/* ============================================================
   HCL Healthcare R&R Portal – script.js
   Complete logic: auth, navigation, all dashboards, CRUD
   ============================================================ */

'use strict';

/* =========================================================
   DATA SEEDS
   ========================================================= */
const AWARD_LIST = [
  {
    id: 'A01', name: 'Star Award - Rising Star', type: 'Reporting',
    clusters: ['Cluster 1 - Mukesh K Pandey','Cluster 2 - Kavitha Dhinesh','Cluster 3 - Vivek',
      'SNF Account - Jibesh Kumar Mishra','New Vista Business - Dr V Harish',
      'Morgan Stanley - Hina Dutt','Care Plan',
      'NV Corp Team (Clinic Managers, Providers\' Network, Operation Services)',
      'Human Resources, L&D, Admin','Finance','Medical Excellence',
      'LOB 1 Corp Team (Client Relationship, VAS, Clinic Managers, Dental, Operation Services)',
      'Product & Marketing and Central Business Analytics',
      'Information, Technology and Innovation',
      'Others - Corporate (CEO Office, New Initiative, President\'s Office)'],
    criteria: '1. Job Performance 30% – Delivers quality, consistent work\n2. Values 30% – Integrity, urgency, innovation, compassion, accountability\n3. Punctuality 20% – Consistent and timely attendance\n4. Grooming 20% – Neat professional appearance per dress code\nFrequency: Quarterly'
  },
  {
    id: 'A02', name: 'Star Award - Front Office', type: 'Jury',
    clusters: ['Cluster 1 - Mukesh K Pandey','Cluster 2 - Kavitha Dhinesh','Cluster 3 - Vivek',
      'New Vista Business - Dr V Harish','Morgan Stanley - Hina Dutt'],
    criteria: '1. Behaviors aligned with organisational values\n2. Initiative taken\n3. Outstanding quarterly performance\n4. Goes the extra mile\nFrequency: Quarterly'
  },
  {
    id: 'A03', name: 'Star Award - Nurse', type: 'Jury',
    clusters: ['Cluster 1 - Mukesh K Pandey','Cluster 2 - Kavitha Dhinesh','Cluster 3 - Vivek',
      'SNF Account - Jibesh Kumar Mishra','New Vista Business - Dr V Harish',
      'Morgan Stanley - Hina Dutt','Care Plan',
      'Others - Corporate (CEO Office, New Initiative, President\'s Office)'],
    criteria: '1. Behaviors aligned with organisational values\n2. Initiative taken\n3. Outstanding quarterly performance\n4. Goes the extra mile\nFrequency: Quarterly'
  },
  {
    id: 'A04', name: 'Star Award - Allied Health Professional', type: 'Jury',
    clusters: ['Cluster 1 - Mukesh K Pandey','Cluster 2 - Kavitha Dhinesh','Cluster 3 - Vivek',
      'SNF Account - Jibesh Kumar Mishra','New Vista Business - Dr V Harish'],
    criteria: '1. Behaviors aligned with organisational values\n2. Initiative taken\n3. Outstanding quarterly performance\n4. Goes the extra mile\nFrequency: Quarterly'
  },
  {
    id: 'A05', name: 'Star Award - Business Enabler', type: 'Jury',
    clusters: ['Care Plan',
      'NV Corp Team (Clinic Managers, Providers\' Network, Operation Services)',
      'Human Resources, L&D, Admin','Finance','Medical Excellence',
      'LOB 1 Corp Team (Client Relationship, VAS, Clinic Managers, Dental, Operation Services)',
      'Product & Marketing and Central Business Analytics',
      'Information, Technology and Innovation',
      'Others - Corporate (CEO Office, New Initiative, President\'s Office)'],
    criteria: '1. Initiatives and Contribution\n2. Team/Individual Performance\n3. Target/Task/Special Assignment Completion\nFrequency: Quarterly'
  },
  {
    id: 'A06', name: 'Star Award - Care Plan Coordinator', type: 'BusinessHead', bhScored: true,
    clusters: ['Care Plan'],
    criteria: 'Consults & Lab Booking ≥ 500 in a month (Doctor consult, Dietician consult, Lab appointment)\nFrequency: Quarterly',
    bh: 'Dr. Gautam Laxman Medhi'
  },
  {
    id: 'A07', name: 'Star Award - Care Plan Champion', type: 'BusinessHead', bhScored: true,
    clusters: ['Care Plan'],
    criteria: 'Enrolments ≥ 190 in a month\nFrequency: Quarterly',
    bh: 'Dr. Gautam Laxman Medhi'
  },
  {
    id: 'A08', name: 'Star Award - Dietician', type: 'BusinessHead', bhScored: true,
    clusters: ['Care Plan'],
    criteria: '1. Total Successful Diet Consult ≥ 70%\n2. Clinical Improvement ≤ 50%\n3. Inconclusive ≤ 12%\n4. NPS ≥ 75% (in-clinic & digital)\nFrequency: Quarterly',
    bh: 'Dr. Gautam Laxman Medhi'
  }
];

const CLUSTERS = [
  'Cluster 1 - Mukesh K Pandey',
  'Cluster 2 - Kavitha Dhinesh',
  'Cluster 3 - Vivek',
  'SNF Account - Jibesh Kumar Mishra',
  'New Vista Business - Dr V Harish',
  'Morgan Stanley - Hina Dutt',
  'Care Plan',
  'NV Corp Team (Clinic Managers, Providers\' Network, Operation Services)',
  'Human Resources, L&D, Admin',
  'Finance',
  'Medical Excellence',
  'LOB 1 Corp Team (Client Relationship, VAS, Clinic Managers, Dental, Operation Services)',
  'Product & Marketing and Central Business Analytics',
  'Information, Technology and Innovation',
  'Others - Corporate (CEO Office, New Initiative, President\'s Office)',
  /* Change 4: new teams added to Team Master */
  'Dental Clinic',
  /* Change 2: 'New Vista Corporate' removed — merged into NV Corp Team (see migration in initStorage) */
  'Others Nurse (Care Plan, VAS, New Vista Corporate)',
  'Corporate Sales',
  'Other'
];

/* =========================================================
   Change 4: TEAM → AWARD ELIGIBILITY (reference data only)
   This is informational/reference data for HR — it documents
   which awards each team is eligible for. It does NOT drive
   which awards a Manager sees; award visibility for Managers
   continues to be controlled entirely by the existing manual
   Award Assignment screen (SEED_ASSIGNMENTS / getAssignments()),
   exactly as before. This map is surfaced as a read-only
   reference table in HR's Headcount/Team screen.
   ========================================================= */
const TEAM_AWARD_ELIGIBILITY = [
  { team: 'Dental Clinic', eligibleAwards: ['Star Award - Allied Health Professional', 'Star Award - Business Enabler'] },
  /* Change 2: 'New Vista Corporate' merged into NV Corp Team */
  { team: 'NV Corp Team (Clinic Managers, Providers\'s Network, Operation Services)', eligibleAwards: ['Star Award - Business Enabler'] },
  { team: 'Others Nurse (Care Plan, VAS, New Vista Corporate)', eligibleAwards: ['Star Award - Nurse'] },
  { team: 'Corporate Sales', eligibleAwards: ['Star Award - Rising Star'] }
];

const SEED_USERS = [
  { empId:'HR001', password:'hr@123', name:'Priya Kapoor', role:'HR Admin', email:'priya.kapoor@hclhealthcare.com', active:true, isDemo:true },
  // Managers: email-only login, no password, eligibleTeams from CSV upload
  { empId:'M001', name:'Rahul Sharma', role:'Manager', email:'rahul.sharma@hclhealthcare.com', active:true,
    eligibleTeams:['Cluster 1 - Mukesh K Pandey','Finance'], isDemo:true },
  { empId:'M002', name:'Anjali Mehta', role:'Manager', email:'anjali.mehta@hclhealthcare.com', active:true,
    eligibleTeams:['Cluster 2 - Kavitha Dhinesh','Care Plan'], isDemo:true },
  { empId:'M003', name:'Vikram Nair', role:'Manager', email:'vikram.nair@hclhealthcare.com', active:true,
    eligibleTeams:['Cluster 3 - Vivek','SNF Account - Jibesh Kumar Mishra'], isDemo:true },
  { empId:'J001', password:'jury@123', name:'Sanjay Patel', role:'Jury Member', email:'sanjay.patel@hclhealthcare.com', active:true, isDemo:true },
  { empId:'J002', password:'jury@123', name:'Meera Iyer', role:'Jury Member', email:'meera.iyer@hclhealthcare.com', active:true, isDemo:true },
  { empId:'BH001', password:'bh@123', name:'Dr. Gautam Laxman Medhi', role:'Business Head', email:'gautam.medhi@hclhealthcare.com', active:true, isDemo:true },
  { empId:'BH002', password:'bh@123', name:'Kavitha Dhinesh', role:'Business Head', email:'kavita.dinesh@hclhealthcare.com', active:true, isDemo:true },
  // Rahul also as Jury — dual-role demo entry
  { empId:'J001B', password:'jury@123', name:'Rahul Sharma', role:'Jury Member', email:'rahul.sharma@hclhealthcare.com', active:true, isDemo:true },
  // User requested credentials
  { empId:'HR002', password:'Deeksha@1234', name:'Deeksha', role:'HR Admin', email:'hrintern@hclhealthcare.in', active:true, isDemo:true },
  { empId:'M004', name:'Deeksha', role:'Manager', email:'hrintern@hclhealthcare.in', active:true,
    eligibleTeams:['Cluster 1 - Mukesh K Pandey','Finance'], isDemo:true },
  { empId:'J003', password:'Deeksha@1234', name:'Deeksha', role:'Jury Member', email:'hrintern@hclhealthcare.in', active:true, isDemo:true },
  { empId:'BH003', password:'Deeksha@1234', name:'Deeksha', role:'Business Head', email:'hrintern@hclhealthcare.in', active:true, isDemo:true }
];

const SEED_ASSIGNMENTS = [
  // Manager assignments
  { awardId:'A01', role:'Manager', empId:'M001', isDemo:true },
  { awardId:'A01', role:'Manager', empId:'M002', isDemo:true },
  { awardId:'A02', role:'Manager', empId:'M001', isDemo:true },
  { awardId:'A03', role:'Manager', empId:'M002', isDemo:true },
  { awardId:'A04', role:'Manager', empId:'M003', isDemo:true },
  { awardId:'A05', role:'Manager', empId:'M001', isDemo:true },
  { awardId:'A06', role:'Manager', empId:'M002', isDemo:true },
  { awardId:'A07', role:'Manager', empId:'M003', isDemo:true },
  { awardId:'A08', role:'Manager', empId:'M001', isDemo:true },
  // Jury assignments
  { awardId:'A02', role:'Jury', empId:'J001', isDemo:true },
  { awardId:'A03', role:'Jury', empId:'J001', isDemo:true },
  { awardId:'A04', role:'Jury', empId:'J002', isDemo:true },
  { awardId:'A05', role:'Jury', empId:'J002', isDemo:true },
  // BH assignments
  { awardId:'A06', role:'BusinessHead', empId:'BH001', isDemo:true },
  { awardId:'A07', role:'BusinessHead', empId:'BH001', isDemo:true },
  { awardId:'A08', role:'BusinessHead', empId:'BH001', isDemo:true }
];

/* v9: Headcounts are now per FY+Quarter+Team+Award composite key.
   Rising Star Award is excluded from Headcount.
   Old records without an award field will be migrated in migrateHeadcountsToAwardWise(). */
const SEED_HEADCOUNTS = [
  { fy:'FY2025-26', quarter:'Q2', cluster:'Cluster 1 - Mukesh K Pandey', award:'Star Award - Nurse', headcount:92, isDemo:true },
  { fy:'FY2025-26', quarter:'Q2', cluster:'Cluster 1 - Mukesh K Pandey', award:'Star Award - Front Office', headcount:18, isDemo:true },
  { fy:'FY2025-26', quarter:'Q2', cluster:'Cluster 1 - Mukesh K Pandey', award:'Star Award - Allied Health Professional', headcount:41, isDemo:true },
  { fy:'FY2025-26', quarter:'Q2', cluster:'Cluster 2 - Kavitha Dhinesh', award:'Star Award - Nurse', headcount:85, isDemo:true },
  { fy:'FY2025-26', quarter:'Q2', cluster:'Care Plan', award:'Star Award - Business Enabler', headcount:75, isDemo:true }
];

const SEED_NOMINATIONS = [
  {
    id:'N001', awardId:'A02', fy:'FY2025-26', quarter:'Q2',
    nomineeName:'Deepa Singh', empId:'E201', cluster:'Cluster 1 - Mukesh K Pandey',
    location:'Mumbai', reason:'Exceptional patient handling and consistently positive feedback from clients over the quarter.',
    managerEmpId:'M001', managerName:'Rahul Sharma', submittedAt:'2025-10-05',
    status:'Jury Review',
    juryScores:[ { juryId:'J001', juryName:'Sanjay Patel', score:88, comment:'Outstanding service attitude and initiative.' } ],
    isDemo:true
  },
  {
    id:'N002', awardId:'A02', fy:'FY2025-26', quarter:'Q2',
    nomineeName:'Ritesh Kumar', empId:'E202', cluster:'Cluster 2 - Kavitha Dhinesh',
    location:'Delhi', reason:'Led front office transformation reducing patient wait time by 35%.',
    managerEmpId:'M002', managerName:'Anjali Mehta', submittedAt:'2025-10-06',
    status:'Jury Review',
    juryScores:[],
    isDemo:true
  },
  {
    id:'N003', awardId:'A03', fy:'FY2025-26', quarter:'Q2',
    nomineeName:'Sunita Rao', empId:'E203', cluster:'Cluster 3 - Vivek',
    location:'Bangalore', reason:'Excellent patient care beyond duty hours during staff shortage period.',
    managerEmpId:'M002', managerName:'Anjali Mehta', submittedAt:'2025-10-07',
    status:'Jury Review',
    juryScores:[],
    isDemo:true
  },
  {
    id:'N004', awardId:'A06', fy:'FY2025-26', quarter:'Q2',
    nomineeName:'Kavya Nair', empId:'E204', cluster:'Care Plan',
    location:'Hyderabad', reason:'Achieved 540 consult & lab bookings, 8% above target for the quarter.',
    managerEmpId:'M002', managerName:'Anjali Mehta', submittedAt:'2025-10-08',
    status:'BH Review',
    bhScores:[],
    isDemo:true
  },
  {
    id:'N005', awardId:'A01', fy:'FY2025-26', quarter:'Q2',
    nomineeName:'Arjun Verma', empId:'E205', cluster:'Cluster 1 - Mukesh K Pandey',
    location:'Mumbai', reason:'Consistent punctuality, excellent grooming standards, strong performance scores.',
    managerEmpId:'M001', managerName:'Rahul Sharma', submittedAt:'2025-10-09',
    status:'HR Review',
    isDemo:true
  },
  {
    id:'N006', awardId:'A05', fy:'FY2025-26', quarter:'Q2',
    nomineeName:'Preethi Subramanian', empId:'E206', cluster:'Finance',
    location:'Chennai', reason:'Led finance digitisation initiative saving 200+ man-hours per month.',
    managerEmpId:'M001', managerName:'Rahul Sharma', submittedAt:'2025-10-10',
    status:'Jury Review',
    juryScores:[ { juryId:'J002', juryName:'Meera Iyer', score:92, comment:'Exceptional project ownership and delivery.' } ],
    isDemo:true
  }
];

const SEED_WINNERS = [
  {
    id:'W001', awardId:'A02', awardName:'Star Award - Front Office', fy:'FY2025-26', quarter:'Q1',
    winnerName:'Deepa Singh', empId:'E201', cluster:'Cluster 1 - Mukesh K Pandey',
    approvedAt:'2025-08-15', approvedBy:'Priya Kapoor', isDemo:true
  }
];

/* =========================================================
   JSONBIN SHARED STORAGE
   =========================================================
   All portal data (users, nominations, headcounts, etc.)
   is stored in a shared JSONBin so every user sees the
   same data. Session-only keys (rr_current_user,
   rr_session_roles, rr_version) stay in localStorage.

   Setup: HR admin enters the JSONBin Master Key and Bin ID
   once via the setup screen; these are saved in localStorage
   on that device only (they are credentials, not shared data).
   ========================================================= */

const LS = {
  get(k) {
    try {
      const val = localStorage.getItem(k);
      return val ? JSON.parse(val) : null;
    } catch(e) {
      console.error(`Error reading ${k} from localStorage:`, e);
      return null;
    }
  },
  set(k, v) {
    try {
      localStorage.setItem(k, JSON.stringify(v));
    } catch(e) {
      console.error(`Error writing ${k} to localStorage:`, e);
    }
  },
  remove(k) {
    try {
      localStorage.removeItem(k);
    } catch(e) {
      console.error(`Error removing ${k} from localStorage:`, e);
    }
  },
  merge(k, defaultVal) {
    const existing = this.get(k);
    if (existing === null) {
      this.set(k, defaultVal);
      return defaultVal;
    }
    return existing;
  }
};

/* Version stamp — change this string whenever the data schema changes.
   v6: Multiple-role support + isDemo flag cleanup
   v7: Full tri-role support (Manager + Jury + Business Head), Switch Role, BH access assign
   v8: Team-Award mapping (Change 1), Remove New Vista Corporate (Change 2), userId fix (Change 3)
   v9: Headcount now Team+Award-wise, Rising Star exception, Quarter display format Q1 AMJ etc, CSV Import for Headcount
   v10: headcountId — permanent unique ID on every Headcount record; CRUD no longer uses composite key
   v11: Rising Star optional Comments field; HR Soft Delete nominations; Deleted Nominations page; visual redesign */
const DATA_VERSION = 'v11';

/* =========================================================
   CHANGE 6 — DEMO DATA CLEANUP
   Removes only records flagged isDemo:true from each store.
   Never touches records without the flag (user-uploaded data).
   ========================================================= */
function removeDemoRecords() {
  const stores = ['rr_users','rr_assignments','rr_headcounts','rr_nominations','rr_winners'];
  stores.forEach(key => {
    const data = LS.get(key);
    if (!Array.isArray(data)) return;
    const cleaned = data.filter(r => !r.isDemo);
    LS.set(key, cleaned);
  });
}

/* CHANGE 6 — Tag any existing records that match demo seed IDs
   (for portals upgraded from v5 that never had isDemo on them). */
function backfillDemoFlags() {
  const demoUserIds    = new Set(SEED_USERS.map(u => u.empId));
  const demoNomIds     = new Set(SEED_NOMINATIONS.map(n => n.id));
  const demoWinnerIds  = new Set(SEED_WINNERS.map(w => w.id));

  const users = LS.get('rr_users') || [];
  let changed = false;
  users.forEach(u => { if (demoUserIds.has(u.empId) && !u.isDemo) { u.isDemo = true; changed = true; } });
  if (changed) LS.set('rr_users', users);

  const assignments = LS.get('rr_assignments') || [];
  changed = false;
  assignments.forEach(a => {
    if (demoUserIds.has(a.empId) && !a.isDemo) { a.isDemo = true; changed = true; }
  });
  if (changed) LS.set('rr_assignments', assignments);

  const headcounts = LS.get('rr_headcounts') || [];
  changed = false;
  /* Seed headcounts are identified by the combination of fy+quarter+cluster matching a seed record */
  const seedHCKeys = new Set(SEED_HEADCOUNTS.map(h => `${h.fy}|${h.quarter}|${h.cluster}|${h.award||''}`));
  headcounts.forEach(h => {
    if (seedHCKeys.has(`${h.fy}|${h.quarter}|${h.cluster}|${h.award||''}`) && !h.isDemo) { h.isDemo = true; changed = true; }
  });
  if (changed) LS.set('rr_headcounts', headcounts);

  const noms = LS.get('rr_nominations') || [];
  changed = false;
  noms.forEach(n => { if (demoNomIds.has(n.id) && !n.isDemo) { n.isDemo = true; changed = true; } });
  if (changed) LS.set('rr_nominations', noms);

  const winners = LS.get('rr_winners') || [];
  changed = false;
  winners.forEach(w => { if (demoWinnerIds.has(w.id) && !w.isDemo) { w.isDemo = true; changed = true; } });
  if (changed) LS.set('rr_winners', winners);
}

/* =========================================================
   CHANGE 1: TEAM-AWARD MAPPING helpers
   rr_team_awards: [{ team: string, awardIds: string[] }]
   ========================================================= */
function getTeamAwards() { return LS.get('rr_team_awards') || []; }
function setTeamAwards(v) { LS.set('rr_team_awards', v); }

/* Return award IDs assigned to a given team name */
function getAwardIdsForTeam(teamName) {
  const entry = getTeamAwards().find(t => t.team === teamName);
  return entry ? entry.awardIds : [];
}

/* Return all award IDs visible to a manager (union of all their teams) */
function getAwardIdsForManager(managerUser) {
  const teams = Array.isArray(managerUser.eligibleTeams) ? managerUser.eligibleTeams : [];
  const teamAwards = getTeamAwards();
  const ids = new Set();
  teams.forEach(team => {
    const entry = teamAwards.find(t => t.team === team);
    if (entry) entry.awardIds.forEach(id => ids.add(id));
  });
  return [...ids];
}

/* =========================================================
   CHANGE 2: Canonical name for the merged team
   ========================================================= */
const NV_CORP_CANONICAL = 'NV Corp Team (Clinic Managers, Providers\' Network, Operation Services)';
const NV_CORP_OBSOLETE  = 'New Vista Corporate';

function mergeNewVistaCorporate() {
  let changed = false;

  /* Users: replace eligibleTeams entries */
  const users = LS.get('rr_users') || [];
  users.forEach(u => {
    if (Array.isArray(u.eligibleTeams)) {
      const before = JSON.stringify(u.eligibleTeams);
      u.eligibleTeams = u.eligibleTeams.map(t => t === NV_CORP_OBSOLETE ? NV_CORP_CANONICAL : t);
      /* deduplicate */
      u.eligibleTeams = [...new Set(u.eligibleTeams)];
      if (JSON.stringify(u.eligibleTeams) !== before) changed = true;
    }
  });
  if (changed) LS.set('rr_users', users);

  /* Headcounts: replace cluster names */
  const hcs = LS.get('rr_headcounts') || [];
  let hcChanged = false;
  hcs.forEach(h => {
    if (h.cluster === NV_CORP_OBSOLETE) {
      /* Check if canonical already exists for same period */
      const dupExists = hcs.some(x => x.cluster === NV_CORP_CANONICAL && x.fy === h.fy && x.quarter === h.quarter);
      if (!dupExists) { h.cluster = NV_CORP_CANONICAL; hcChanged = true; }
      /* else: duplicate — leave original so data is not silently lost; HR can clean up */
    }
  });
  if (hcChanged) LS.set('rr_headcounts', hcs);

  /* Nominations: replace cluster names */
  const noms = LS.get('rr_nominations') || [];
  let nomChanged = false;
  noms.forEach(n => {
    if (n.cluster === NV_CORP_OBSOLETE) { n.cluster = NV_CORP_CANONICAL; nomChanged = true; }
  });
  if (nomChanged) LS.set('rr_nominations', noms);

  /* Winners: replace cluster names */
  const winners = LS.get('rr_winners') || [];
  let wChanged = false;
  winners.forEach(w => {
    if (w.cluster === NV_CORP_OBSOLETE) { w.cluster = NV_CORP_CANONICAL; wChanged = true; }
  });
  if (wChanged) LS.set('rr_winners', winners);

  /* Team-Award mapping: replace team names */
  const ta = LS.get('rr_team_awards') || [];
  let taChanged = false;
  ta.forEach(t => {
    if (t.team === NV_CORP_OBSOLETE) {
      const canonIdx = ta.findIndex(x => x.team === NV_CORP_CANONICAL);
      if (canonIdx > -1) {
        /* Merge award IDs */
        const merged = [...new Set([...ta[canonIdx].awardIds, ...t.awardIds])];
        ta[canonIdx].awardIds = merged;
        t._delete = true;
      } else {
        t.team = NV_CORP_CANONICAL;
      }
      taChanged = true;
    }
  });
  if (taChanged) LS.set('rr_team_awards', ta.filter(t => !t._delete));
}

/* =========================================================
   CHANGE 3: Ensure every user record has a permanent userId
   ========================================================= */
function backfillUserIds() {
  const users = LS.get('rr_users');
  if (!Array.isArray(users)) return;
  let changed = false;
  const seenIds = new Set();
  users.forEach(u => {
    if (!u.userId) {
      u.userId = 'UID' + Date.now() + Math.random().toString(36).slice(2, 8);
      changed = true;
    }
    /* Guard against duplicate userIds (shouldn't happen, but be safe) */
    if (seenIds.has(u.userId)) {
      u.userId = 'UID' + Date.now() + Math.random().toString(36).slice(2, 8);
      changed = true;
    }
    seenIds.add(u.userId);
  });
  if (changed) LS.set('rr_users', users);
}

/* =========================================================
   CHANGE 1: SAFE MIGRATION — Manager Award Assignments → Team Award Assignments
   Reads existing rr_assignments (Manager role only), maps manager → team,
   converts to team-award entries in rr_team_awards.
   Reports any that cannot be migrated automatically.
   Does NOT delete rr_assignments (Jury + BH entries remain intact).
   ========================================================= */
function migrateManagerAssignmentsToTeams() {
  const assignments = LS.get('rr_assignments') || [];
  const users       = LS.get('rr_users') || [];
  const teamAwards  = LS.get('rr_team_awards') || [];

  const managerAssignments = assignments.filter(a => a.role === 'Manager');
  if (!managerAssignments.length) return { migrated: 0, unmigrated: [] };

  const unmigrated = [];
  let migratedCount = 0;

  managerAssignments.forEach(a => {
    const mgr = users.find(u => u.empId === a.empId || u.userId === a.empId);
    if (!mgr) {
      unmigrated.push({ reason: 'Manager not found', empId: a.empId, awardId: a.awardId });
      return;
    }
    const teams = Array.isArray(mgr.eligibleTeams) && mgr.eligibleTeams.length ? mgr.eligibleTeams : [];
    if (!teams.length) {
      unmigrated.push({ reason: 'Manager has no team assigned', name: mgr.name, empId: a.empId, awardId: a.awardId });
      return;
    }
    /* Assign award to each of manager's teams */
    teams.forEach(team => {
      let entry = teamAwards.find(t => t.team === team);
      if (!entry) { entry = { team, awardIds: [] }; teamAwards.push(entry); }
      if (!entry.awardIds.includes(a.awardId)) {
        entry.awardIds.push(a.awardId);
        migratedCount++;
      }
    });
  });

  LS.set('rr_team_awards', teamAwards);

  /* Store migration report for HR to review */
  if (unmigrated.length) {
    LS.set('rr_migration_report', { runAt: new Date().toISOString(), unmigrated });
  }

  return { migrated: migratedCount, unmigrated };
}


/* =========================================================
   v9: SAFE MIGRATION — Old team-only headcounts → team+award headcounts
   For any headcount record that has no 'award' field, we cannot know
   which award it belonged to, so we flag it for HR attention rather than
   silently deleting or duplicating. The old record is preserved with
   award = '__migrated__' so HR can see it in the table and decide.
   Rising Star award headcounts (if somehow inserted) are removed.
   ========================================================= */
function migrateHeadcountsToAwardWise() {
  const hcs = LS.get('rr_headcounts') || [];
  let changed = false;
  const RISING_STAR_NAME = 'Star Award - Rising Star';

  hcs.forEach(h => {
    // Remove any Rising Star headcount records
    if (h.award === RISING_STAR_NAME) {
      h._delete = true;
      changed = true;
      return;
    }
    // Records without award field: keep them but mark for HR review
    if (!h.award) {
      h.award = '__legacy__';
      changed = true;
    }
  });

  if (changed) {
    LS.set('rr_headcounts', hcs.filter(h => !h._delete));
  }
}

function initStorage() {
  const storedVer = localStorage.getItem('rr_version');

  if (storedVer !== DATA_VERSION) {
    if (storedVer === 'v5') {
      backfillDemoFlags();
      removeDemoRecords();
    } else if (storedVer === 'v6') {
      /* intentionally a no-op data migration */
    } else if (storedVer === 'v7') {
      /* SAFE UPGRADE v7 → v8:
         1. Backfill userId on every user (Change 3)
         2. Merge "New Vista Corporate" → canonical team name (Change 2)
         3. Migrate manager-award assignments → team-award assignments (Change 1)
         No data is deleted. rr_assignments preserved intact. */
      backfillUserIds();
      mergeNewVistaCorporate();
      migrateManagerAssignmentsToTeams();
      migrateHeadcountsToAwardWise();
    } else if (storedVer === 'v8') {
      /* SAFE UPGRADE v8 → v9:
         Migrate old team-only headcounts to team+award composite key.
         No data is deleted. All other stores preserved intact. */
      migrateHeadcountsToAwardWise();
    } else if (storedVer === 'v9') {
      /* SAFE UPGRADE v9 → v10:
         Backfill headcountId on every existing Headcount record.
         No data is deleted. All other stores preserved intact. */
      migrateHeadcountIds();
    } else if (storedVer === 'v10') {
      /* SAFE UPGRADE v10 → v11:
         Rising Star comments, soft-delete, redesign — no data migration needed.
         Existing nominations without deletedAt are treated as active (not deleted). */
    } else if (storedVer === null) {
      /* Fresh install — nothing to preserve */
    } else {
      /* Older/unknown version — wipe rr_* shared data and start clean */
      const keysToWipe = ['rr_users','rr_assignments','rr_headcounts','rr_nominations','rr_winners','rr_nom_open','rr_team_awards'];
      keysToWipe.forEach(k => LS.remove(k));
    }
    localStorage.setItem('rr_version', DATA_VERSION);
  }

  /* Always ensure userIds exist (handles first-run after manual empId edits) */
  backfillUserIds();
  /* Always ensure headcountId exists on every Headcount record */
  migrateHeadcountIds();

  /* Only seed if the store is completely absent (null) — never overwrite existing data */
  if (LS.get('rr_users')       === null) LS.set('rr_users',       SEED_USERS);
  if (LS.get('rr_assignments') === null) LS.set('rr_assignments', SEED_ASSIGNMENTS);
  if (LS.get('rr_headcounts')  === null) LS.set('rr_headcounts',  SEED_HEADCOUNTS);
  if (LS.get('rr_nominations') === null) LS.set('rr_nominations', SEED_NOMINATIONS);
  if (LS.get('rr_winners')     === null) LS.set('rr_winners',     SEED_WINNERS);
  if (LS.get('rr_nom_open')    === null) LS.set('rr_nom_open',    true);
  if (LS.get('rr_team_awards') === null) LS.set('rr_team_awards', []);

  // Ensure user requested credentials hrintern@hclhealthcare.in always exist and are active in users list
  let currentUsers = LS.get('rr_users') || [];
  currentUsers = currentUsers.filter(u => (u.email || '').toLowerCase() !== 'hrintern@hclhealthcare.in');
  const deekshaUsers = [
    { empId:'HR002', password:'Deeksha@1234', name:'Deeksha', role:'HR Admin', email:'hrintern@hclhealthcare.in', active:true, isDemo:true },
    { empId:'M004', name:'Deeksha', role:'Manager', email:'hrintern@hclhealthcare.in', active:true,
      eligibleTeams:['Cluster 1 - Mukesh K Pandey','Finance'], isDemo:true },
    { empId:'J003', password:'Deeksha@1234', name:'Deeksha', role:'Jury Member', email:'hrintern@hclhealthcare.in', active:true, isDemo:true },
    { empId:'BH003', password:'Deeksha@1234', name:'Deeksha', role:'Business Head', email:'hrintern@hclhealthcare.in', active:true, isDemo:true }
  ];
  currentUsers = [...currentUsers, ...deekshaUsers];
  LS.set('rr_users', currentUsers);
}

function getUsers() { return LS.get('rr_users') || []; }
function setUsers(v) { LS.set('rr_users', v); }
function getAssignments() { return LS.get('rr_assignments') || []; }
function setAssignments(v) { LS.set('rr_assignments', v); }
function getHeadcounts() { return LS.get('rr_headcounts') || []; }
function setHeadcounts(v) { LS.set('rr_headcounts', v); }
/* getNominations() returns only active (non-deleted) nominations throughout the portal.
   getAllNominations() is used by HR Deleted Nominations page and migration utilities. */
function getAllNominations() { return LS.get('rr_nominations') || []; }
function getNominations() { return getAllNominations().filter(n => !n.deletedAt); }
function setNominations(v) { LS.set('rr_nominations', v); }
function getWinners() { return LS.get('rr_winners') || []; }
function setWinners(v) { LS.set('rr_winners', v); }
function isNomOpen() { return LS.get('rr_nom_open') !== false; }
function setNomOpen(v) { LS.set('rr_nom_open', v); }
function currentUser() { return LS.get('rr_current_user'); }
/* v7: session roles — all role records for the logged-in email (cleared on logout) */
function getSessionRoles() { return LS.get('rr_session_roles') || []; }
function setSessionRoles(v) { LS.set('rr_session_roles', v); }
function getFY() { return document.getElementById('filterFY')?.value || 'FY2025-26'; }
function getQ() { return document.getElementById('filterQ')?.value || 'Q2'; }

/* v9: Quarter display helpers — Change 3
   Store value: Q1/Q2/Q3/Q4 | Display value: Q1 AMJ / Q2 JAS / Q3 OND / Q4 JFM */
const QUARTER_DISPLAY = { Q1:'Q1 AMJ', Q2:'Q2 JAS', Q3:'Q3 OND', Q4:'Q4 JFM' };
const QUARTER_MONTHS  = { Q1:'April – May – June', Q2:'July – August – September', Q3:'October – November – December', Q4:'January – February – March' };
function qDisplay(q) { return QUARTER_DISPLAY[q] || q; }
function qOptions(selectedQ) {
  return ['Q1','Q2','Q3','Q4'].map(q =>
    `<option value="${q}" ${q===selectedQ?'selected':''}>${qDisplay(q)}</option>`
  ).join('');
}

/* v9: RISING_STAR_AWARD_NAME — excluded from headcount everywhere */
const RISING_STAR_AWARD_NAME = 'Star Award - Rising Star';

function uid() { return 'X' + Date.now() + Math.random().toString(36).slice(2,6); }

/* v10: Permanent unique ID for every Headcount record.
   Avoids all issues with special characters (apostrophes, commas, brackets)
   that would break composite-key strings inside HTML onclick attributes. */
function generateHeadcountId() {
  return 'HC' + Date.now().toString(36).toUpperCase() + Math.random().toString(36).slice(2,8).toUpperCase();
}

/* v10: Safe migration — backfill headcountId on every existing record that
   does not already have one. No records are deleted or recreated. */
function migrateHeadcountIds() {
  const hcs = LS.get('rr_headcounts');
  if (!hcs || !Array.isArray(hcs)) return;
  let changed = false;
  hcs.forEach(h => {
    if (!h.headcountId) {
      h.headcountId = generateHeadcountId();
      changed = true;
    }
  });
  if (changed) LS.set('rr_headcounts', hcs);
}

/* =========================================================
   AUTH
   ========================================================= */

/* Track which login tab is active */
let _loginTab = 'empId';

function switchLoginTab(tab) {
  _loginTab = tab;
  document.getElementById('panelEmpId').style.display  = tab === 'empId'  ? '' : 'none';
  document.getElementById('panelEmail').style.display   = tab === 'email'  ? '' : 'none';
  document.getElementById('tabEmpId').classList.toggle('active', tab === 'empId');
  document.getElementById('tabEmail').classList.toggle('active',  tab === 'email');
  document.getElementById('loginError').style.display = 'none';
}

/* -------------------------------------------------------
   CHANGE 5 / v7 — FULL TRI-ROLE LOGIN
   The same email can now hold ANY combination of:
     Manager, Jury Member, Business Head (and HR Admin).

   Tab "Manager" (email-only):
     → Matches the Manager record for that email.
     → After login, also collects all OTHER roles for that
       email (Jury, BH) so Switch Role works immediately.

   Tab "HR / Jury / Business Head" (email + password):
     → Finds ALL non-Manager records whose password matches.
     → ALSO includes the Manager record for the same email
       (Manager has no password — it is automatically included
       when the email is found in a password-tab login).
     → If exactly one role → login directly.
     → If multiple roles → show role picker.
   ------------------------------------------------------- */
function doLogin() {
  const errEl = document.getElementById('loginError');
  errEl.style.display = 'none';
  const users = getUsers();

  const emailTabBtn = document.getElementById('tabEmail');
  const useEmailLogin = emailTabBtn && emailTabBtn.classList.contains('active');

  if (useEmailLogin) {
    /* ---- Manager email-only login ---- */
    const emailEl = document.getElementById('loginEmail');
    const email = (emailEl ? emailEl.value : '').trim().toLowerCase();
    if (!email) {
      errEl.textContent = 'Please enter your official email address.';
      errEl.style.display = 'block';
      return;
    }
    const user = users.find(u =>
      u.role === 'Manager' &&
      u.active &&
      (u.email || '').toLowerCase() === email
    );
    if (!user) {
      errEl.textContent = 'No active Manager account found for this email. Contact HR Admin.';
      errEl.style.display = 'block';
      return;
    }
    /* Collect ALL active roles for this email for Switch Role */
    const allRoles = users.filter(u => u.active && (u.email||'').toLowerCase() === email);
    launchSession(user, allRoles);

  } else {
    /* ---- HR / Jury / BH: Email + Password ---- */
    const emailVal = (document.getElementById('loginEmpId').value || '').trim().toLowerCase();
    const pwd      = (document.getElementById('loginPassword').value || '').trim();
    if (!emailVal || !pwd) {
      errEl.textContent = 'Please enter your email address and password.';
      errEl.style.display = 'block';
      return;
    }
    /* Find all non-Manager records matching email+password */
    const pwdMatches = users.filter(u =>
      u.role !== 'Manager' &&
      (u.email || '').toLowerCase() === emailVal &&
      u.password === pwd &&
      u.active
    );
    if (!pwdMatches.length) {
      errEl.textContent = 'Invalid email or password.';
      errEl.style.display = 'block';
      return;
    }
    /* Also include the Manager record for this email (no password needed — linked by email) */
    const managerRecord = users.find(u =>
      u.role === 'Manager' &&
      u.active &&
      (u.email || '').toLowerCase() === emailVal
    );
    /* All roles for this session */
    const allRoles = managerRecord ? [managerRecord, ...pwdMatches] : pwdMatches;

    if (allRoles.length === 1) {
      launchSession(allRoles[0], allRoles);
    } else {
      showRolePicker(allRoles);
    }
  }
}

/* Launch session for a specific user record; allRoles = full list for Switch Role */
function launchSession(user, allRoles) {
  LS.set('rr_current_user', user);
  /* v7: store all roles for this email so Switch Role works without re-login */
  if (allRoles && allRoles.length > 0) {
    setSessionRoles(allRoles);
  } else {
    /* Called from role picker where allRoles already stored */
  }
  document.getElementById('loginPage').style.display = 'none';
  document.getElementById('appShell').style.display = 'flex';
  buildNav();
  navigateTo(defaultPage(user.role));
}

/* v7: Role picker shown when one person has multiple roles */
function showRolePicker(allRoles) {
  /* Store session roles now so launchSession can skip the allRoles param */
  setSessionRoles(allRoles);

  const errEl = document.getElementById('loginError');
  errEl.style.display = 'none';

  const roleIcons = { 'HR Admin':'🛡️', 'Manager':'👔', 'Jury Member':'⚖️', 'Business Head':'💼' };
  const btnHtml = allRoles.map((u, i) =>
    `<button class="btn-secondary" style="width:100%;margin-bottom:10px;padding:12px 16px;text-align:left;font-size:15px;"
      onclick="launchSession(window._rolePickerMatches[${i}])">
      <span style="font-size:20px;margin-right:10px">${roleIcons[u.role]||'👤'}</span>
      <strong>${u.role}</strong>
      <span style="display:block;font-size:12px;opacity:0.65;margin-top:2px;margin-left:30px">${u.name}</span>
    </button>`
  ).join('');

  window._rolePickerMatches = allRoles;

  /* Replace login card body temporarily */
  const loginForm = document.querySelector('.login-form');
  loginForm.innerHTML = `
    <div style="margin-bottom:18px">
      <h3 style="margin:0 0 6px;font-size:16px">Select Role to Sign In As</h3>
      <p style="margin:0;font-size:13px;opacity:0.7">Multiple roles found for this account — choose how you want to enter.</p>
    </div>
    ${btnHtml}
    <button class="btn-secondary" style="width:100%;margin-top:4px" onclick="resetLoginForm()">← Back to Login</button>`;
}

function resetLoginForm() {
  /* Rebuild the login form HTML from scratch */
  document.querySelector('.login-form').innerHTML = `
    <div class="login-tabs">
      <button class="login-tab active" id="tabEmpId" onclick="switchLoginTab('empId')">
        HR / Jury / Business Head
      </button>
      <button class="login-tab" id="tabEmail" onclick="switchLoginTab('email')">
        Manager
      </button>
    </div>
    <div id="panelEmpId">
      <div class="form-group">
        <label>Official Email Address</label>
        <input type="email" id="loginEmpId" placeholder="yourname@hclhealthcare.com" />
      </div>
      <div class="form-group">
        <label>Password</label>
        <input type="password" id="loginPassword" placeholder="Enter password" />
      </div>
    </div>
    <div id="panelEmail" style="display:none">
      <div class="form-group">
        <label>Official Email ID</label>
        <input type="email" id="loginEmail" placeholder="yourname@hclhealthcare.com" />
      </div>
      <p class="login-email-note">Managers sign in with their official email address.<br/>No password required.</p>
    </div>
    <div id="loginError" class="error-msg" style="display:none"></div>
    <button class="btn-primary full-width" onclick="doLogin()">Sign In</button>`;
  switchLoginTab('empId');
}

function doLogout() {
  LS.remove('rr_current_user');
  LS.remove('rr_session_roles');
  document.getElementById('appShell').style.display = 'none';
  document.getElementById('loginPage').style.display = 'flex';
  /* Rebuild the login form (handles the case where role-picker replaced it) */
  resetLoginForm();
}

function defaultPage(role) {
  const map = { 'HR Admin':'hrDashboard', 'Manager':'managerDashboard', 'Jury Member':'juryDashboard', 'Business Head':'bhDashboard' };
  return map[role] || 'hrDashboard';
}

/* =========================================================
   NAVIGATION
   ========================================================= */
let currentPage = '';

const NAV_CONFIG = {
  'HR Admin': [
    { section:'Overview' },
    { id:'hrDashboard', label:'Dashboard', icon:'📊' },
    { section:'Management' },
    { id:'userMgmt', label:'User Management', icon:'👥' },
    { id:'awardAssignment', label:'Award Assignment', icon:'🏆' },
    { id:'headcountMgmt', label:'Headcount Management', icon:'📋' },
    { section:'Operations' },
    { id:'nominationControl', label:'Nomination Control', icon:'🔧' },
    { id:'detailedReview', label:'Nomination Review', icon:'🔍' },
    { id:'winnerApproval', label:'Winner Approval', icon:'✅' },
    { id:'winnerHistory', label:'Winner History', icon:'🏅' },
    { id:'deletedNominations', label:'Deleted Nominations', icon:'🗑️' },
    { section:'Score Reviews' },
    { id:'risingStarReview', label:'Rising Star Review', icon:'🌟' },
    { id:'hrScoreReview', label:'Jury Score Review', icon:'⭐' },
    { id:'bhScoreReview', label:'BH Score Review', icon:'💼' },
    { id:'nominationTracker', label:'Nomination Tracker', icon:'📈' }
  ],
  'Manager': [
    { section:'Overview' },
    { id:'managerDashboard', label:'My Awards', icon:'🏆' },
    { section:'Activity' },
    { id:'myNominations', label:'My Nominations', icon:'📝' },
    { section:'Recognition' },
    { id:'winnerHistory', label:'Winner History', icon:'🏅' }
  ],
  'Jury Member': [
    { section:'Overview' },
    { id:'juryDashboard', label:'Jury Dashboard', icon:'⚖️' },
    { section:'Actions' },
    { id:'juryEvaluations', label:'My Evaluations', icon:'📋' },
    { section:'Recognition' },
    { id:'winnerHistory', label:'Winner History', icon:'🏅' }
  ],
  'Business Head': [
    { section:'Overview' },
    { id:'bhDashboard', label:'BH Dashboard', icon:'💼' },
    { section:'Recognition' },
    { id:'winnerHistory', label:'Winner History', icon:'🏅' }
  ]
};

function buildNav() {
  const user = currentUser();
  if (!user) return;
  const nav = NAV_CONFIG[user.role] || [];
  const navEl = document.getElementById('sidebarNav');
  navEl.innerHTML = nav.map(item => {
    if (item.section) return `<div class="nav-section-label">${item.section}</div>`;
    return `<div class="nav-item" id="nav_${item.id}" onclick="navigateTo('${item.id}')">
      <span class="nav-icon">${item.icon}</span><span>${item.label}</span></div>`;
  }).join('');
  const userEl = document.getElementById('sidebarUser');
  userEl.innerHTML = `<strong>${user.name}</strong>${user.role}<br/><span style="font-size:11px;opacity:0.75">${user.email||''}</span>`;

  /* Update topbar avatar initials */
  const avatarEl = document.getElementById('topbarAvatar');
  if (avatarEl) {
    const initials = user.name.split(' ').map(w=>w[0]).slice(0,2).join('').toUpperCase();
    avatarEl.textContent = initials;
    avatarEl.title = user.name + ' (' + user.role + ')';
  }

  /* v7: Show Switch Role button if this session has more than one role */
  const sessionRoles = getSessionRoles();
  const switchBtn = document.getElementById('switchRoleBtn');
  if (switchBtn) {
    if (sessionRoles.length > 1) {
      switchBtn.style.display = 'block';
    } else {
      switchBtn.style.display = 'none';
    }
  }
}

/* v7: Switch Role — show the role picker from within the app (no re-login required) */
function switchRole() {
  const sessionRoles = getSessionRoles();
  if (!sessionRoles.length) return;
  const current = currentUser();
  const roleIcons = { 'HR Admin':'🛡️', 'Manager':'👔', 'Jury Member':'⚖️', 'Business Head':'💼' };
  const btnHtml = sessionRoles.map((u, i) => {
    const isCurrent = current && u.empId === current.empId;
    return `<button class="btn-secondary" style="width:100%;margin-bottom:10px;padding:12px 16px;text-align:left;font-size:15px;${isCurrent?'border:2px solid var(--orange);':''}"
      onclick="switchToRole(${i})">
      <span style="font-size:20px;margin-right:10px">${roleIcons[u.role]||'👤'}</span>
      <strong>${u.role}</strong>${isCurrent?' <span style="font-size:11px;opacity:0.65">(current)</span>':''}
      <span style="display:block;font-size:12px;opacity:0.65;margin-top:2px;margin-left:30px">${u.name}</span>
    </button>`;
  }).join('');
  openModal('Switch Role', `
    <div style="margin-bottom:16px">
      <p style="margin:0;font-size:13px;opacity:0.75">Select the dashboard you want to switch to. No re-login required.</p>
    </div>
    ${btnHtml}
    <div class="modal-actions" style="margin-top:8px">
      <button class="btn-secondary" onclick="closeModal()">Cancel</button>
    </div>`);
}

function switchToRole(idx) {
  const sessionRoles = getSessionRoles();
  const target = sessionRoles[idx];
  if (!target) return;
  closeModal();
  LS.set('rr_current_user', target);
  buildNav();
  navigateTo(defaultPage(target.role));
  showToast(`Switched to ${target.role} dashboard.`);
}

function navigateTo(page) {
  currentPage = page;
  document.querySelectorAll('.nav-item').forEach(el => el.classList.remove('active'));
  const activeNav = document.getElementById('nav_' + page);
  if (activeNav) activeNav.classList.add('active');
  const PAGES = {
    hrDashboard: renderHRDashboard,
    userMgmt: renderUserMgmt,
    awardAssignment: renderAwardAssignment,
    headcountMgmt: renderHeadcountMgmt,
    nominationControl: renderNominationControl,
    detailedReview: renderDetailedReview,
    winnerApproval: renderWinnerApproval,
    winnerHistory: renderWinnerHistory,
    risingStarReview: renderRisingStarReview,
    hrScoreReview: renderHRScoreReview,
    bhScoreReview: renderBHScoreReview,
    nominationTracker: renderNominationTracker,
    deletedNominations: renderDeletedNominations,
    managerDashboard: renderManagerDashboard,
    myNominations: renderMyNominations,
    juryDashboard: renderJuryDashboard,
    juryEvaluations: renderJuryEvaluations,
    bhDashboard: renderBHDashboard
  };
  const titles = {
    hrDashboard:'HR Dashboard', userMgmt:'User Management', awardAssignment:'Award Assignment',
    headcountMgmt:'Headcount Management', nominationControl:'Nomination Control',
    detailedReview:'Nomination Review', winnerApproval:'Winner Approval', winnerHistory:'Winner History',
    risingStarReview:'Rising Star Review',
    hrScoreReview:'Jury Score Review', bhScoreReview:'BH Score Review', nominationTracker:'Nomination Tracker',
    deletedNominations:'Deleted Nominations',
    managerDashboard:'My Awards', myNominations:'My Nominations',
    juryDashboard:'Jury Dashboard', juryEvaluations:'My Evaluations',
    bhDashboard:'Business Head Dashboard',
    winnerHistory:'Winner History'
  };
  document.getElementById('topbarTitle').textContent = titles[page] || page;
  const fn = PAGES[page];
  if (fn) fn();
  else document.getElementById('pageContent').innerHTML = `<div class="empty-state"><div class="empty-icon">🚧</div><p>Page not found.</p></div>`;
}

function applyGlobalFilters() { if (currentPage) navigateTo(currentPage); }
function toggleSidebar() { document.getElementById('sidebar').classList.toggle('open'); }

/* =========================================================
   MODAL HELPERS
   ========================================================= */
function openModal(title, html, wide) {
  document.getElementById('modalTitle').textContent = title;
  document.getElementById('modalBody').innerHTML = html;
  document.getElementById('modalBox').style.maxWidth = wide ? '860px' : '680px';
  document.getElementById('modalOverlay').style.display = 'flex';
}
function closeModal() { document.getElementById('modalOverlay').style.display = 'none'; }
function closeModalOnOverlay(e) { if (e.target === document.getElementById('modalOverlay')) closeModal(); }

function openConfirm(title, msg, cb) {
  document.getElementById('confirmTitle').textContent = title;
  document.getElementById('confirmMsg').textContent = msg;
  document.getElementById('confirmOverlay').style.display = 'flex';
  document.getElementById('confirmYes').onclick = () => { closeConfirm(); cb(); };
}
function closeConfirm() { document.getElementById('confirmOverlay').style.display = 'none'; }

function showToast(msg, type='success') {
  const t = document.getElementById('toast');
  t.textContent = msg;
  t.className = 'toast ' + type;
  t.style.display = 'block';
  setTimeout(() => { t.style.display='none'; }, 3200);
}

/* =========================================================
   HR DASHBOARD
   ========================================================= */
function renderHRDashboard() {
  const fy = getFY(); const q = getQ();
  const noms = getNominations().filter(n => n.fy===fy && n.quarter===q);
  const pending_eval = noms.filter(n => n.status==='Jury Review' || n.status==='BH Review').length;
  const pending_appr = noms.filter(n => n.status==='HR Review').length;
  const winners = getWinners().filter(w => w.fy===fy && w.quarter===q);
  const recentWinners = getWinners().slice(-6).reverse();
  document.getElementById('pageContent').innerHTML = `
    <div class="stats-grid">
      <div class="stat-card"><div class="stat-icon">📝</div><div><div class="stat-value">${noms.length}</div><div class="stat-label">Total Nominations</div></div></div>
      <div class="stat-card blue"><div class="stat-icon">⏳</div><div><div class="stat-value">${pending_eval}</div><div class="stat-label">Pending Evaluations</div></div></div>
      <div class="stat-card yellow"><div class="stat-icon">🔔</div><div><div class="stat-value">${pending_appr}</div><div class="stat-label">Pending Approvals</div></div></div>
      <div class="stat-card green"><div class="stat-icon">🏅</div><div><div class="stat-value">${winners.length}</div><div class="stat-label">Approved Winners</div></div></div>
    </div>
    <div class="section-card">
      <div class="section-card-header"><h3>Recent Nominations – ${fy} ${q}</h3></div>
      <div class="section-card-body">
        <div class="table-wrapper">
          <table>
            <thead><tr><th>Nominee</th><th>Award</th><th>Manager</th><th>Status</th><th>Date</th></tr></thead>
            <tbody>
              ${noms.length ? noms.map(n => {
                const award = AWARD_LIST.find(a=>a.id===n.awardId);
                return `<tr>
                  <td><strong>${n.nomineeName}</strong><br/><span class="text-muted text-sm">${n.empId}</span></td>
                  <td>${award?award.name:'—'}</td>
                  <td>${n.managerName}</td>
                  <td>${statusBadge(n.status)}</td>
                  <td>${n.submittedAt}</td>
                </tr>`;
              }).join('') : `<tr><td colspan="5">
                <div class="empty-state">
                  <div style="font-size:60px;margin-bottom:16px">📭</div>
                  <p>No nominations for this period.</p>
                  <div class="empty-sub">Looks like things are quiet for now. Check back later for updates.</div>
                </div>
              </td></tr>`}
            </tbody>
          </table>
        </div>
      </div>
    </div>
    <div class="section-card" style="margin-top:24px">
      <div class="section-card-header">
        <div class="prev-winners-header">
          <div class="prev-winners-icon">🏅</div>
          <div>
            <div class="prev-winners-title">Previous Winners</div>
            <div class="prev-winners-sub">Celebrate the achievements of our amazing winners.</div>
          </div>
        </div>
        <button class="btn-secondary btn-sm" onclick="navigateTo('winnerHistory')">View Full History →</button>
      </div>
      <div class="section-card-body">
        ${recentWinners.length ? `<div class="table-wrapper"><table>
          <thead><tr><th>Financial Year</th><th>Quarter</th><th>Award</th><th>Winner</th></tr></thead>
          <tbody>${recentWinners.map(w=>`<tr>
            <td>${w.fy}</td><td><span class="badge badge-blue">${qDisplay(w.quarter)}</span></td>
            <td>${w.awardName}</td>
            <td><div class="winner-name-cell"><span class="winner-trophy">🏆</span><strong>${w.winnerName}</strong></div></td>
          </tr>`).join('')}</tbody>
        </table></div>`
        : `<div class="empty-state"><div class="empty-icon">🏅</div><p>No winners recorded yet.</p><div class="empty-sub">Approved winners will appear here.</div></div>`}
      </div>
    </div>
    ${renderDemoCleanupCard()}`;
}

/* CHANGE 6: Demo Data Cleanup card shown on HR Dashboard */
function renderDemoCleanupCard() {
  const demoUsers   = getUsers().filter(u => u.isDemo).length;
  const demoNoms    = getNominations().filter(n => n.isDemo).length;
  const demoWinners = getWinners().filter(w => w.isDemo).length;
  const demoHC      = getHeadcounts().filter(h => h.isDemo).length;
  const demoAsgn    = getAssignments().filter(a => a.isDemo).length;
  const total = demoUsers + demoNoms + demoWinners + demoHC + demoAsgn;
  if (total === 0) return '';
  return `
    <div class="section-card" style="margin-top:24px;border:2px dashed var(--orange)">
      <div class="section-card-header">
        <h3>🧹 Demo Data Detected</h3>
        <button class="btn-danger btn-sm" onclick="confirmRemoveDemoData()">Remove All Demo Data</button>
      </div>
      <div class="section-card-body">
        <div class="info-alert orange">
          The portal contains <strong>${total} demo/sample records</strong> that were pre-loaded for demonstration.
          Use the button above to safely remove only these records. Your uploaded real data will not be touched.
        </div>
        <div class="csv-stat-grid" style="margin-top:12px">
          <div class="csv-stat ok"><div class="csv-stat-num">${demoUsers}</div><div class="csv-stat-lbl">Demo Users</div></div>
          <div class="csv-stat ok"><div class="csv-stat-num">${demoAsgn}</div><div class="csv-stat-lbl">Demo Assignments</div></div>
          <div class="csv-stat ok"><div class="csv-stat-num">${demoNoms}</div><div class="csv-stat-lbl">Demo Nominations</div></div>
          <div class="csv-stat ok"><div class="csv-stat-num">${demoWinners}</div><div class="csv-stat-lbl">Demo Winners</div></div>
          <div class="csv-stat ok"><div class="csv-stat-num">${demoHC}</div><div class="csv-stat-lbl">Demo Headcounts</div></div>
        </div>
        <p class="text-muted" style="font-size:12px;margin-top:12px">
          ✅ Only records tagged <code>isDemo: true</code> will be removed.<br/>
          ✅ No LocalStorage reset. ✅ No user-uploaded data will be deleted.
        </p>
      </div>
    </div>`;
}

function confirmRemoveDemoData() {
  openConfirm(
    'Remove Demo Data',
    'This will permanently delete all demo/sample records (isDemo: true). Your real uploaded data is safe. Continue?',
    () => {
      backfillDemoFlags();
      removeDemoRecords();
      showToast('Demo data removed. Only your real data remains.');
      renderHRDashboard();
    }
  );
}

function statusBadge(s) {
  const map = {
    'Jury Review':'badge-blue','BH Review':'badge-yellow','HR Review':'badge-orange',
    'Approved':'badge-green','Rejected':'badge-red','Submitted':'badge-gray'
  };
  return `<span class="badge ${map[s]||'badge-gray'}">${s}</span>`;
}

/* =========================================================
   USER MANAGEMENT
   ========================================================= */
const MAX_USERS = 200;   /* Change 3: system-wide user cap */

function renderUserMgmt() {
  const users = getUsers();
  const atLimit = users.length >= MAX_USERS;
  document.getElementById('pageContent').innerHTML = `
    <div class="section-card">
      <div class="section-card-header">
        <h3>All Users (${users.length} / ${MAX_USERS})</h3>
        <div style="display:flex;gap:8px;flex-wrap:wrap;align-items:center;">
          <button class="btn-secondary btn-sm" onclick="openManagerCSVUpload()">📤 Upload Manager CSV</button>
          <button class="btn-secondary btn-sm" onclick="openAssignJuryAccess()">⚖️ Assign Jury Access</button>
          <button class="btn-secondary btn-sm" onclick="openAssignBHAccess()">💼 Assign BH Access</button>
          <button class="btn-primary btn-sm" onclick="openUserForm()">+ Create User</button>
        </div>
      </div>
      ${atLimit ? `<div class="user-limit-warning">⚠️ User limit reached (${MAX_USERS} max). Remove or deactivate users before adding more.</div>` : ''}
      <div class="section-card-body">
        <div class="search-bar-wrap">
          <input type="text" id="userSearch" placeholder="Search by name, role or email…" oninput="filterUserTable()" />
        </div>
        <div class="table-wrapper">
          <table id="userTable">
            <thead><tr><th>Name</th><th>Role(s)</th><th>Email</th><th>Eligible Teams</th><th>Status</th><th>Actions</th></tr></thead>
            <tbody id="userTableBody"></tbody>
          </table>
        </div>
      </div>
    </div>`;
  renderUserTableBody(users);
}

/* Change 3 + Change 5: Group users by email so dual-role people appear on one row
   with both role badges shown. All action buttons now use permanent userId, never
   array index or empId, so sorting/filtering cannot affect which user is edited. */
function renderUserTableBody(users) {
  const tbody = document.getElementById('userTableBody');
  if (!tbody) return;

  /* Group by email to surface multi-role users clearly */
  const byEmail = {};
  users.forEach(u => {
    const key = (u.email || u.userId || u.empId).toLowerCase();
    if (!byEmail[key]) byEmail[key] = [];
    byEmail[key].push(u);
  });

  const rows = [];
  Object.values(byEmail).forEach(group => {
    group.forEach((u, idx) => {
      const teamsHtml = (u.role === 'Manager' && u.eligibleTeams && u.eligibleTeams.length)
        ? u.eligibleTeams.map(t => `<span class="team-tag">${t}</span>`).join(' ')
        : '<span class="text-muted">—</span>';

      const dualBadge = group.length > 1
        ? `<span class="badge badge-orange" style="font-size:10px;margin-left:4px" title="This person has ${group.length} roles">Multi-Role</span>`
        : '';

      /* Change 3: Use u.userId as the stable key for all operations */
      const uid = u.userId || u.empId; /* fallback to empId for old records not yet backfilled */

      rows.push(`
      <tr>
        <td>${u.name}${idx === 0 ? dualBadge : ''}</td>
        <td><span class="badge badge-blue">${u.role}</span></td>
        <td>${u.email||'—'}</td>
        <td>${teamsHtml}</td>
        <td>${u.active ? '<span class="badge badge-green">Active</span>' : '<span class="badge badge-red">Inactive</span>'}</td>
        <td>
          <button class="btn-secondary btn-sm" onclick="openUserForm('${uid}')">Edit</button>
          <button class="btn-danger btn-sm" style="margin-left:6px" onclick="toggleUserActive('${uid}')">${u.active?'Deactivate':'Activate'}</button>
          ${u.role === 'Jury Member' ? `<button class="btn-danger btn-sm" style="margin-left:6px" onclick="removeJuryAccess('${uid}')">Remove Jury</button>` : ''}
          ${u.role === 'Business Head' ? `<button class="btn-danger btn-sm" style="margin-left:6px" onclick="removeBHAccess('${uid}')">Remove BH</button>` : ''}
        </td>
      </tr>`);
    });
  });
  tbody.innerHTML = rows.join('');
}

function filterUserTable() {
  const q = document.getElementById('userSearch').value.toLowerCase();
  const users = getUsers().filter(u =>
    u.name.toLowerCase().includes(q) ||
    u.role.toLowerCase().includes(q) ||
    (u.email||'').toLowerCase().includes(q)
  );
  renderUserTableBody(users);
}

/* CHANGE 5: Assign Jury Access to an existing user (any role).
   HR enters the person's email + sets a Jury password.
   A new Jury Member record is created with the same email.
   The Manager (or other) record is NOT touched. */
function openAssignJuryAccess() {
  openModal('Assign Jury Access', `
    <div class="info-alert blue">
      <strong>Jury Access — Multi-Role</strong><br/>
      This creates a <strong>Jury Member</strong> account for an existing person.
      The same email can then log in as Manager (email tab) <em>and</em> as Jury Member (password tab).
    </div>
    <div class="form-row">
      <div class="form-group"><label>Full Name</label>
        <input id="jaName" type="text" placeholder="Full name of the person"/>
      </div>
      <div class="form-group"><label>Email ID</label>
        <input id="jaEmail" type="email" placeholder="Same email as their Manager account"/>
      </div>
    </div>
    <div class="form-group"><label>Jury Password</label>
      <input id="jaPwd" type="password" placeholder="Set a password for jury access"/>
    </div>
    <p class="text-muted" style="font-size:12px;margin-top:-8px">
      HR assigns this password. The person will use it to log in on the HR / Jury tab.
    </p>
    <div class="modal-actions">
      <button class="btn-primary" onclick="saveJuryAccess()">Assign Jury Access</button>
      <button class="btn-secondary" onclick="closeModal()">Cancel</button>
    </div>`);
}

function saveJuryAccess() {
  const name  = document.getElementById('jaName').value.trim();
  const email = document.getElementById('jaEmail').value.trim().toLowerCase();
  const pwd   = document.getElementById('jaPwd').value.trim();
  if (!name || !email || !pwd) {
    showToast('Name, Email, and Jury Password are all required.', 'error');
    return;
  }
  const users = getUsers();
  if (users.length >= MAX_USERS) {
    showToast(`User limit of ${MAX_USERS} reached. Cannot add more users.`, 'error');
    return;
  }
  /* Check this exact email is not already a Jury Member */
  const alreadyJury = users.find(u => u.role === 'Jury Member' && (u.email||'').toLowerCase() === email);
  if (alreadyJury) {
    showToast(`${email} already has a Jury Member account.`, 'error');
    return;
  }
  const empId  = generateInternalUserId('Jury Member');
  const userId = generateUserId();
  users.push({ userId, empId, name, role:'Jury Member', email, password:pwd, active:true });
  setUsers(users);
  closeModal();
  showToast(`Jury access granted to ${name}.`);
  renderUserMgmt();
}

/* CHANGE 5: Remove Jury access from a person without affecting their other roles */
function removeJuryAccess(userId) {
  const users = getUsers();
  /* Change 3: look up by userId */
  const u = users.find(u => (u.userId === userId || u.empId === userId) && u.role === 'Jury Member');
  if (!u) return;
  openConfirm(
    'Remove Jury Access',
    `Remove Jury Member access for ${u.name} (${u.email})? Their other role accounts (e.g. Manager) will not be affected.`,
    () => {
      const assignments = getAssignments().filter(a => !(a.role === 'Jury' && a.empId === u.empId));
      setAssignments(assignments);
      setUsers(users.filter(x => x.userId !== u.userId));
      showToast(`Jury access removed for ${u.name}.`);
      renderUserMgmt();
    }
  );
}

/* v7: Assign Business Head Access to an existing person */
function openAssignBHAccess() {
  openModal('Assign Business Head Access', `
    <div class="info-alert blue">
      <strong>Business Head Access — Multi-Role</strong><br/>
      This creates a <strong>Business Head</strong> account for an existing person.
      The same email can then log in as Manager (email tab) <em>and/or</em> as Business Head (password tab).
    </div>
    <div class="form-row">
      <div class="form-group"><label>Full Name</label>
        <input id="bhName" type="text" placeholder="Full name of the person"/>
      </div>
      <div class="form-group"><label>Email ID</label>
        <input id="bhEmail" type="email" placeholder="Same email as their Manager account"/>
      </div>
    </div>
    <div class="form-group"><label>Business Head Password</label>
      <input id="bhPwd" type="password" placeholder="Set a password for BH access"/>
    </div>
    <p class="text-muted" style="font-size:12px;margin-top:-8px">
      HR assigns this password. The person will use it to log in on the HR / Jury / BH tab.
    </p>
    <div class="modal-actions">
      <button class="btn-primary" onclick="saveAssignBHAccess()">Assign BH Access</button>
      <button class="btn-secondary" onclick="closeModal()">Cancel</button>
    </div>`);
}

function saveAssignBHAccess() {
  const name  = document.getElementById('bhName').value.trim();
  const email = document.getElementById('bhEmail').value.trim().toLowerCase();
  const pwd   = document.getElementById('bhPwd').value.trim();
  if (!name || !email || !pwd) {
    showToast('Name, Email, and Business Head Password are all required.', 'error');
    return;
  }
  const users = getUsers();
  if (users.length >= MAX_USERS) {
    showToast(`User limit of ${MAX_USERS} reached. Cannot add more users.`, 'error');
    return;
  }
  /* Block duplicate BH record for same email */
  const alreadyBH = users.find(u => u.role === 'Business Head' && (u.email||'').toLowerCase() === email);
  if (alreadyBH) {
    showToast(`${email} already has a Business Head account.`, 'error');
    return;
  }
  const empId  = generateInternalUserId('Business Head');
  const userId = generateUserId();
  users.push({ userId, empId, name, role:'Business Head', email, password:pwd, active:true });
  setUsers(users);
  closeModal();
  showToast(`Business Head access granted to ${name}.`);
  renderUserMgmt();
}

/* v7: Remove Business Head access without affecting other roles */
function removeBHAccess(userId) {
  const users = getUsers();
  /* Change 3: look up by userId */
  const u = users.find(u => (u.userId === userId || u.empId === userId) && u.role === 'Business Head');
  if (!u) return;
  openConfirm(
    'Remove Business Head Access',
    `Remove Business Head access for ${u.name} (${u.email})? Their other role accounts (e.g. Manager, Jury) will not be affected.`,
    () => {
      const assignments = getAssignments().filter(a => !(a.role === 'BusinessHead' && a.empId === u.empId));
      setAssignments(assignments);
      setUsers(users.filter(x => x.userId !== u.userId));
      showToast(`Business Head access removed for ${u.name}.`);
      renderUserMgmt();
    }
  );
}

function openUserForm(userId) {
  const users = getUsers();
  /* Change 3: Always look up by permanent userId — never by array index or empId */
  const existing = userId ? users.find(u => u.userId === userId) : null;
  const title = existing ? 'Edit User' : 'Create User';
  const roles = ['HR Admin','Manager','Jury Member','Business Head'];

  /* For managers, show eligible teams multi-select */
  const teamsSection = `
    <div class="form-group" id="teamsGroup" style="${existing && existing.role==='Manager' ? '' : 'display:none'}">
      <label>Eligible Teams <span class="text-muted" style="font-weight:400;text-transform:none">(hold Ctrl / ⌘ to select multiple)</span></label>
      <select id="uTeams" multiple style="min-height:130px;">
        ${CLUSTERS.filter(c=>c!=='Other').map(c => {
          const sel = existing && existing.eligibleTeams && existing.eligibleTeams.includes(c) ? 'selected' : '';
          return `<option value="${c}" ${sel}>${c}</option>`;
        }).join('')}
      </select>
    </div>`;

  const currentRole = existing ? existing.role : 'HR Admin';
  const pwdLabel = currentRole === 'Jury Member' ? 'Jury Password' : currentRole === 'Business Head' ? 'Business Head Password' : 'Password';
  const pwdNote  = currentRole === 'Manager' ? '<p class="text-muted" style="font-size:12px;margin-top:-8px">Managers log in by email only — no password required.</p>' : '';
  const pwdDisplay = currentRole === 'Manager' ? 'none' : '';

  /* Change 3: Employee ID removed from user creation/edit. userId stored as data-attribute, never shown */
  openModal(title, `
    <div class="form-row">
      <div class="form-group"><label>Full Name</label>
        <input id="uName" type="text" value="${existing?existing.name:''}" placeholder="Full name"/>
      </div>
      <div class="form-group"><label>Email ID</label>
        <input id="uEmail" type="email" value="${existing?existing.email:''}" placeholder="email@hclhealthcare.com"/>
      </div>
    </div>
    <div class="form-row">
      <div class="form-group"><label>Role</label>
        <select id="uRole" onchange="toggleUserFormFields()">${roles.map(r=>`<option ${existing&&existing.role===r?'selected':''}>${r}</option>`).join('')}</select>
      </div>
      <div class="form-group"><label>Status</label>
        <select id="uStatus">
          <option value="active" ${(!existing || existing.active) ? 'selected':''}>Active</option>
          <option value="inactive" ${(existing && !existing.active) ? 'selected':''}>Inactive</option>
        </select>
      </div>
    </div>
    <div class="form-group" id="pwdGroup" style="${pwdDisplay}"><label id="pwdLabel">${pwdLabel}</label>
      <input id="uPwd" type="password" placeholder="${existing?'Leave blank to keep current':'Set password'}"/>
      ${pwdNote}
    </div>
    ${teamsSection}
    <div class="modal-actions">
      <button class="btn-primary" onclick="saveUser('${existing?existing.userId:''}')">Save User</button>
      <button class="btn-secondary" onclick="closeModal()">Cancel</button>
    </div>`);
}

function toggleUserFormFields() {
  const role = document.getElementById('uRole').value;
  const tg = document.getElementById('teamsGroup');
  const pg = document.getElementById('pwdGroup');
  const pl = document.getElementById('pwdLabel');
  if (tg) tg.style.display = role === 'Manager' ? '' : 'none';
  if (pg) pg.style.display = role === 'Manager' ? 'none' : '';
  if (pl) {
    if (role === 'Jury Member') pl.textContent = 'Jury Password';
    else if (role === 'Business Head') pl.textContent = 'Business Head Password';
    else pl.textContent = 'Password';
  }
}

/* Change 3: Auto-generates an internal system ID for a new user.
   Every user also receives a permanent userId (UUID-like) that is
   used as the primary key for Edit/Update/Delete/Search operations.
   empId is kept for backward compatibility but is never used as a key. */
function generateInternalUserId(role) {
  const prefixMap = { 'HR Admin':'HR', 'Manager':'MGR', 'Jury Member':'JRY', 'Business Head':'BH' };
  const prefix = prefixMap[role] || 'USR';
  return prefix + String(Date.now()).slice(-5) + String(Math.floor(Math.random()*900)+100);
}

function generateUserId() {
  return 'UID' + Date.now() + Math.random().toString(36).slice(2, 8);
}

function saveUser(editUserId) {
  const name   = document.getElementById('uName').value.trim();
  const role   = document.getElementById('uRole').value;
  const email  = document.getElementById('uEmail').value.trim();
  const status = document.getElementById('uStatus').value;
  const pwd    = document.getElementById('uPwd').value.trim();
  if (!name||!email) { showToast('Name and Email ID are required.','error'); return; }

  const users = getUsers();

  /* Change 3: enforce cap on NEW users only */
  if (!editUserId && users.length >= MAX_USERS) {
    showToast(`User limit of ${MAX_USERS} reached. Cannot add more users.`,'error');
    return;
  }

  /* Collect eligible teams if Manager */
  let eligibleTeams = [];
  const teamsEl = document.getElementById('uTeams');
  if (role === 'Manager' && teamsEl) {
    eligibleTeams = Array.from(teamsEl.selectedOptions).map(o => o.value);
  }

  if (editUserId) {
    /* Change 3: Look up by userId — completely immune to sort/filter order */
    const i = users.findIndex(u => u.userId === editUserId);
    if (i > -1) {
      users[i].name   = name;
      users[i].role   = role;
      users[i].email  = email;
      users[i].active = status === 'active';
      if (pwd) users[i].password = pwd;
      if (role === 'Manager') users[i].eligibleTeams = eligibleTeams;
    } else {
      showToast('User not found. Please refresh and try again.', 'error');
      return;
    }
  } else {
    /* CHANGE 5: Allow same email across DIFFERENT roles (multi-role).
       Only block if the same email+role combination already exists. */
    const duplicate = users.find(u =>
      (u.email||'').toLowerCase() === email.toLowerCase() &&
      u.role === role
    );
    if (duplicate) {
      showToast(`A ${role} account with this email already exists.`, 'error');
      return;
    }
    const empId  = generateInternalUserId(role);
    const userId = generateUserId();
    const newUser = { userId, empId, name, role, email, active: status === 'active' };
    if (role === 'Manager') {
      newUser.eligibleTeams = eligibleTeams;
    } else {
      newUser.password = pwd || 'pass@123';
    }
    users.push(newUser);
  }
  setUsers(users);
  closeModal();
  showToast(editUserId?'User updated.':'User created.');
  renderUserMgmt();
}

function toggleUserActive(userId) {
  const users = getUsers();
  /* Change 3: Look up by permanent userId */
  const u = users.find(u => u.userId === userId);
  if (!u) return;
  const action = u.active ? 'deactivate' : 'activate';
  openConfirm('Confirm', `Are you sure you want to ${action} user ${u.name}?`, () => {
    u.active = !u.active;
    setUsers(users);
    showToast(`User ${u.active?'activated':'deactivated'}.`);
    renderUserMgmt();
  });
}

/* =========================================================
   BULK MANAGER CSV UPLOAD  (Change 1 + Change 2)
   Expected CSV columns (comma-separated, first row = header):
     Manager Name, Email ID, Team
   Team → the team name the manager belongs to (from the Teams list).
   Award eligibility comes entirely from Team-Award mapping.
   "Assigned Awards" column is no longer needed and will be ignored if present.
   ========================================================= */
let _csvPendingManagers = [];  /* holds parsed rows before commit */

function openManagerCSVUpload() {
  _csvPendingManagers = [];
  openModal('Upload Manager CSV', `
    <div class="info-alert blue">
      <strong>CSV Format (first row = header, columns comma-separated):</strong><br/>
      <code>Manager Name, Email ID, Team</code><br/>
      • <strong>Team</strong> must exactly match a team name in the system (e.g. <em>Human Resources, L&amp;D, Admin</em>).<br/>
      • Multiple teams: use semicolons inside the Team field (e.g. <em>Finance;Care Plan</em>).<br/>
      • Award eligibility is determined automatically by the Team's award assignments.<br/>
      • Duplicate emails will be skipped automatically.<br/>
      • Maximum <strong>${MAX_USERS}</strong> total users allowed in the system.
    </div>

    <div class="csv-drop-zone" id="csvDropZone"
         onclick="document.getElementById('csvFileInput').click()"
         ondragover="event.preventDefault();this.classList.add('drag-over')"
         ondragleave="this.classList.remove('drag-over')"
         ondrop="handleCsvDrop(event)">
      <div style="font-size:36px;margin-bottom:8px;">📄</div>
      <p><strong>Click to choose a CSV file</strong> or drag &amp; drop here</p>
      <p class="text-muted text-sm" style="margin-top:4px;">Accepts .csv files only</p>
      <input type="file" id="csvFileInput" accept=".csv" style="display:none"
             onchange="handleCsvFileSelect(this)"/>
    </div>

    <div id="csvSummary" style="display:none">
      <div class="csv-summary-grid" id="csvSummaryGrid"></div>
      <div class="table-wrapper" style="max-height:260px;overflow-y:auto;margin-top:12px;">
        <table>
          <thead><tr><th>#</th><th>Name</th><th>Email</th><th>Teams</th><th>Result</th></tr></thead>
          <tbody id="csvPreviewBody"></tbody>
        </table>
      </div>
    </div>

    <div class="modal-actions" style="margin-top:18px;">
      <button class="btn-primary" id="csvConfirmBtn" style="display:none" onclick="commitCsvManagers()">✔ Add Managers</button>
      <button class="btn-secondary" onclick="closeModal()">Cancel</button>
    </div>`, true);
}

function handleCsvDrop(e) {
  e.preventDefault();
  document.getElementById('csvDropZone').classList.remove('drag-over');
  const file = e.dataTransfer.files[0];
  if (file) parseCsvFile(file);
}

function handleCsvFileSelect(input) {
  const file = input.files[0];
  if (file) parseCsvFile(file);
}

function parseCsvFile(file) {
  if (!file.name.toLowerCase().endsWith('.csv')) {
    showToast('Please upload a .csv file.','error'); return;
  }
  const reader = new FileReader();
  reader.onload = e => processCsvText(e.target.result);
  reader.readAsText(file);
}

function processCsvText(text) {
  const lines = text.split(/\r?\n/).map(l=>l.trim()).filter(l=>l);
  if (!lines.length) { showToast('CSV file is empty.','error'); return; }

  /* Strip header row if present */
  const firstLower = lines[0].toLowerCase();
  const startIdx = (firstLower.includes('manager name') || firstLower.includes('email')) ? 1 : 0;
  const dataLines = lines.slice(startIdx);

  const existingUsers  = getUsers();
  const existingEmails = new Set(existingUsers.map(u=>(u.email||'').toLowerCase()));
  const seenEmails     = new Set();
  const currentCount   = existingUsers.length;
  const slotsLeft      = MAX_USERS - currentCount;

  _csvPendingManagers = [];
  const previewRows   = [];
  let okCount = 0, dupCount = 0, failCount = 0, skippedLimit = 0;

  dataLines.forEach((line, idx) => {
    /* Simple CSV split — handles unquoted fields */
    const cols = line.split(',').map(c=>c.trim().replace(/^"|"$/g,''));
    /* Change 1: CSV format is now: Manager Name, Email ID, Team
       For backward compatibility with old 4-column format (Name, Email, Awards, Teams),
       detect if col[2] looks like an award name and use col[3] as teams in that case. */
    const [rawName='', rawEmail='', col2='', col3=''] = cols;
    const name  = rawName.trim();
    const email = rawEmail.trim().toLowerCase();
    const col2IsAward = col2.toLowerCase().includes('award') ||
                        AWARD_LIST.some(a => a.name.toLowerCase() === col2.toLowerCase() || a.id === col2);
    const rawTeams = col2IsAward ? col3 : col2;

    /* Validate */
    if (!name || !email || !email.includes('@')) {
      failCount++;
      previewRows.push({ idx:idx+startIdx+1, name:name||'(empty)', email:email||'(empty)', teams:'', result:'fail', reason:'Missing name or invalid email' });
      return;
    }
    if (existingEmails.has(email) || seenEmails.has(email)) {
      dupCount++;
      previewRows.push({ idx:idx+startIdx+1, name, email, teams:'', result:'dup', reason:'Duplicate email' });
      return;
    }
    if (_csvPendingManagers.length >= slotsLeft) {
      skippedLimit++;
      previewRows.push({ idx:idx+startIdx+1, name, email, teams:'', result:'limit', reason:'User limit reached' });
      return;
    }

    /* Parse teams — validate against known CLUSTERS; remap obsolete names */
    const eligibleTeams = rawTeams
      ? rawTeams.split(';').map(t => t.trim())
          .filter(t => {
            if (!t) return false;
            if (t === NV_CORP_OBSOLETE) return true;
            return CLUSTERS.includes(t);
          })
          .map(t => t === NV_CORP_OBSOLETE ? NV_CORP_CANONICAL : t)
      : [];
    const uniqueTeams = [...new Set(eligibleTeams)];

    /* Auto-generate a unique empId and permanent userId */
    const empId  = 'MGR' + String(Date.now()).slice(-5) + String(Math.floor(Math.random()*900)+100);
    const userId = generateUserId();
    seenEmails.add(email);
    _csvPendingManagers.push({ userId, empId, name, role:'Manager', email, active:true, eligibleTeams: uniqueTeams });
    okCount++;
    previewRows.push({ idx:idx+startIdx+1, name, email, teams:uniqueTeams.join(', ')||'—', result:'ok', reason:'' });
  });

  /* Render summary */
  const limitWarning = (skippedLimit > 0 || (currentCount + okCount) >= MAX_USERS)
    ? `<div class="user-limit-warning" style="margin-bottom:12px;">⚠️ System is at or near the ${MAX_USERS}-user limit. ${skippedLimit} row(s) skipped.</div>`
    : '';

  document.getElementById('csvSummary').style.display = '';
  document.getElementById('csvSummaryGrid').innerHTML = limitWarning + `
    <div class="csv-stat-grid">
      <div class="csv-stat ok"><div class="csv-stat-num">${okCount}</div><div class="csv-stat-lbl">Ready to Upload</div></div>
      <div class="csv-stat dup"><div class="csv-stat-num">${dupCount}</div><div class="csv-stat-lbl">Duplicates Skipped</div></div>
      <div class="csv-stat fail"><div class="csv-stat-num">${failCount + skippedLimit}</div><div class="csv-stat-lbl">Failed / Skipped</div></div>
    </div>`;

  const badgeMap = { ok:'badge-green', dup:'badge-yellow', fail:'badge-red', limit:'badge-red' };
  const labelMap = { ok:'✓ Ready', dup:'Duplicate', fail:'Failed', limit:'Limit' };
  document.getElementById('csvPreviewBody').innerHTML = previewRows.map(r=>`
    <tr>
      <td>${r.idx}</td>
      <td>${r.name}</td>
      <td>${r.email}</td>
      <td style="font-size:11px">${r.teams}</td>
      <td><span class="badge ${badgeMap[r.result]||'badge-gray'}">${labelMap[r.result]||r.result}</span>${r.reason?`<br/><span class="text-muted text-sm">${r.reason}</span>`:''}</td>
    </tr>`).join('');

  document.getElementById('csvConfirmBtn').style.display = okCount > 0 ? '' : 'none';
}

function commitCsvManagers() {
  if (!_csvPendingManagers.length) { showToast('Nothing to upload.','error'); return; }
  const users = getUsers();
  _csvPendingManagers.forEach(m => users.push(m));
  setUsers(users);
  const count = _csvPendingManagers.length;
  _csvPendingManagers = [];
  closeModal();
  showToast(`${count} manager(s) uploaded successfully.`);
  renderUserMgmt();
}

/* =========================================================
   AWARD ASSIGNMENT  (Change 1: Assign Awards to Teams, not individual Managers)
   HR assigns awards to Teams. Managers automatically see all awards
   assigned to their Team(s). Individual Manager-award assignments
   are no longer created here; existing ones are preserved in
   rr_assignments for Jury and BusinessHead roles.
   ========================================================= */
function renderAwardAssignment() {
  const teamAwards = getTeamAwards();
  const allTeams   = CLUSTERS.filter(c => c !== 'Other');

  /* Show migration report if present */
  const migReport = LS.get('rr_migration_report');
  const migCard = migReport && migReport.unmigrated && migReport.unmigrated.length ? `
    <div class="section-card" style="margin-top:20px;border:2px dashed var(--orange)">
      <div class="section-card-header">
        <h3>⚠️ Migration Report — Manual Review Required</h3>
        <button class="btn-secondary btn-sm" onclick="dismissMigReport()">Dismiss</button>
      </div>
      <div class="section-card-body">
        <div class="info-alert orange">
          The following ${migReport.unmigrated.length} award assignment(s) could not be automatically migrated
          to team-based assignments because the manager had no team assigned. Please review and assign them manually.
        </div>
        <div class="table-wrapper" style="margin-top:12px">
          <table>
            <thead><tr><th>Manager Name</th><th>Manager ID</th><th>Award ID</th><th>Reason</th></tr></thead>
            <tbody>
              ${migReport.unmigrated.map(r => `<tr>
                <td>${r.name||'—'}</td>
                <td><code>${r.empId||'—'}</code></td>
                <td><code>${r.awardId||'—'}</code></td>
                <td class="text-muted">${r.reason}</td>
              </tr>`).join('')}
            </tbody>
          </table>
        </div>
      </div>
    </div>` : '';

  /* Also show Jury + BH assignments (unchanged) */
  const assignments = getAssignments();
  const users = getUsers();
  const nonMgrAssignments = assignments.filter(a => a.role !== 'Manager');

  document.getElementById('pageContent').innerHTML = `
    <div class="section-card">
      <div class="section-card-header">
        <h3>Assign Awards to Teams</h3>
        <button class="btn-primary btn-sm" onclick="openTeamAwardForm()">+ Assign Awards to Team</button>
      </div>
      <div class="section-card-body">
        <div class="info-alert blue" style="margin-bottom:14px;">
          Awards are assigned to <strong>Teams</strong>. Every Manager belonging to a Team automatically
          sees all Awards assigned to their Team. No individual Manager assignment is needed.
        </div>
        <div class="table-wrapper">
          <table>
            <thead><tr><th>Team Name</th><th>Assigned Awards</th><th>Actions</th></tr></thead>
            <tbody>
              ${allTeams.map(team => {
                const entry  = teamAwards.find(t => t.team === team);
                const ids    = entry ? entry.awardIds : [];
                const names  = ids.map(id => {
                  const a = AWARD_LIST.find(x => x.id === id);
                  return a ? `<span class="team-tag">${a.name}</span>` : '';
                }).filter(Boolean).join(' ');
                return `<tr>
                  <td><strong>${team}</strong></td>
                  <td>${names || '<span class="text-muted">No awards assigned</span>'}</td>
                  <td>
                    <button class="btn-secondary btn-sm" onclick="openTeamAwardForm('${team.replace(/'/g,"\\'")}')">Edit</button>
                    ${ids.length ? `<button class="btn-danger btn-sm" style="margin-left:6px" onclick="clearTeamAwards('${team.replace(/'/g,"\\'")}')">Clear</button>` : ''}
                  </td>
                </tr>`;
              }).join('')}
            </tbody>
          </table>
        </div>
      </div>
    </div>

    ${nonMgrAssignments.length ? `
    <div class="section-card" style="margin-top:20px">
      <div class="section-card-header">
        <h3>Jury &amp; Business Head Assignments</h3>
        <button class="btn-primary btn-sm" onclick="openAssignForm()">+ Add Jury / BH Assignment</button>
      </div>
      <div class="section-card-body">
        <div class="table-wrapper">
          <table>
            <thead><tr><th>Award</th><th>Role</th><th>Assigned To</th><th>Action</th></tr></thead>
            <tbody>
              ${nonMgrAssignments.map((a, i) => {
                const award = AWARD_LIST.find(aw => aw.id === a.awardId);
                const user  = users.find(u => u.empId === a.empId);
                const realIdx = assignments.indexOf(a);
                return `<tr>
                  <td>${award?award.name:'Unknown'}</td>
                  <td><span class="badge badge-blue">${a.role}</span></td>
                  <td>${user?user.name:'Unknown User'}<br/><span class="text-muted text-sm">${user?(user.email||''):''}</span></td>
                  <td><button class="btn-danger btn-sm" onclick="removeAssignment(${realIdx})">Remove</button></td>
                </tr>`;
              }).join('')}
            </tbody>
          </table>
        </div>
      </div>
    </div>` : `
    <div class="section-card" style="margin-top:20px">
      <div class="section-card-header">
        <h3>Jury &amp; Business Head Assignments</h3>
        <button class="btn-primary btn-sm" onclick="openAssignForm()">+ Add Jury / BH Assignment</button>
      </div>
      <div class="section-card-body">
        <div class="empty-state"><div class="empty-icon">⚖️</div><p>No Jury or Business Head assignments yet.</p></div>
      </div>
    </div>`}

    ${migCard}`;
}

function openTeamAwardForm(team) {
  const teamAwards = getTeamAwards();
  const allTeams   = CLUSTERS.filter(c => c !== 'Other');
  const existing   = team ? teamAwards.find(t => t.team === team) : null;
  const assignedIds = existing ? existing.awardIds : [];

  openModal(team ? `Edit Awards for Team` : 'Assign Awards to Team', `
    <div class="form-group"><label>Team</label>
      <select id="taTeam" ${team ? 'disabled' : ''}>
        ${allTeams.map(t => `<option ${t === team ? 'selected' : ''}>${t}</option>`).join('')}
      </select>
    </div>
    <div class="form-group">
      <label>Awards <span class="text-muted" style="font-weight:400;text-transform:none">(hold Ctrl / ⌘ to select multiple)</span></label>
      <select id="taAwards" multiple style="min-height:160px;">
        ${AWARD_LIST.map(a => `<option value="${a.id}" ${assignedIds.includes(a.id) ? 'selected' : ''}>${a.name}</option>`).join('')}
      </select>
    </div>
    <div class="modal-actions">
      <button class="btn-primary" onclick="saveTeamAwards('${(team||'').replace(/'/g,"\\'")}')">Save</button>
      <button class="btn-secondary" onclick="closeModal()">Cancel</button>
    </div>`, false);
}

function saveTeamAwards(editTeam) {
  const teamEl   = document.getElementById('taTeam');
  const awardsEl = document.getElementById('taAwards');
  const team     = editTeam || (teamEl ? teamEl.value : '');
  if (!team) { showToast('Please select a team.', 'error'); return; }
  const awardIds = awardsEl ? Array.from(awardsEl.selectedOptions).map(o => o.value) : [];

  const teamAwards = getTeamAwards();
  const idx = teamAwards.findIndex(t => t.team === team);
  if (idx > -1) {
    teamAwards[idx].awardIds = awardIds;
  } else {
    teamAwards.push({ team, awardIds });
  }
  setTeamAwards(teamAwards);
  closeModal();
  showToast('Team award assignment saved.');
  renderAwardAssignment();
}

function clearTeamAwards(team) {
  openConfirm('Clear Awards', `Remove all award assignments for team: ${team}?`, () => {
    const teamAwards = getTeamAwards();
    const idx = teamAwards.findIndex(t => t.team === team);
    if (idx > -1) { teamAwards[idx].awardIds = []; setTeamAwards(teamAwards); }
    showToast('Awards cleared for team.');
    renderAwardAssignment();
  });
}

function dismissMigReport() {
  LS.remove('rr_migration_report');
  renderAwardAssignment();
}

function openAssignForm() {
  const users = getUsers();
  openModal('Add Jury / BH Assignment', `
    <div class="form-group"><label>Award</label>
      <select id="asgAward">${AWARD_LIST.map(a=>`<option value="${a.id}">${a.name}</option>`).join('')}</select>
    </div>
    <div class="form-group"><label>Role</label>
      <select id="asgRole" onchange="populateAssignUser()">
        <option value="Jury">Jury Member</option>
        <option value="BusinessHead">Business Head</option>
      </select>
    </div>
    <div class="form-group"><label>Employee</label>
      <select id="asgUser"></select>
    </div>
    <div class="modal-actions">
      <button class="btn-primary" onclick="saveAssignment()">Save</button>
      <button class="btn-secondary" onclick="closeModal()">Cancel</button>
    </div>`);
  populateAssignUser();
}

function populateAssignUser() {
  const role = document.getElementById('asgRole').value;
  const roleMap = { Jury:'Jury Member', BusinessHead:'Business Head' };
  const users = getUsers().filter(u=>u.active && u.role===roleMap[role]);
  const sel = document.getElementById('asgUser');
  if (!sel) return;
  sel.innerHTML = users.map(u=>`<option value="${u.empId}">${u.name}${u.email?' ('+u.email+')':''}</option>`).join('');
}

function saveAssignment() {
  const awardId = document.getElementById('asgAward').value;
  const role    = document.getElementById('asgRole').value;
  const empId   = document.getElementById('asgUser').value;
  if (!empId) { showToast('No user available for selected role.','error'); return; }
  const assignments = getAssignments();
  if (assignments.find(a=>a.awardId===awardId&&a.role===role&&a.empId===empId)) {
    showToast('Assignment already exists.','error'); return;
  }
  assignments.push({ awardId, role, empId });
  setAssignments(assignments);
  closeModal();
  showToast('Assignment added.');
  renderAwardAssignment();
}

function removeAssignment(idx) {
  openConfirm('Remove Assignment', 'Are you sure you want to remove this assignment?', () => {
    const assignments = getAssignments();
    assignments.splice(idx, 1);
    setAssignments(assignments);
    showToast('Assignment removed.');
    renderAwardAssignment();
  });
}

/* =========================================================
   HEADCOUNT MANAGEMENT  (v9: Team + Award wise)
   ========================================================= */

/* v9: Helpers for headcount unique key */
function hcKey(fy, q, cluster, award) {
  return `${fy}|${q}|${cluster}|${award}`;
}

/* v9: Get award names eligible for a team (excluding Rising Star) */
function getEligibleAwardNamesForTeam(teamName) {
  const entry = getTeamAwards().find(t => t.team === teamName);
  if (!entry || !entry.awardIds.length) return [];
  return entry.awardIds
    .map(id => AWARD_LIST.find(a => a.id === id))
    .filter(Boolean)
    .map(a => a.name)
    .filter(name => name !== RISING_STAR_AWARD_NAME);
}

/* v9: Get all distinct non-Rising-Star award names across all teams (for CSV import) */
function getAllEligibleAwardNames() {
  const names = new Set();
  AWARD_LIST.filter(a => a.name !== RISING_STAR_AWARD_NAME).forEach(a => names.add(a.name));
  return [...names].sort();
}

function renderHeadcountMgmt() {
  const fy = getFY(); const q = getQ();
  const allHCs = getHeadcounts();

  // Filter controls state
  const fFY      = document.getElementById('hcfFY')?.value      || fy;
  const fQ       = document.getElementById('hcfQ')?.value       || q;
  const fTeam    = document.getElementById('hcfTeam')?.value    || '';
  const fAward   = document.getElementById('hcfAward')?.value   || '';
  const fSearch  = document.getElementById('hcfSearch')?.value  || '';

  let filtered = allHCs;
  filtered = filtered.filter(h => h.fy === fFY && h.quarter === fQ);
  if (fTeam)  filtered = filtered.filter(h => h.cluster === fTeam);
  if (fAward) filtered = filtered.filter(h => h.award === fAward);
  if (fSearch) {
    const sq = fSearch.toLowerCase();
    filtered = filtered.filter(h =>
      (h.cluster||'').toLowerCase().includes(sq) ||
      (h.award||'').toLowerCase().includes(sq)
    );
  }

  // Legacy rows marker
  const legacyRows = filtered.filter(h => h.award === '__legacy__');
  const normalRows = filtered.filter(h => h.award && h.award !== '__legacy__');

  const fySet = [...new Set(['FY2024-25','FY2025-26','FY2026-27',...allHCs.map(h=>h.fy)])].sort();
  const allAwardNames = getAllEligibleAwardNames();

  document.getElementById('pageContent').innerHTML = `
    <div class="section-card">
      <div class="section-card-header">
        <h3>Headcount Management</h3>
        <div style="display:flex;gap:8px;flex-wrap:wrap;align-items:center;">
          <button class="btn-secondary btn-sm" onclick="openHCImportCSV()">⬆ Import CSV</button>
          <button class="btn-secondary btn-sm" onclick="exportHCCSV()">⬇ Export CSV</button>
          <button class="btn-primary btn-sm" onclick="openHCForm()">+ Add Headcount</button>
        </div>
      </div>
      <div class="section-card-body">

        <!-- Filters -->
        <div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(155px,1fr));gap:10px;margin-bottom:14px">
          <div class="form-group" style="margin:0">
            <label style="margin-bottom:4px;display:block">Search</label>
            <input type="text" id="hcfSearch" placeholder="Team or award…" value="${fSearch}" oninput="renderHeadcountMgmt()" style="width:100%"/>
          </div>
          <div class="form-group" style="margin:0">
            <label style="margin-bottom:4px;display:block">Financial Year</label>
            <select id="hcfFY" onchange="renderHeadcountMgmt()">
              ${fySet.map(f=>`<option ${f===fFY?'selected':''}>${f}</option>`).join('')}
            </select>
          </div>
          <div class="form-group" style="margin:0">
            <label style="margin-bottom:4px;display:block">Quarter</label>
            <select id="hcfQ" onchange="renderHeadcountMgmt()">
              ${qOptions(fQ)}
            </select>
          </div>
          <div class="form-group" style="margin:0">
            <label style="margin-bottom:4px;display:block">Team / Cluster</label>
            <select id="hcfTeam" onchange="renderHeadcountMgmt()">
              <option value="">All Teams</option>
              ${CLUSTERS.filter(c=>c!=='Other').map(c=>`<option ${c===fTeam?'selected':''}>${c}</option>`).join('')}
            </select>
          </div>
          <div class="form-group" style="margin:0">
            <label style="margin-bottom:4px;display:block">Award</label>
            <select id="hcfAward" onchange="renderHeadcountMgmt()">
              <option value="">All Awards</option>
              ${allAwardNames.map(n=>`<option ${n===fAward?'selected':''}>${n}</option>`).join('')}
            </select>
          </div>
          <div style="display:flex;align-items:flex-end;padding-bottom:2px">
            <button class="btn-secondary btn-sm" onclick="hcClearFilters()">✕ Clear Filters</button>
          </div>
        </div>

        ${legacyRows.length ? `
        <div class="info-alert orange" style="margin-bottom:12px">
          ⚠️ <strong>${legacyRows.length} legacy headcount record(s)</strong> found from before the v9 upgrade.
          These records do not have an Award field. Please delete them and re-add with the correct Award.
        </div>` : ''}

        <div class="table-wrapper">
          <table>
            <thead>
              <tr>
                <th>Financial Year</th>
                <th>Quarter</th>
                <th>Team / Cluster</th>
                <th>Award</th>
                <th>Headcount</th>
                <th>Allowed Winners (÷30)</th>
                <th>Last Updated</th>
                <th>Actions</th>
              </tr>
            </thead>
            <tbody>
              ${normalRows.length ? normalRows.map(h => {
                const allowed = Math.ceil(h.headcount / 30);
                const hid = h.headcountId;
                return `<tr>
                  <td>${h.fy}</td>
                  <td>${qDisplay(h.quarter)}</td>
                  <td><strong>${h.cluster}</strong></td>
                  <td>${h.award}</td>
                  <td><strong>${h.headcount}</strong></td>
                  <td><span class="badge badge-green">${allowed}</span></td>
                  <td class="text-muted text-sm">${h.updatedAt || '—'}</td>
                  <td>
                    <button class="btn-secondary btn-sm" onclick="openHCForm('${hid}')">Edit</button>
                    <button class="btn-danger btn-sm" style="margin-left:6px" onclick="deleteHC('${hid}')">Delete</button>
                  </td>
                </tr>`;
              }).join('') : ''}
              ${legacyRows.map(h => {
                const hid = h.headcountId;
                return `<tr style="opacity:0.7">
                  <td>${h.fy}</td>
                  <td>${qDisplay(h.quarter)}</td>
                  <td>${h.cluster}</td>
                  <td><span class="badge badge-yellow">Legacy (no award)</span></td>
                  <td>${h.headcount}</td>
                  <td>—</td>
                  <td class="text-muted text-sm">${h.updatedAt || '—'}</td>
                  <td><button class="btn-danger btn-sm" onclick="deleteHC('${hid}')">Delete</button></td>
                </tr>`;
              }).join('')}
              ${!normalRows.length && !legacyRows.length ? '<tr><td colspan="8"><div class="empty-state"><div class="empty-icon">📋</div><p>No headcount records for these filters.</p></div></td></tr>' : ''}
            </tbody>
          </table>
        </div>
        <div class="text-muted text-sm" style="margin-top:8px">${normalRows.length} record(s) shown</div>
      </div>
    </div>
    ${renderTeamAwardEligibilityCard()}`;
}

function hcClearFilters() {
  ['hcfFY','hcfQ','hcfTeam','hcfAward'].forEach(id => { const el = document.getElementById(id); if(el) el.value=''; });
  const s = document.getElementById('hcfSearch'); if(s) s.value='';
  renderHeadcountMgmt();
}

/* =========================================================
   Change 4 (now Change 1): TEAM MASTER / AWARD ELIGIBILITY
   ========================================================= */
function renderTeamAwardEligibilityCard() {
  const teamAwards = getTeamAwards();
  return `
    <div class="section-card" style="margin-top:24px">
      <div class="section-card-header">
        <h3>Team Master — Current Award Assignments</h3>
        <button class="btn-secondary btn-sm" onclick="navigateTo('awardAssignment')">Manage Team Awards →</button>
      </div>
      <div class="section-card-body">
        <div class="info-alert blue" style="margin-bottom:14px;">
          Awards are assigned to <strong>Teams</strong> from the <strong>Award Assignment</strong> page.
          Each Team can have multiple Headcount records — one per eligible Award.
        </div>
        <div class="table-wrapper">
          <table>
            <thead><tr><th>Team</th><th>Currently Assigned Awards</th></tr></thead>
            <tbody>
              ${CLUSTERS.filter(c=>c!=='Other').map(team => {
                const entry = teamAwards.find(t => t.team === team);
                const ids   = entry ? entry.awardIds : [];
                const names = ids.map(id => {
                  const a = AWARD_LIST.find(x => x.id === id);
                  return a ? `<span class="team-tag">${a.name}</span>` : '';
                }).filter(Boolean).join(' ');
                return `<tr>
                  <td><strong>${team}</strong></td>
                  <td>${names || '<span class="text-muted">No awards assigned</span>'}</td>
                </tr>`;
              }).join('')}
            </tbody>
          </table>
        </div>
      </div>
    </div>`;
}

/* =========================================================
   HEADCOUNT CRUD — ADD / EDIT
   ========================================================= */
function openHCForm(headcountId) {
  const fy = getFY(); const q = getQ();
  const hcs = getHeadcounts();
  let existing = null;
  if (headcountId) {
    existing = hcs.find(h => h.headcountId === headcountId) || null;
  }

  // Award dropdown: show all eligible (non-Rising-Star) awards for the selected team
  const teamForAwards = existing ? existing.cluster : (CLUSTERS.filter(c=>c!=='Other')[0] || '');
  const awardNamesForTeam = getEligibleAwardNamesForTeam(teamForAwards);
  // If team has no team-award assignments yet, show all eligible awards from AWARD_LIST
  const awardChoices = awardNamesForTeam.length ? awardNamesForTeam : getAllEligibleAwardNames();

  const existingHC = existing ? existing.headcount : '';
  const existingAllowed = existing ? Math.ceil(existing.headcount / 30) : '';

  openModal(existing ? 'Edit Headcount' : 'Add Headcount', `
    <div class="form-group"><label>Financial Year</label>
      <select id="hcFY">
        <option ${(existing?existing.fy:fy)==='FY2024-25'?'selected':''} value="FY2024-25">FY2024-25</option>
        <option ${(existing?existing.fy:fy)==='FY2025-26'?'selected':''} value="FY2025-26">FY2025-26</option>
        <option ${(existing?existing.fy:fy)==='FY2026-27'?'selected':''} value="FY2026-27">FY2026-27</option>
      </select>
    </div>
    <div class="form-group"><label>Quarter</label>
      <select id="hcQ">${qOptions(existing?existing.quarter:q)}</select>
    </div>
    <div class="form-group"><label>Team / Cluster</label>
      <select id="hcCluster" onchange="hcUpdateAwardDropdown()" ${existing?'':''}> 
        ${CLUSTERS.filter(c=>c!=='Other').map(c=>`<option ${(existing&&existing.cluster===c)?'selected':''}>${c}</option>`).join('')}
      </select>
    </div>
    <div class="form-group"><label>Award</label>
      <select id="hcAward" onchange="hcUpdateAllowed()">
        ${awardChoices.map(n=>`<option ${(existing&&existing.award===n)?'selected':''}>${n}</option>`).join('')}
      </select>
      <p class="text-muted" style="font-size:12px;margin-top:4px">Only awards assigned to the selected team are shown. Rising Star is excluded.</p>
    </div>
    <div class="form-group"><label>Headcount</label>
      <input id="hcCount" type="number" min="1" step="1" value="${existingHC}" placeholder="Enter positive whole number" oninput="hcUpdateAllowed()"/>
    </div>
    <div class="form-group"><label>Allowed Winners <span class="badge badge-gray" style="font-size:11px;margin-left:4px">Read Only · Auto-calculated</span></label>
      <input id="hcAllowed" type="text" value="${existingAllowed}" readonly style="background:#f5f5f5;color:var(--gray-500);cursor:not-allowed"/>
      <p class="text-muted" style="font-size:12px;margin-top:2px">= ROUNDUP(Headcount ÷ 30)</p>
    </div>
    <div class="modal-actions">
      <button class="btn-primary" onclick="saveHC(${existing ? `'${existing.headcountId}'` : 'null'})">Save</button>
      <button class="btn-secondary" onclick="closeModal()">Cancel</button>
    </div>`);
}

function hcUpdateAwardDropdown() {
  const team = document.getElementById('hcCluster')?.value;
  const awardSel = document.getElementById('hcAward');
  if (!team || !awardSel) return;
  const names = getEligibleAwardNamesForTeam(team);
  const choices = names.length ? names : getAllEligibleAwardNames();
  awardSel.innerHTML = choices.map(n => `<option>${n}</option>`).join('');
  hcUpdateAllowed();
}

function hcUpdateAllowed() {
  const cnt = parseInt(document.getElementById('hcCount')?.value);
  const el = document.getElementById('hcAllowed');
  if (!el) return;
  if (!isNaN(cnt) && cnt > 0) {
    el.value = Math.ceil(cnt / 30);
  } else {
    el.value = '';
  }
}

function saveHC(headcountId) {
  const fy    = document.getElementById('hcFY').value;
  const q     = document.getElementById('hcQ').value;
  const cl    = document.getElementById('hcCluster').value;
  const award = document.getElementById('hcAward').value;
  const cnt   = parseInt(document.getElementById('hcCount').value);
  if (!cl || !award || isNaN(cnt) || cnt < 1 || !Number.isInteger(cnt)) {
    showToast('Please fill all fields correctly. Headcount must be a positive whole number.', 'error');
    return;
  }
  if (award === RISING_STAR_AWARD_NAME) {
    showToast('Rising Star Award does not require Headcount.', 'error');
    return;
  }
  const hcs = getHeadcounts();
  const user = currentUser();
  const updatedAt = new Date().toISOString().slice(0, 10);
  const updatedBy = user ? user.name : '';

  if (headcountId && headcountId !== 'null') {
    const idx = hcs.findIndex(h => h.headcountId === headcountId);
    if (idx > -1) {
      hcs[idx] = { ...hcs[idx], fy, quarter:q, cluster:cl, award, headcount:cnt, updatedAt, updatedBy };
    } else {
      showToast('Record not found. It may have been deleted. Please refresh.', 'error');
      return;
    }
  } else {
    // Check for duplicate
    const dup = hcs.find(h => h.fy===fy && h.quarter===q && h.cluster===cl && h.award===award);
    if (dup) {
      showToast('A headcount record for this FY/Quarter/Team/Award already exists. Use Edit to update it.', 'error');
      return;
    }
    hcs.push({ headcountId: generateHeadcountId(), fy, quarter:q, cluster:cl, award, headcount:cnt, updatedAt, updatedBy });
  }
  setHeadcounts(hcs);
  closeModal();
  showToast('Headcount saved.');
  renderHeadcountMgmt();
}

function deleteHC(headcountId) {
  openConfirm(
    'Delete Headcount Record',
    'Are you sure you want to delete this Headcount record? Only this specific FY / Quarter / Team / Award combination will be removed.',
    () => {
      const hcs = getHeadcounts();
      const idx = hcs.findIndex(h => h.headcountId === headcountId);
      if (idx > -1) {
        hcs.splice(idx, 1);
        setHeadcounts(hcs);
        showToast('Headcount record deleted.');
        renderHeadcountMgmt();
      } else {
        showToast('Record not found.', 'error');
      }
    }
  );
}

/* =========================================================
   HEADCOUNT — EXPORT CSV
   ========================================================= */
function exportHCCSV() {
  const hcs = getHeadcounts().filter(h => h.award && h.award !== '__legacy__');
  const headers = ['Financial Year','Quarter','Team / Cluster','Award','Headcount','Allowed Winners','Last Updated','Updated By'];
  const rows = hcs.map(h => [
    h.fy, qDisplay(h.quarter), h.cluster, h.award, h.headcount,
    Math.ceil(h.headcount / 30), h.updatedAt || '', h.updatedBy || ''
  ]);
  downloadCSV('Headcount_Export.csv', headers, rows);
}

/* =========================================================
   HEADCOUNT — IMPORT CSV  (v9)
   Mandatory columns: Financial Year, Quarter, Team / Cluster, Award, Headcount
   Calculated automatically: Allowed Winners
   Rising Star Award rows are skipped with a message.
   Duplicate key = FY + Quarter + Team + Award
   ========================================================= */
let _hcCsvPending = [];
let _hcCsvDupHandles = []; // { rowIdx, fy, q, cluster, award, headcount, existingIdx }

function openHCImportCSV() {
  _hcCsvPending = [];
  _hcCsvDupHandles = [];
  openModal('Import Headcount CSV', `
    <div class="info-alert blue">
      <strong>CSV Format (first row = header, comma-separated):</strong><br/>
      <code>Financial Year, Quarter, Team / Cluster, Award, Headcount</code><br/>
      • <strong>Allowed Winners</strong> is calculated automatically — do not include it.<br/>
      • <strong>Rising Star Award</strong> rows are automatically skipped.<br/>
      • Duplicate records (same FY + Quarter + Team + Award) will prompt you to Update or Skip.<br/>
      • Existing records are never automatically overwritten or deleted.
    </div>

    <div class="csv-drop-zone" id="hcCsvDropZone"
         onclick="document.getElementById('hcCsvFileInput').click()"
         ondragover="event.preventDefault();this.classList.add('drag-over')"
         ondragleave="this.classList.remove('drag-over')"
         ondrop="handleHCCsvDrop(event)">
      <div style="font-size:36px;margin-bottom:8px;">📄</div>
      <p><strong>Click to choose a CSV file</strong> or drag &amp; drop here</p>
      <p class="text-muted text-sm" style="margin-top:4px;">Accepts .csv files only</p>
      <input type="file" id="hcCsvFileInput" accept=".csv" style="display:none"
             onchange="handleHCCsvFileSelect(this)"/>
    </div>

    <div id="hcCsvError" class="error-msg" style="display:none;margin-top:12px"></div>

    <div id="hcCsvSummary" style="display:none">
      <div id="hcCsvSummaryGrid"></div>
      <div class="table-wrapper" style="max-height:260px;overflow-y:auto;margin-top:12px;">
        <table>
          <thead><tr><th>#</th><th>FY</th><th>Quarter</th><th>Team</th><th>Award</th><th>Headcount</th><th>Allowed</th><th>Result</th></tr></thead>
          <tbody id="hcCsvPreviewBody"></tbody>
        </table>
      </div>
      <div id="hcDupSection" style="display:none;margin-top:14px">
        <div class="info-alert orange">
          <strong>Duplicate Records Found</strong> — Choose how to handle each:
        </div>
        <div id="hcDupList" style="margin-top:10px"></div>
        <div class="modal-actions" style="margin-top:12px">
          <button class="btn-secondary btn-sm" onclick="hcDupAllUpdate()">Update All Duplicates</button>
          <button class="btn-secondary btn-sm" style="margin-left:6px" onclick="hcDupAllSkip()">Skip All Duplicates</button>
        </div>
      </div>
    </div>

    <div class="modal-actions" style="margin-top:18px;">
      <button class="btn-primary" id="hcCsvConfirmBtn" style="display:none" onclick="commitHCCsv()">✔ Import Records</button>
      <button class="btn-secondary" onclick="closeModal()">Cancel</button>
    </div>`, true);
}

function handleHCCsvDrop(e) {
  e.preventDefault();
  document.getElementById('hcCsvDropZone').classList.remove('drag-over');
  const file = e.dataTransfer.files[0];
  if (file) parseHCCsvFile(file);
}

function handleHCCsvFileSelect(input) {
  const file = input.files[0];
  if (file) parseHCCsvFile(file);
}

function parseHCCsvFile(file) {
  if (!file.name.toLowerCase().endsWith('.csv')) { showToast('Please upload a .csv file.','error'); return; }
  const reader = new FileReader();
  reader.onload = e => processHCCsvText(e.target.result);
  reader.readAsText(file);
}

function hcParseCsvLine(line) {
  const out = []; let cur = '', inQ = false;
  for (let i = 0; i < line.length; i++) {
    const ch = line[i];
    if (inQ) { if (ch==='"') { if (line[i+1]==='"') { cur+='"'; i++; } else inQ=false; } else cur+=ch; }
    else { if (ch==='"') inQ=true; else if (ch===',') { out.push(cur); cur=''; } else cur+=ch; }
  }
  out.push(cur);
  return out.map(c=>c.trim());
}

function processHCCsvText(text) {
  const errEl = document.getElementById('hcCsvError');
  errEl.style.display = 'none';
  const lines = text.split(/\r?\n/).map(l=>l).filter(l=>l.trim());
  if (!lines.length) { errEl.textContent='CSV file is empty.'; errEl.style.display=''; return; }

  const headers = hcParseCsvLine(lines[0]).map(h=>h.trim().toLowerCase());
  const findCol = name => {
    const t = name.toLowerCase();
    let i = headers.indexOf(t);
    if (i !== -1) return i;
    // fuzzy matches
    if (t === 'team / cluster') i = headers.findIndex(h => h.includes('team') || h.includes('cluster'));
    if (t === 'financial year') i = headers.findIndex(h => h.includes('financial') || h.includes('year') || h.includes('fy'));
    return i;
  };

  const colFY       = findCol('financial year');
  const colQ        = findCol('quarter');
  const colTeam     = findCol('team / cluster');
  const colAward    = findCol('award');
  const colHC       = findCol('headcount');

  const missing = [];
  if (colFY < 0)    missing.push('Financial Year');
  if (colQ < 0)     missing.push('Quarter');
  if (colTeam < 0)  missing.push('Team / Cluster');
  if (colAward < 0) missing.push('Award');
  if (colHC < 0)    missing.push('Headcount');

  if (missing.length) {
    errEl.textContent = `Missing required column(s): ${missing.join(', ')}. Check your CSV headers.`;
    errEl.style.display = '';
    return;
  }

  const existingHCs = getHeadcounts();
  const existingKeys = new Map();
  existingHCs.forEach(h => existingKeys.set(hcKey(h.fy, h.quarter, h.cluster, h.award), h.headcountId));
  const seenInFile = new Set();

  _hcCsvPending = [];
  _hcCsvDupHandles = [];
  const previewRows = [];
  let okCount=0, dupCount=0, skipCount=0, invalidCount=0;

  lines.slice(1).forEach((line, idx) => {
    if (!line.trim()) return;
    const cols = hcParseCsvLine(line);
    const get = i => (i >= 0 && i < cols.length) ? cols[i].trim() : '';
    const fy       = get(colFY);
    const qRaw     = get(colQ).toUpperCase().replace(/\s+/g,'');
    // normalize quarter: accept Q1AMJ, Q1, Q1AMJ etc.
    const q        = qRaw.match(/^Q[1-4]/i) ? qRaw.slice(0,2).toUpperCase() : '';
    const cluster  = get(colTeam);
    const award    = get(colAward);
    const hcRaw    = get(colHC);
    const hcNum    = parseInt(hcRaw);
    const rowNum   = idx + 2;

    // Rising Star skip
    if (award && award.toLowerCase().includes('rising star')) {
      skipCount++;
      previewRows.push({ idx:rowNum, fy, q, cluster, award, hc:'', allowed:'', result:'rising', reason:'Skipped – Rising Star Award does not require Headcount.' });
      return;
    }

    // Validate
    if (!fy || !q || !cluster || !award || isNaN(hcNum) || hcNum < 1 || !Number.isInteger(hcNum)) {
      invalidCount++;
      previewRows.push({ idx:rowNum, fy:fy||'—', q:q||'—', cluster:cluster||'—', award:award||'—', hc:hcRaw||'—', allowed:'', result:'fail', reason:'Missing or invalid field(s)' });
      return;
    }

    const key = hcKey(fy, q, cluster, award);
    if (seenInFile.has(key)) {
      invalidCount++;
      previewRows.push({ idx:rowNum, fy, q, cluster, award, hc:hcNum, allowed:'', result:'fail', reason:'Duplicate row within CSV' });
      return;
    }
    seenInFile.add(key);

    const allowed = Math.ceil(hcNum / 30);

    if (existingKeys.has(key)) {
      dupCount++;
      _hcCsvDupHandles.push({ rowIdx: rowNum, fy, q, cluster, award, headcount: hcNum, existingId: existingKeys.get(key), action: 'ask' });
      previewRows.push({ idx:rowNum, fy, q, cluster, award, hc:hcNum, allowed, result:'dup', reason:'Duplicate — awaiting your decision' });
    } else {
      okCount++;
      _hcCsvPending.push({ fy, quarter:q, cluster, award, headcount:hcNum });
      previewRows.push({ idx:rowNum, fy, q, cluster, award, hc:hcNum, allowed, result:'ok', reason:'' });
    }
  });

  document.getElementById('hcCsvSummary').style.display = '';
  document.getElementById('hcCsvSummaryGrid').innerHTML = `
    <div class="csv-stat-grid">
      <div class="csv-stat ok"><div class="csv-stat-num">${okCount + dupCount + skipCount + invalidCount}</div><div class="csv-stat-lbl">Total Records</div></div>
      <div class="csv-stat ok"><div class="csv-stat-num">${okCount}</div><div class="csv-stat-lbl">Ready to Import</div></div>
      <div class="csv-stat dup"><div class="csv-stat-num">${dupCount}</div><div class="csv-stat-lbl">Duplicates</div></div>
      <div class="csv-stat dup" style="background:#fff8e1"><div class="csv-stat-num">${skipCount}</div><div class="csv-stat-lbl">Rising Star Skipped</div></div>
      <div class="csv-stat fail"><div class="csv-stat-num">${invalidCount}</div><div class="csv-stat-lbl">Invalid</div></div>
    </div>`;

  const badgeMap = { ok:'badge-green', dup:'badge-yellow', fail:'badge-red', rising:'badge-orange' };
  const labelMap = { ok:'✓ Ready', dup:'Duplicate', fail:'Invalid', rising:'Skipped (Rising Star)' };
  document.getElementById('hcCsvPreviewBody').innerHTML = previewRows.map(r => `
    <tr>
      <td>${r.idx}</td><td>${r.fy}</td><td>${r.q ? qDisplay(r.q) : '—'}</td>
      <td style="font-size:12px">${r.cluster}</td>
      <td style="font-size:12px">${r.award}</td>
      <td>${r.hc}</td><td>${r.allowed}</td>
      <td><span class="badge ${badgeMap[r.result]||'badge-gray'}">${labelMap[r.result]||r.result}</span>${r.reason?`<br/><span class="text-muted text-sm">${r.reason}</span>`:''}</td>
    </tr>`).join('');

  // Render dup decision UI
  const dupSec = document.getElementById('hcDupSection');
  if (_hcCsvDupHandles.length) {
    dupSec.style.display = '';
    renderHCDupList();
  } else {
    dupSec.style.display = 'none';
  }

  document.getElementById('hcCsvConfirmBtn').style.display = (okCount > 0 || _hcCsvDupHandles.some(d=>d.action!=='ask')) ? '' : 'none';
  // Always show confirm button so HR can proceed even if only dups
  if (okCount > 0 || _hcCsvDupHandles.length > 0) document.getElementById('hcCsvConfirmBtn').style.display = '';
}

function renderHCDupList() {
  const listEl = document.getElementById('hcDupList');
  if (!listEl) return;
  listEl.innerHTML = _hcCsvDupHandles.map((d, i) => `
    <div style="display:flex;align-items:center;gap:10px;flex-wrap:wrap;margin-bottom:8px;padding:8px;background:#fffbf0;border-radius:6px;border:1px solid #f5c97a">
      <span style="flex:1;min-width:200px;font-size:13px"><strong>${d.fy} ${qDisplay(d.q)}</strong> · ${d.cluster} · ${d.award} — HC: ${d.headcount}</span>
      <label><input type="radio" name="dupAction_${i}" value="update" ${d.action==='update'?'checked':''} onchange="_hcCsvDupHandles[${i}].action='update';document.getElementById('hcCsvConfirmBtn').style.display=''"> Update Existing</label>
      <label><input type="radio" name="dupAction_${i}" value="skip" ${d.action==='skip'?'checked':''} onchange="_hcCsvDupHandles[${i}].action='skip'"> Skip Record</label>
    </div>`).join('');
}

function hcDupAllUpdate() { _hcCsvDupHandles.forEach(d => d.action='update'); renderHCDupList(); document.getElementById('hcCsvConfirmBtn').style.display=''; }
function hcDupAllSkip()   { _hcCsvDupHandles.forEach(d => d.action='skip');   renderHCDupList(); }

function commitHCCsv() {
  const hcs = getHeadcounts();
  const user = currentUser();
  const updatedAt = new Date().toISOString().slice(0,10);
  const updatedBy = user ? user.name : '';
  let imported = 0, updated = 0, skipped = 0;

  // New records — assign a fresh headcountId to each
  _hcCsvPending.forEach(r => {
    hcs.push({ headcountId: generateHeadcountId(), ...r, updatedAt, updatedBy });
    imported++;
  });

  // Duplicate decisions — look up by headcountId, not by array index
  _hcCsvDupHandles.forEach(d => {
    if (d.action === 'update') {
      const idx = hcs.findIndex(h => h.headcountId === d.existingId);
      if (idx > -1) {
        hcs[idx] = { ...hcs[idx], headcount: d.headcount, updatedAt, updatedBy };
      }
      updated++;
    } else {
      skipped++;
    }
  });

  setHeadcounts(hcs);
  _hcCsvPending = [];
  _hcCsvDupHandles = [];
  closeModal();
  showToast(`Import complete: ${imported} added, ${updated} updated, ${skipped} skipped.`);
  renderHeadcountMgmt();
}

/* =========================================================
   NOMINATION CONTROL
   ========================================================= */
function renderNominationControl() {
  const open = isNomOpen();
  document.getElementById('pageContent').innerHTML = `
    <div class="section-card">
      <div class="section-card-header"><h3>Nomination Control</h3></div>
      <div class="section-card-body">
        <div class="nom-status-banner ${open?'on':'off'}">
          ${open ? '✅ Nominations are currently OPEN' : '🚫 Nominations are currently CLOSED'}
        </div>
        <div class="toggle-wrap">
          <span class="toggle-label">Nomination Status</span>
          <label class="toggle">
            <input type="checkbox" id="nomToggle" ${open?'checked':''} onchange="toggleNomStatus()"/>
            <span class="toggle-slider"></span>
          </label>
          <span style="font-size:14px;font-weight:600;color:${open?'var(--green)':'var(--red)'}">${open?'ON':'OFF'}</span>
        </div>
        <p class="text-muted mt-16">When <strong>OFF</strong>, managers cannot submit nominations and will see a "Nominations are currently closed" message.</p>
      </div>
    </div>`;
}

function toggleNomStatus() {
  const v = document.getElementById('nomToggle').checked;
  setNomOpen(v);
  showToast(`Nominations turned ${v?'ON':'OFF'}.`);
  renderNominationControl();
}

/* =========================================================
   DETAILED REVIEW
   ========================================================= */
function renderDetailedReview() {
  const fy = getFY(); const q = getQ();
  const noms = getNominations().filter(n=>n.fy===fy&&n.quarter===q);
  document.getElementById('pageContent').innerHTML = `
    <div class="section-card">
      <div class="section-card-header"><h3>All Nominations – ${fy} ${q}</h3></div>
      <div class="section-card-body">
        <div class="search-bar-wrap">
          <input type="text" id="drSearch" placeholder="Search nominee, award or manager…" oninput="filterDR()"/>
        </div>
        <div class="table-wrapper" id="drTableWrap">
          ${drTable(noms)}
        </div>
      </div>
    </div>`;
}

function drTable(noms) {
  if (!noms.length) return `<div class="empty-state"><div class="empty-icon">📭</div><p>No nominations found.</p></div>`;
  const user = currentUser();
  const isHR = user && user.role === 'HR Admin';
  const actionHeader = isHR ? '<th>Actions</th>' : '<th>Details</th>';
  return `<table><thead><tr><th>Nominee</th><th>Award</th><th>Cluster</th><th>Manager</th><th>Date</th><th>Status</th>${actionHeader}</tr></thead>
    <tbody>${noms.map(n=>{
      const award = AWARD_LIST.find(a=>a.id===n.awardId);
      const actionCell = isHR
        ? `<td style="white-space:nowrap">
            <button class="btn-secondary btn-sm" onclick="openNomDetail('${n.id}')">View</button>
            ${n.status === 'Approved'
              ? `<button class="btn-danger btn-sm" style="margin-left:4px;opacity:0.4;cursor:not-allowed" title="Cannot delete approved winner" disabled>Delete</button>`
              : `<button class="btn-danger btn-sm" style="margin-left:4px" onclick="softDeleteNomination('${n.id}')">Delete</button>`
            }
          </td>`
        : `<td><button class="btn-secondary btn-sm" onclick="openNomDetail('${n.id}')">View</button></td>`;
      return `<tr>
        <td><strong>${n.nomineeName}</strong><br/><span class="text-muted text-sm">${n.empId}</span></td>
        <td>${award?award.name:'—'}</td>
        <td>${n.cluster}</td>
        <td>${n.managerName}</td>
        <td>${n.submittedAt}</td>
        <td>${statusBadge(n.status)}</td>
        ${actionCell}
      </tr>`;
    }).join('')}</tbody></table>`;
}

function filterDR() {
  const q = document.getElementById('drSearch').value.toLowerCase();
  const fy = getFY(); const qt = getQ();
  const noms = getNominations().filter(n => n.fy===fy && n.quarter===qt &&
    (n.nomineeName.toLowerCase().includes(q) || (AWARD_LIST.find(a=>a.id===n.awardId)||{name:''}).name.toLowerCase().includes(q) || n.managerName.toLowerCase().includes(q)));
  document.getElementById('drTableWrap').innerHTML = drTable(noms);
}

function openNomDetail(nomId) {
  const nom = getNominations().find(n=>n.id===nomId);
  if (!nom) return;
  const award = AWARD_LIST.find(a=>a.id===nom.awardId);
  const isRising = nom.awardId === 'A01';
  let extra = '';
  if (nom.juryScores && nom.juryScores.length) {
    const avg = (nom.juryScores.reduce((s,j)=>s+j.score,0)/nom.juryScores.length).toFixed(1);
    extra += `<hr class="divider"/>
      <div class="score-box">
        <h5>Jury Evaluations <span class="score-scale-badge">Score (1-10)</span></h5>
        ${nom.juryScores.map(j=>`<div class="detail-row"><span class="label">${j.juryName}</span><span class="value">Score: ${j.score} | ${j.comment}</span></div>`).join('')}
        <div class="detail-row"><span class="label">Average Score</span><span class="avg-score">${avg}</span></div>
      </div>`;
  }
  if (nom.bhScores && nom.bhScores.length) {
    const avg = (nom.bhScores.reduce((s,b)=>s+b.score,0)/nom.bhScores.length).toFixed(1);
    extra += `<hr class="divider"/>
      <div class="score-box">
        <h5>Business Head Evaluations <span class="score-scale-badge">Score (1-10)</span></h5>
        ${nom.bhScores.map(b=>`<div class="detail-row"><span class="label">${b.bhName}</span><span class="value">Score: ${b.score} | ${b.comment}</span></div>`).join('')}
        <div class="detail-row"><span class="label">Average Score</span><span class="avg-score">${avg}</span></div>
      </div>`;
  }

  /* Change 2: Rising Star (A01) shows the 4-parameter evaluation table + Total Score
     instead of the free-text Reason row used by all other awards. */
  const reasonOrScoreRow = isRising ? `
    <hr class="divider"/>
    <div class="score-box">
      <h5>Rising Star Evaluation <span class="score-scale-badge">Score (1-5)</span></h5>
      <div class="detail-row"><span class="label">Job Performance Score</span><span class="value">${nom.jobPerformanceScore ?? '—'}</span></div>
      <div class="detail-row"><span class="label">Values Score</span><span class="value">${nom.valuesScore ?? '—'}</span></div>
      <div class="detail-row"><span class="label">Punctuality Score</span><span class="value">${nom.punctualityScore ?? '—'}</span></div>
      <div class="detail-row"><span class="label">Grooming Score</span><span class="value">${nom.groomingScore ?? '—'}</span></div>
      <div class="detail-row"><span class="label">Total Score</span><span class="avg-score">${nom.totalScore ?? '—'} / 20</span></div>
      ${nom.rsComment ? `<div class="detail-row"><span class="label">Comments</span><span class="value">${nom.rsComment}</span></div>` : ''}
    </div>` : `
    <div class="detail-row"><span class="label">Reason</span><span class="value">${nom.reason}</span></div>`;

  openModal('Nomination Detail – ' + nom.nomineeName, `
    <div class="detail-row"><span class="label">Award</span><span class="value">${award?award.name:'—'}</span></div>
    <div class="detail-row"><span class="label">Nominee Name</span><span class="value">${nom.nomineeName}</span></div>
    <div class="detail-row"><span class="label">Employee ID</span><span class="value">${nom.empId}</span></div>
    <div class="detail-row"><span class="label">Cluster</span><span class="value">${nom.cluster}</span></div>
    <div class="detail-row"><span class="label">Location</span><span class="value">${nom.location}</span></div>
    ${isRising ? '' : reasonOrScoreRow}
    <div class="detail-row"><span class="label">Manager</span><span class="value">${nom.managerName}</span></div>
    <div class="detail-row"><span class="label">Submitted</span><span class="value">${nom.submittedAt}</span></div>
    <div class="detail-row"><span class="label">Status</span><span class="value">${statusBadge(nom.status)}</span></div>
    ${isRising ? reasonOrScoreRow : ''}
    ${extra}`, true);
}

/* =========================================================
   WINNER APPROVAL
   ========================================================= */
function renderWinnerApproval() {
  const fy = getFY(); const q = getQ();
  const pending = getNominations().filter(n=>n.fy===fy&&n.quarter===q&&n.status==='HR Review');
  document.getElementById('pageContent').innerHTML = `
    <div class="section-card">
      <div class="section-card-header"><h3>Pending Approvals – ${fy} ${q}</h3></div>
      <div class="section-card-body">
        ${pending.length ? `<div class="table-wrapper"><table>
          <thead><tr><th>Nominee</th><th>Award</th><th>Cluster</th><th>Scores</th><th>Actions</th></tr></thead>
          <tbody>${pending.map(n=>{
            const award = AWARD_LIST.find(a=>a.id===n.awardId);
            const juryAvg = n.juryScores&&n.juryScores.length ? (n.juryScores.reduce((s,j)=>s+j.score,0)/n.juryScores.length).toFixed(1) : '—';
            const bhAvg   = n.bhScores&&n.bhScores.length ? (n.bhScores.reduce((s,b)=>s+b.score,0)/n.bhScores.length).toFixed(1) : '—';
            const isRising = n.awardId === 'A01';
            const scoreCell = isRising
              ? `<strong class="avg-score">${n.totalScore ?? '—'} / 20</strong>`
              : `${juryAvg!=='—'?`Jury: ${juryAvg}`:''}${bhAvg!=='—'?` BH: ${bhAvg}`:''}`;
            return `<tr>
              <td><strong>${n.nomineeName}</strong><br/><span class="text-muted text-sm">${n.empId}</span></td>
              <td>${award?award.name:'—'}</td>
              <td>${n.cluster}</td>
              <td>${scoreCell}</td>
              <td>
                <button class="btn-success btn-sm" onclick="approveWinner('${n.id}')">✓ Approve</button>
                <button class="btn-danger btn-sm" style="margin-left:6px" onclick="rejectNomination('${n.id}')">✗ Reject</button>
                <button class="btn-secondary btn-sm" style="margin-left:6px" onclick="returnForReview('${n.id}')">↩ Return</button>
              </td>
            </tr>`;
          }).join('')}</tbody></table></div>`
        : `<div class="empty-state"><div class="empty-icon">✅</div><p>No pending approvals for this period.</p></div>`}
      </div>
    </div>`;
}

function approveWinner(nomId) {
  openConfirm('Approve Winner', 'Are you sure you want to approve this nomination as winner?', () => {
    const noms = getNominations();
    const nom  = noms.find(n=>n.id===nomId);
    const award = AWARD_LIST.find(a=>a.id===nom.awardId);
    nom.status = 'Approved';
    setNominations(noms);
    const winners = getWinners();
    winners.push({
      id: uid(), awardId:nom.awardId, awardName:award?award.name:'',
      fy:nom.fy, quarter:nom.quarter,
      winnerName:nom.nomineeName, empId:nom.empId, cluster:nom.cluster,
      approvedAt: new Date().toISOString().slice(0,10),
      approvedBy: currentUser().name
    });
    setWinners(winners);
    showToast('Winner approved and added to history!');
    renderWinnerApproval();
  });
}

function rejectNomination(nomId) {
  openConfirm('Reject Nomination', 'Are you sure you want to reject this nomination?', () => {
    const noms = getNominations();
    const nom  = noms.find(n=>n.id===nomId);
    nom.status = 'Rejected';
    setNominations(noms);
    showToast('Nomination rejected.', 'error');
    renderWinnerApproval();
  });
}

function returnForReview(nomId) {
  const noms = getNominations();
  const nom  = noms.find(n=>n.id===nomId);
  const award = AWARD_LIST.find(a=>a.id===nom.awardId);
  if (award) {
    if (award.type==='Jury') nom.status='Jury Review';
    else if (award.type==='BusinessHead') nom.status='BH Review';
    else nom.status='Submitted';
  }
  setNominations(noms);
  showToast('Returned for further review.');
  renderWinnerApproval();
}

/* =========================================================
   SOFT DELETE — HR only
   Marks nomination as deleted. Does not permanently remove data.
   Approved winners cannot be deleted.
   ========================================================= */
function softDeleteNomination(nomId) {
  const allNoms = getAllNominations();
  const nom = allNoms.find(n => n.id === nomId);
  if (!nom) { showToast('Nomination not found.', 'error'); return; }
  if (nom.status === 'Approved') {
    showToast('This nomination has already been approved as a winner. Please revoke the approval before deleting.', 'error');
    return;
  }
  openConfirm(
    'Delete Nomination',
    `Are you sure you want to delete the nomination for "${nom.nomineeName}"? This is a soft delete — the record will be kept and can be restored from Deleted Nominations.`,
    () => {
      const user = currentUser();
      nom.deletedAt = new Date().toISOString().slice(0, 10);
      nom.deletedBy = user ? user.name : 'HR Admin';
      nom._preDeleteStatus = nom.status;
      setNominations(allNoms);
      showToast('Nomination deleted. It can be restored from Deleted Nominations.');
      renderDetailedReview();
    }
  );
}

function restoreNomination(nomId) {
  const allNoms = getAllNominations();
  const nom = allNoms.find(n => n.id === nomId);
  if (!nom) { showToast('Nomination not found.', 'error'); return; }
  openConfirm(
    'Restore Nomination',
    `Restore the nomination for "${nom.nomineeName}"? It will be returned to its previous status ("${nom._preDeleteStatus || nom.status}") and all scores/evaluations will be restored.`,
    () => {
      if (nom._preDeleteStatus) nom.status = nom._preDeleteStatus;
      delete nom.deletedAt;
      delete nom.deletedBy;
      delete nom._preDeleteStatus;
      setNominations(allNoms);
      showToast('Nomination restored successfully.');
      renderDeletedNominations();
    }
  );
}

/* =========================================================
   DELETED NOMINATIONS PAGE — HR only
   ========================================================= */
function renderDeletedNominations() {
  const deleted = getAllNominations().filter(n => !!n.deletedAt);
  const fSearch = document.getElementById('dnSearch')?.value || '';
  const fFY     = document.getElementById('dnFY')?.value     || '';
  const fQ      = document.getElementById('dnQ')?.value      || '';
  let filtered = deleted;
  if (fSearch) filtered = filtered.filter(n =>
    n.nomineeName.toLowerCase().includes(fSearch.toLowerCase()) ||
    (n.empId||'').toLowerCase().includes(fSearch.toLowerCase()) ||
    (n.managerName||'').toLowerCase().includes(fSearch.toLowerCase())
  );
  if (fFY) filtered = filtered.filter(n => n.fy === fFY);
  if (fQ)  filtered = filtered.filter(n => n.quarter === fQ);

  const fySet = [...new Set(['FY2024-25','FY2025-26','FY2026-27', ...deleted.map(n=>n.fy)])].sort();

  document.getElementById('pageContent').innerHTML = `
    <div class="deleted-noms-banner">
      <span style="font-size:22px">🗑️</span>
      <div>
        <div style="font-size:17px;font-weight:700">Deleted Nominations</div>
        <div style="font-size:13px;opacity:0.8">${deleted.length} soft-deleted record(s) — no data has been permanently removed</div>
      </div>
    </div>
    <div class="section-card">
      <div class="section-card-header"><h3>Filter Deleted Records</h3></div>
      <div class="section-card-body">
        <div style="display:flex;gap:12px;flex-wrap:wrap;align-items:flex-end;margin-bottom:4px">
          <div class="form-group" style="margin:0;flex:1;min-width:200px">
            <label style="display:block;margin-bottom:4px">Search Nominee / Manager</label>
            <input type="text" id="dnSearch" placeholder="Name or ID…" value="${fSearch}" oninput="renderDeletedNominations()" style="width:100%"/>
          </div>
          <div class="form-group" style="margin:0">
            <label style="display:block;margin-bottom:4px">Financial Year</label>
            <select id="dnFY" onchange="renderDeletedNominations()">
              <option value="">All Years</option>
              ${fySet.map(f=>`<option ${f===fFY?'selected':''}>${f}</option>`).join('')}
            </select>
          </div>
          <div class="form-group" style="margin:0">
            <label style="display:block;margin-bottom:4px">Quarter</label>
            <select id="dnQ" onchange="renderDeletedNominations()">
              <option value="">All Quarters</option>
              ${['Q1','Q2','Q3','Q4'].map(qq=>`<option value="${qq}" ${qq===fQ?'selected':''}>${qDisplay(qq)}</option>`).join('')}
            </select>
          </div>
          <div style="padding-bottom:2px">
            <button class="btn-secondary btn-sm" onclick="dnClearFilters()">✕ Clear</button>
          </div>
        </div>
      </div>
    </div>
    <div class="section-card" style="margin-top:16px">
      <div class="section-card-header">
        <h3>Deleted Records</h3>
        <span class="text-muted text-sm">${filtered.length} record(s)</span>
      </div>
      <div class="section-card-body">
        ${filtered.length ? `<div class="table-wrapper"><table>
          <thead><tr>
            <th>Award</th><th>Nominee</th><th>Manager</th><th>FY</th><th>Quarter</th>
            <th>Status (before delete)</th><th>Deleted By</th><th>Deleted On</th><th>Action</th>
          </tr></thead>
          <tbody>${filtered.map(n => {
            const award = AWARD_LIST.find(a=>a.id===n.awardId);
            return `<tr>
              <td>${award?award.name:'—'}</td>
              <td><strong>${n.nomineeName}</strong><br/><span class="text-muted text-sm">${n.empId}</span></td>
              <td>${n.managerName}</td>
              <td>${n.fy}</td>
              <td><span class="badge badge-blue">${qDisplay(n.quarter)}</span></td>
              <td>${statusBadge(n._preDeleteStatus || n.status)}</td>
              <td>${n.deletedBy || '—'}</td>
              <td>${n.deletedAt || '—'}</td>
              <td><button class="btn-success btn-sm" onclick="restoreNomination('${n.id}')">↩ Restore</button></td>
            </tr>`;
          }).join('')}</tbody>
        </table></div>`
        : `<div class="empty-state">
            <div class="empty-icon">🗑️</div>
            <p>No deleted nominations${fSearch||fFY||fQ?' match your filters':' yet'}.</p>
          </div>`}
      </div>
    </div>`;
}

function dnClearFilters() {
  ['dnSearch'].forEach(id => { const el=document.getElementById(id); if(el) el.value=''; });
  ['dnFY','dnQ'].forEach(id => { const el=document.getElementById(id); if(el) el.value=''; });
  renderDeletedNominations();
}

/* =========================================================
   WINNER HISTORY
   ========================================================= */
function renderWinnerHistory() {
  const all = getWinners();
  const fySet = [...new Set(['FY2024-25','FY2025-26','FY2026-27',...all.map(w=>w.fy)])].sort();

  // Read filter state from DOM (persists across filter changes via re-render)
  const fFY      = document.getElementById('whFY')?.value      || '';
  const fQ       = document.getElementById('whQ')?.value       || '';
  const fAward   = document.getElementById('whAward')?.value   || '';
  const fCluster = document.getElementById('whCluster')?.value || '';
  const fSearch  = document.getElementById('whSearch')?.value  || '';

  let filtered = all;
  if (fFY)      filtered = filtered.filter(w => w.fy === fFY);
  if (fQ)       filtered = filtered.filter(w => w.quarter === fQ);
  if (fAward)   filtered = filtered.filter(w => w.awardId === fAward);
  if (fCluster) filtered = filtered.filter(w => w.cluster === fCluster);
  if (fSearch)  filtered = filtered.filter(w =>
    w.winnerName.toLowerCase().includes(fSearch.toLowerCase()) ||
    (w.empId||'').toLowerCase().includes(fSearch.toLowerCase())
  );

  // Sort: newest first
  filtered = [...filtered].reverse();

  /* Import CSV is HR Admin only — Managers, Jury Members, and Business Heads never see it */
  const _whUser = currentUser();
  const whCanImport = _whUser && _whUser.role === 'HR Admin';

  document.getElementById('pageContent').innerHTML = `
    <div class="winners-history-banner">
      <div class="whb-trophy">🏆</div>
      <div class="whb-text">
        <div class="whb-title">Winner History</div>
        <div class="whb-sub">${all.length} total winners recognised across all periods</div>
      </div>
      <div style="display:flex;gap:8px;flex-shrink:0">
        ${whCanImport ? `<button class="btn-secondary btn-sm" onclick="openWinnerHistoryCSVUpload()">⬆ Import CSV</button>` : ''}
        <button class="btn-secondary btn-sm" onclick="whExportCSV()">⬇ Export CSV</button>
      </div>
    </div>

    <div class="section-card">
      <div class="section-card-header"><h3>Filter Winners</h3></div>
      <div class="section-card-body">
        <div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(155px,1fr));gap:12px;margin-bottom:4px">
          <div class="form-group" style="margin:0">
            <label style="margin-bottom:4px;display:block">Search</label>
            <input type="text" id="whSearch" placeholder="Name or ID…" value="${fSearch}" oninput="renderWinnerHistory()" style="width:100%"/>
          </div>
          <div class="form-group" style="margin:0">
            <label style="margin-bottom:4px;display:block">Financial Year</label>
            <select id="whFY" onchange="renderWinnerHistory()">
              <option value="">All Years</option>
              ${fySet.map(f=>`<option ${f===fFY?'selected':''}>${f}</option>`).join('')}
            </select>
          </div>
          <div class="form-group" style="margin:0">
            <label style="margin-bottom:4px;display:block">Quarter</label>
            <select id="whQ" onchange="renderWinnerHistory()">
              <option value="">All Quarters</option>
              ${['Q1','Q2','Q3','Q4'].map(q=>`<option value="${q}" ${q===fQ?'selected':''}>${qDisplay(q)}</option>`).join('')}
            </select>
          </div>
          <div class="form-group" style="margin:0">
            <label style="margin-bottom:4px;display:block">Award</label>
            <select id="whAward" onchange="renderWinnerHistory()">
              <option value="">All Awards</option>
              ${AWARD_LIST.map(a=>`<option value="${a.id}" ${a.id===fAward?'selected':''}>${a.name}</option>`).join('')}
            </select>
          </div>
          <div class="form-group" style="margin:0">
            <label style="margin-bottom:4px;display:block">Cluster</label>
            <select id="whCluster" onchange="renderWinnerHistory()">
              <option value="">All Clusters</option>
              ${CLUSTERS.filter(c=>c!=='Other').map(c=>`<option ${c===fCluster?'selected':''}>${c}</option>`).join('')}
            </select>
          </div>
          <div style="display:flex;align-items:flex-end;padding-bottom:2px">
            <button class="btn-secondary btn-sm" onclick="whClearFilters()">✕ Clear Filters</button>
          </div>
        </div>
      </div>
    </div>

    <div class="section-card" style="margin-top:16px">
      <div class="section-card-header">
        <h3>Winners ${fFY||'All Years'} ${fQ||''}</h3>
        <span class="text-muted text-sm">${filtered.length} record(s)</span>
      </div>
      <div class="section-card-body">
        ${filtered.length ? `<div class="table-wrapper"><table>
          <thead><tr><th>Financial Year</th><th>Quarter</th><th>Award</th><th>Winner</th><th>Employee ID</th><th>Cluster</th><th>Approved On</th><th>Approved By</th></tr></thead>
          <tbody>${filtered.map(w=>`<tr>
            <td>${w.fy}</td>
            <td><span class="badge badge-blue">${qDisplay(w.quarter)}</span></td>
            <td>${w.awardName}</td>
            <td><div class="winner-name-cell"><span class="winner-trophy">🏆</span><strong>${w.winnerName}</strong></div></td>
            <td><code>${w.empId||'—'}</code></td>
            <td>${w.cluster}</td>
            <td>${w.approvedAt}</td>
            <td>${w.approvedBy}</td>
          </tr>`).join('')}</tbody>
        </table></div>`
        : `<div class="empty-state"><div class="empty-icon">🏅</div><p>No winners match the selected filters.</p></div>`}
      </div>
    </div>`;
}

function whClearFilters() {
  ['whFY','whQ','whAward','whCluster'].forEach(id => { const el = document.getElementById(id); if(el) el.value=''; });
  const s = document.getElementById('whSearch'); if(s) s.value='';
  renderWinnerHistory();
}

function whExportCSV() {
  const all = getWinners().slice().reverse();
  const headers = ['Financial Year','Quarter','Award','Winner Name','Employee ID','Cluster','Approved On','Approved By'];
  const rows = all.map(w => [w.fy, w.quarter, w.awardName, w.winnerName, w.empId||'', w.cluster, w.approvedAt, w.approvedBy]);
  downloadCSV('Winner_History_All.csv', headers, rows);
}

/* =========================================================
   WINNER HISTORY — IMPORT CSV  (HR Admin only)
   Appends previous-quarter winners from a CSV file into
   Winner History. Never overwrites or deletes existing records.

   Expected columns (header row required), in this order:
     Mandatory: Financial Year, Quarter, Award Name, Winner Name
     Optional : Employee ID, Cluster / Team, Location, Approved By, Approval Date
   Extra/unrecognised columns in the CSV are ignored.

   Duplicate key for skip-detection: Financial Year + Quarter + Award Name + Winner Name
   (case-insensitive, trimmed) — checked against existing Winner History AND
   against other rows already accepted earlier in the same file.
   ========================================================= */
const WH_REQUIRED_HEADERS = ['Financial Year','Quarter','Award Name','Winner Name'];
const WH_OPTIONAL_HEADERS = ['Employee ID','Cluster / Team','Location','Approved By','Approval Date'];
let _whCsvPendingWinners = [];  /* holds parsed, valid, non-duplicate rows before commit */

function openWinnerHistoryCSVUpload() {
  /* Defense in depth: this entry point is only ever rendered for HR Admin,
     but re-check here too in case it's ever called from elsewhere. */
  const user = currentUser();
  if (!user || user.role !== 'HR Admin') {
    showToast('Only HR Admin can import Winner History.', 'error');
    return;
  }

  _whCsvPendingWinners = [];
  openModal('Import Winner History CSV', `
    <div class="info-alert blue">
      <strong>CSV Format (first row = header, columns comma-separated):</strong><br/>
      <code>Financial Year, Quarter, Award Name, Winner Name, Employee ID, Cluster / Team, Location, Approved By, Approval Date</code><br/>
      • <strong>Mandatory columns:</strong> Financial Year, Quarter, Award Name, Winner Name.<br/>
      • <strong>Optional columns:</strong> Employee ID, Cluster / Team, Location, Approved By, Approval Date — blank or missing is fine.<br/>
      • Extra columns beyond these are ignored automatically.<br/>
      • Records that already exist (same Financial Year + Quarter + Award Name + Winner Name) are skipped automatically.<br/>
      • Existing Winner History is never modified or removed — valid new records are only appended.
    </div>

    <div style="margin-bottom:14px">
      <button class="btn-secondary btn-sm" onclick="downloadWinnerHistoryTemplate()">⬇ Download Sample Template (Winner_History_Template.csv)</button>
    </div>

    <div class="csv-drop-zone" id="whCsvDropZone"
         onclick="document.getElementById('whCsvFileInput').click()"
         ondragover="event.preventDefault();this.classList.add('drag-over')"
         ondragleave="this.classList.remove('drag-over')"
         ondrop="handleWhCsvDrop(event)">
      <div style="font-size:36px;margin-bottom:8px;">📄</div>
      <p><strong>Click to choose a CSV file</strong> or drag &amp; drop here</p>
      <p class="text-muted text-sm" style="margin-top:4px;">Accepts .csv files only</p>
      <input type="file" id="whCsvFileInput" accept=".csv" style="display:none"
             onchange="handleWhCsvFileSelect(this)"/>
    </div>

    <div id="whCsvError" class="error-msg" style="display:none;margin-top:12px"></div>

    <div id="whCsvSummary" style="display:none">
      <div class="csv-summary-grid" id="whCsvSummaryGrid"></div>
      <div class="table-wrapper" style="max-height:260px;overflow-y:auto;margin-top:12px;">
        <table>
          <thead><tr><th>#</th><th>FY</th><th>Quarter</th><th>Award</th><th>Winner</th><th>Result</th></tr></thead>
          <tbody id="whCsvPreviewBody"></tbody>
        </table>
      </div>
    </div>

    <div class="modal-actions" style="margin-top:18px;">
      <button class="btn-primary" id="whCsvConfirmBtn" style="display:none" onclick="commitWhCsvWinners()">✔ Import Records</button>
      <button class="btn-secondary" onclick="closeModal()">Cancel</button>
    </div>`, true);
}

function downloadWinnerHistoryTemplate() {
  const headers = ['Financial Year','Quarter','Award Name','Winner Name','Employee ID','Cluster / Team','Location','Approved By','Approval Date'];
  const sampleRows = [
    ['FY2024-25','Q1','Star Award - Front Office','Asha Rao','E301','Cluster 1 - Mukesh K Pandey','Delhi','Priya Kapoor','2024-08-10'],
    ['FY2024-25','Q2','Star Award - Nurse','Ravi Shankar','','Care Plan','','','']
  ];
  downloadCSV('Winner_History_Template.csv', headers, sampleRows);
}

function handleWhCsvDrop(e) {
  e.preventDefault();
  document.getElementById('whCsvDropZone').classList.remove('drag-over');
  const file = e.dataTransfer.files[0];
  if (file) parseWhCsvFile(file);
}

function handleWhCsvFileSelect(input) {
  const file = input.files[0];
  if (file) parseWhCsvFile(file);
}

function parseWhCsvFile(file) {
  if (!file.name.toLowerCase().endsWith('.csv')) {
    showToast('Please upload a .csv file.', 'error');
    return;
  }
  const reader = new FileReader();
  reader.onload = e => processWhCsvText(e.target.result);
  reader.readAsText(file);
}

/* Parses one CSV line, handling simple double-quoted fields (with "" escapes) */
function whParseCsvLine(line) {
  const out = [];
  let cur = '', inQuotes = false;
  for (let i = 0; i < line.length; i++) {
    const ch = line[i];
    if (inQuotes) {
      if (ch === '"') {
        if (line[i+1] === '"') { cur += '"'; i++; }
        else inQuotes = false;
      } else cur += ch;
    } else {
      if (ch === '"') inQuotes = true;
      else if (ch === ',') { out.push(cur); cur = ''; }
      else cur += ch;
    }
  }
  out.push(cur);
  return out.map(c => c.trim());
}

function whDupKey(fy, quarter, awardName, winnerName) {
  return [fy, quarter, awardName, winnerName].map(v => String(v||'').trim().toLowerCase()).join('|');
}

function processWhCsvText(text) {
  const errEl = document.getElementById('whCsvError');
  errEl.style.display = 'none';
  errEl.textContent = '';

  const lines = text.split(/\r?\n/).map(l => l).filter(l => l.trim());
  if (!lines.length) {
    errEl.textContent = 'CSV file is empty.';
    errEl.style.display = '';
    return;
  }

  const headerCols = whParseCsvLine(lines[0]).map(h => h.trim());
  const headerColsLower = headerCols.map(h => h.toLowerCase());

  /* Map each required/optional header to its column index, tolerant of
     "Cluster / Team" vs "Cluster/Team" vs "Cluster" spacing variations. */
  const findCol = (name) => {
    const target = name.toLowerCase();
    let idx = headerColsLower.indexOf(target);
    if (idx !== -1) return idx;
    if (target === 'cluster / team') {
      idx = headerColsLower.findIndex(h => h.includes('cluster'));
      if (idx !== -1) return idx;
    }
    return -1;
  };

  const colIdx = {
    fy:          findCol('Financial Year'),
    quarter:     findCol('Quarter'),
    awardName:   findCol('Award Name'),
    winnerName:  findCol('Winner Name'),
    empId:       findCol('Employee ID'),
    cluster:     findCol('Cluster / Team'),
    location:    findCol('Location'),
    approvedBy:  findCol('Approved By'),
    approvedAt:  findCol('Approval Date')
  };

  /* Validate mandatory columns are present in the header row */
  const missingHeaders = [];
  if (colIdx.fy === -1)         missingHeaders.push('Financial Year');
  if (colIdx.quarter === -1)    missingHeaders.push('Quarter');
  if (colIdx.awardName === -1)  missingHeaders.push('Award Name');
  if (colIdx.winnerName === -1) missingHeaders.push('Winner Name');

  if (missingHeaders.length) {
    errEl.textContent = `Missing required column(s): ${missingHeaders.join(', ')}. Please use the sample template and try again.`;
    errEl.style.display = '';
    document.getElementById('whCsvSummary').style.display = 'none';
    document.getElementById('whCsvConfirmBtn').style.display = 'none';
    _whCsvPendingWinners = [];
    return;
  }

  const dataLines = lines.slice(1);
  const existing = getWinners();
  const existingKeys = new Set(existing.map(w => whDupKey(w.fy, w.quarter, w.awardName, w.winnerName)));
  const seenInFile = new Set();

  _whCsvPendingWinners = [];
  const previewRows = [];
  let okCount = 0, dupCount = 0, invalidCount = 0;

  dataLines.forEach((line, idx) => {
    const cols = whParseCsvLine(line);
    const get = (i) => i === -1 ? '' : (cols[i] || '').trim();

    const fy         = get(colIdx.fy);
    const quarter    = get(colIdx.quarter);
    const awardName  = get(colIdx.awardName);
    const winnerName = get(colIdx.winnerName);
    const empId      = get(colIdx.empId);
    const cluster    = get(colIdx.cluster);
    const location   = get(colIdx.location);
    const approvedBy = get(colIdx.approvedBy);
    const approvedAt = get(colIdx.approvedAt);

    const rowNum = idx + 2; /* +1 for header row, +1 for 1-based display */

    /* Mandatory field validation (per-row) */
    if (!fy || !quarter || !awardName || !winnerName) {
      invalidCount++;
      previewRows.push({ idx: rowNum, fy: fy||'—', quarter: quarter||'—', awardName: awardName||'—', winnerName: winnerName||'—', result: 'fail', reason: 'Missing mandatory field(s)' });
      return;
    }

    const key = whDupKey(fy, quarter, awardName, winnerName);
    if (existingKeys.has(key) || seenInFile.has(key)) {
      dupCount++;
      previewRows.push({ idx: rowNum, fy, quarter, awardName, winnerName, result: 'dup', reason: 'Duplicate record' });
      return;
    }
    seenInFile.add(key);

    _whCsvPendingWinners.push({
      id: 'W' + Date.now().toString(36).toUpperCase() + Math.floor(Math.random()*1000),
      awardId: '',           /* imported rows use free-text award names; no AWARD_LIST id */
      awardName,
      fy, quarter,
      winnerName,
      empId: empId || '',
      cluster: cluster || '',
      location: location || '',
      approvedAt: approvedAt || '',
      approvedBy: approvedBy || '',
      isDemo: false,
      importedAt: new Date().toISOString()
    });
    okCount++;
    previewRows.push({ idx: rowNum, fy, quarter, awardName, winnerName, result: 'ok', reason: '' });
  });

  document.getElementById('whCsvSummary').style.display = '';
  document.getElementById('whCsvSummaryGrid').innerHTML = `
    <div class="csv-stat-grid">
      <div class="csv-stat ok"><div class="csv-stat-num">${dataLines.length}</div><div class="csv-stat-lbl">Total Records in CSV</div></div>
      <div class="csv-stat ok"><div class="csv-stat-num">${okCount}</div><div class="csv-stat-lbl">Ready to Import</div></div>
      <div class="csv-stat dup"><div class="csv-stat-num">${dupCount}</div><div class="csv-stat-lbl">Duplicates Skipped</div></div>
      <div class="csv-stat fail"><div class="csv-stat-num">${invalidCount}</div><div class="csv-stat-lbl">Invalid Skipped</div></div>
    </div>`;

  const badgeMap = { ok:'badge-green', dup:'badge-yellow', fail:'badge-red' };
  const labelMap = { ok:'✓ Ready', dup:'Duplicate', fail:'Invalid' };
  document.getElementById('whCsvPreviewBody').innerHTML = previewRows.map(r => `
    <tr>
      <td>${r.idx}</td>
      <td>${r.fy}</td>
      <td>${r.quarter}</td>
      <td>${r.awardName}</td>
      <td>${r.winnerName}</td>
      <td><span class="badge ${badgeMap[r.result]||'badge-gray'}">${labelMap[r.result]||r.result}</span>${r.reason?`<br/><span class="text-muted text-sm">${r.reason}</span>`:''}</td>
    </tr>`).join('');

  document.getElementById('whCsvConfirmBtn').style.display = okCount > 0 ? '' : 'none';
}

function commitWhCsvWinners() {
  /* Re-check role at commit time too — belt and suspenders against any
     stale modal state if the session somehow changed. */
  const user = currentUser();
  if (!user || user.role !== 'HR Admin') {
    showToast('Only HR Admin can import Winner History.', 'error');
    closeModal();
    return;
  }
  if (!_whCsvPendingWinners.length) {
    showToast('Nothing to import.', 'error');
    return;
  }

  /* Append-only: read existing records, push new ones, write back.
     Never clears, overwrites, or replaces the existing array. */
  const winners = getWinners();
  const importCount = _whCsvPendingWinners.length;
  _whCsvPendingWinners.forEach(w => winners.push(w));
  setWinners(winners);
  _whCsvPendingWinners = [];

  closeModal();
  showToast(`${importCount} winner record(s) imported successfully.`);
  renderWinnerHistory();  /* refresh table, search, filters, Previous Winners */
}

/* =========================================================
   MANAGER DASHBOARD  (Change 1: Awards come from Team-Award mapping)
   ========================================================= */
function renderManagerDashboard() {
  const user = currentUser();
  const fy = getFY(); const q = getQ();

  /* Change 1: Get awards via team mapping.
     1. Read manager's eligibleTeams.
     2. Look up each team in rr_team_awards.
     3. Union all award IDs.
     Fall back to rr_assignments (old per-manager method) if no team awards exist yet,
     so the portal keeps working even before HR has set up team mappings. */
  const teamAwardIds = getAwardIdsForManager(user);
  let myAwardIds;
  if (teamAwardIds.length > 0) {
    myAwardIds = teamAwardIds;
  } else {
    /* Fallback: use legacy per-manager assignments (preserves behaviour before migration) */
    const legacyAssignments = getAssignments().filter(a => a.role === 'Manager' && a.empId === user.empId);
    myAwardIds = [...new Set(legacyAssignments.map(a => a.awardId))];
  }

  const myAwards = AWARD_LIST.filter(a => myAwardIds.includes(a.id));
  const winners  = getWinners();
  const nomOpen  = isNomOpen();
  let html = '';

  /* Show which teams this manager belongs to */
  const teamsList = Array.isArray(user.eligibleTeams) && user.eligibleTeams.length
    ? user.eligibleTeams.map(t => `<span class="team-tag">${t}</span>`).join(' ')
    : '<span class="text-muted">No team assigned — contact HR Admin</span>';
  html += `<div class="info-alert blue" style="margin-bottom:16px">
    <strong>Your Team(s):</strong> ${teamsList}
  </div>`;

  if (!nomOpen) {
    html += `<div class="nom-status-banner off">🚫 Nominations are currently closed. Please contact HR Admin.</div>`;
  }
  if (!myAwards.length) {
    html += `<div class="empty-state"><div class="empty-icon">🏆</div><p>No awards assigned to your team yet. Contact HR Admin.</p></div>`;
    document.getElementById('pageContent').innerHTML = html;
    return;
  }
  html += `<div class="awards-grid">${myAwards.map(award => {
    const prevWinner = winners.filter(w=>w.awardId===award.id).slice(-1)[0];
    let typeLabel = award.type==='Reporting' ? 'Manager Finalization' : award.type==='Jury' ? 'Jury Award' : 'Business Head Award';
    let footerContent = '';
    if (award.type==='Reporting') {
      footerContent = `<span class="headcount-info">⚡ Finalization Award</span>`;
    }
    const disabled = !nomOpen ? 'disabled style="opacity:0.5;cursor:not-allowed"' : '';
    return `<div class="award-card">
      <div class="award-card-header">
        <h4>${award.name}</h4>
        <div class="award-type">${typeLabel}</div>
      </div>
      <div class="award-card-body">
        <div class="award-criteria">${award.criteria.replace(/\n/g,'<br/>')}</div>
        <div class="award-prev-winner">
          <strong>Previous Winner:</strong> ${prevWinner ? prevWinner.winnerName + ' (' + prevWinner.fy + ' ' + prevWinner.quarter + ')' : 'None yet'}
        </div>
      </div>
      <div class="award-card-footer">
        ${footerContent}
        <button class="btn-primary btn-sm" ${disabled} onclick="openNomForm('${award.id}')">+ Nominate</button>
      </div>
    </div>`;
  }).join('')}</div>`;

  // Previous Winners panel
  const recentWinners = getWinners().slice(-8).reverse();
  html += `<div class="section-card" style="margin-top:24px">
    <div class="section-card-header">
      <h3>🏅 Previous Winners</h3>
      <button class="btn-secondary btn-sm" onclick="navigateTo('winnerHistory')">View Full History →</button>
    </div>
    <div class="section-card-body">
      ${recentWinners.length ? `<div class="table-wrapper"><table>
        <thead><tr><th>Financial Year</th><th>Quarter</th><th>Award</th><th>Winner</th></tr></thead>
        <tbody>${recentWinners.map(w=>`<tr>
          <td>${w.fy}</td><td><span class="badge badge-blue">${qDisplay(w.quarter)}</span></td>
          <td>${w.awardName}</td>
          <td><div class="winner-name-cell"><span class="winner-trophy">🏆</span><strong>${w.winnerName}</strong></div></td>
        </tr>`).join('')}</tbody>
      </table></div>`
      : `<div class="empty-state"><div class="empty-icon">🏅</div><p>No winners recorded yet.</p></div>`}
    </div>
  </div>`;

  document.getElementById('pageContent').innerHTML = html;
}

function openNomForm(awardId) {
  if (!isNomOpen()) { showToast('Nominations are currently closed.','error'); return; }
  const award = AWARD_LIST.find(a=>a.id===awardId);
  const user  = currentUser();
  const fy = getFY(); const q = getQ();
  const isRising = award.id==='A01';

  /* Change 4: Filter clusters by manager's eligible teams.
     eligibleTeams is set when manager is created via CSV.
     If empty/missing, fall back to showing all award clusters. */
  const managerTeams = Array.isArray(user.eligibleTeams) && user.eligibleTeams.length
    ? user.eligibleTeams
    : null;

  const awardClusters = (award.clusters && award.clusters.length)
    ? award.clusters
    : CLUSTERS.filter(c=>c!=='Other');

  /* Intersection: only clusters that are both in the award AND assigned to manager */
  const availableClusters = managerTeams
    ? awardClusters.filter(c => managerTeams.includes(c))
    : awardClusters;

  /* If the intersection is empty (manager has teams but none match this award), show a warning */
  if (managerTeams && availableClusters.length === 0) {
    showToast('None of your assigned teams are eligible for this award. Contact HR Admin.','error');
    return;
  }

  const clusterOptions = availableClusters.map(c=>`<option>${c}</option>`).join('');

  /* v9: Rising Star does NOT show Headcount or Allowed Winners.
     Other awards show headcount info box. */
  let hcInfoHtml = '';
  if (isRising) {
    // No headcount display for Rising Star
    hcInfoHtml = `
      <div class="form-group"><label>Cluster</label>
        <select id="nomCluster">
          ${clusterOptions}
        </select>
      </div>`;
  } else {
    hcInfoHtml = `
      <div class="form-group"><label>Cluster</label>
        <select id="nomCluster" onchange="updateHCInfo('${awardId}')">${clusterOptions}</select>
      </div>
      <div id="nomHCInfo" class="hc-info-box" style="display:none"></div>`;
  }

  /* Show a note if teams were filtered */
  const filteredNote = managerTeams
    ? `<div class="info-alert orange" style="margin-bottom:12px;">Showing your <strong>${availableClusters.length}</strong> eligible team(s) for this award.</div>`
    : '';

  /* Change 2: Rising Star Award (A01) uses a 4-parameter scored evaluation table
     instead of a free-text reason. All other awards keep the Reason textarea. */
  const reasonOrScoreHtml = isRising ? `
    <div class="form-group">
      <label>Evaluation – Score (1-5)</label>
      <div class="score-scale-hint" style="margin-top:-2px;margin-bottom:10px;">1 = Lowest Rating &nbsp;·&nbsp; 5 = Highest Rating</div>
      <div class="table-wrapper">
        <table class="eval-score-table">
          <thead><tr><th>Parameter</th><th style="width:120px;text-align:center">Score (1-5)</th></tr></thead>
          <tbody>
            <tr><td>Job Performance</td><td><input id="rsJobPerf" type="number" min="1" max="5" step="1" oninput="updateRisingTotal()" placeholder="1-5"/></td></tr>
            <tr><td>Values</td><td><input id="rsValues" type="number" min="1" max="5" step="1" oninput="updateRisingTotal()" placeholder="1-5"/></td></tr>
            <tr><td>Punctuality</td><td><input id="rsPunctuality" type="number" min="1" max="5" step="1" oninput="updateRisingTotal()" placeholder="1-5"/></td></tr>
            <tr><td>Grooming</td><td><input id="rsGrooming" type="number" min="1" max="5" step="1" oninput="updateRisingTotal()" placeholder="1-5"/></td></tr>
          </tbody>
        </table>
      </div>
      <div id="rsTotalBox" class="hc-info-box" style="display:block;margin-top:10px;">
        <div class="hc-num" id="rsTotalNum">0</div>
        <div class="hc-label">Total Score (out of 20)</div>
      </div>
      <div id="rsScoreError" class="field-error" style="display:none">All four scores are required and must be whole numbers between 1 and 5.</div>
    </div>
    <div class="form-group">
      <label>Comments <span class="optional-label">(Optional)</span></label>
      <textarea id="rsComment" placeholder="Add any additional comments about the nominee… (optional)" style="min-height:70px"></textarea>
    </div>` : `
    <div class="form-group"><label>Reason for Nomination</label>
      <textarea id="nomReason" placeholder="Describe the nominee's achievements and why they deserve this award…"></textarea>
    </div>`;

  openModal('Nominate – ' + award.name, `
    <div class="info-alert blue">You are nominating for <strong>${award.name}</strong> | ${fy} ${q}</div>
    ${filteredNote}
    <div class="form-row">
      <div class="form-group"><label>Nominee Name</label><input id="nomName" type="text" placeholder="Full Name"/></div>
      <div class="form-group"><label>Employee ID</label><input id="nomEmpId" type="text" placeholder="e.g. E201"/></div>
    </div>
    ${hcInfoHtml}
    <div class="form-group"><label>Location</label><input id="nomLocation" type="text" placeholder="City / Site"/></div>
    ${reasonOrScoreHtml}
    <div class="modal-actions">
      <button class="btn-primary" onclick="submitNomination('${awardId}')">Submit Nomination</button>
      <button class="btn-secondary" onclick="closeModal()">Cancel</button>
    </div>`);
  if (!isRising) setTimeout(() => updateHCInfo(awardId), 100);
}

function updateRisingTotal() {
  const ids = ['rsJobPerf','rsValues','rsPunctuality','rsGrooming'];
  let total = 0;
  ids.forEach(id => {
    const v = parseInt(document.getElementById(id).value);
    if (!isNaN(v)) total += v;
  });
  const numEl = document.getElementById('rsTotalNum');
  if (numEl) numEl.textContent = total;
}

/* v9: updateHCInfo shows headcount/allowed info for a specific award+cluster combination */
function updateHCInfo(awardId) {
  const award = AWARD_LIST.find(a => a.id === awardId);
  if (!award) return;
  const awardName = award.name;
  const cluster = document.getElementById('nomCluster')?.value;
  const fy = getFY(); const q = getQ();
  const box = document.getElementById('nomHCInfo');
  if (!box || !cluster) return;
  // Look up headcount for this team + award
  const hc = getHeadcounts().find(h => h.fy===fy && h.quarter===q && h.cluster===cluster && h.award===awardName);
  if (hc) {
    const allowed = Math.ceil(hc.headcount / 30);
    box.style.display='block';
    box.innerHTML=`<div class="hc-num">${hc.headcount}</div><div class="hc-label">Headcount for ${cluster} – ${awardName}</div>
      <div class="hc-allowed">✅ ${allowed} Winner${allowed>1?'s':''} Allowed this Quarter</div>`;
    box.dataset.allowed = allowed;
    box.dataset.cluster = cluster;
  } else {
    box.style.display='block';
    box.innerHTML=`<div class="hc-label" style="color:rgba(255,255,255,0.7)">No headcount data for this team/award/period. Contact HR Admin.</div>`;
    box.dataset.allowed = 0;
  }
}

function submitNomination(awardId) {
  const award = AWARD_LIST.find(a=>a.id===awardId);
  const isRisingSubmit = awardId === 'A01';
  const name     = document.getElementById('nomName').value.trim();
  const empId    = document.getElementById('nomEmpId').value.trim();
  const cluster  = document.getElementById('nomCluster').value;
  const location = document.getElementById('nomLocation').value.trim();
  if (!name||!empId||!cluster||!location) { showToast('Please fill all required fields.','error'); return; }
  const fy = getFY(); const q = getQ();
  const user = currentUser();

  let reason = '';
  let jobPerformanceScore, valuesScore, punctualityScore, groomingScore, totalScore;

  if (isRisingSubmit) {
    /* Change 2: Rising Star uses 4 whole-number scores (1-5 each) instead of free text */
    const errEl = document.getElementById('rsScoreError');
    const readScore = (id) => {
      const raw = document.getElementById(id).value.trim();
      const v = Number(raw);
      return (raw !== '' && Number.isInteger(v)) ? v : NaN;
    };
    jobPerformanceScore = readScore('rsJobPerf');
    valuesScore         = readScore('rsValues');
    punctualityScore    = readScore('rsPunctuality');
    groomingScore        = readScore('rsGrooming');
    const allValid = [jobPerformanceScore, valuesScore, punctualityScore, groomingScore]
      .every(v => !isNaN(v) && v>=1 && v<=5);
    if (!allValid) {
      errEl.style.display = 'block';
      return;
    }
    errEl.style.display = 'none';
    totalScore = jobPerformanceScore + valuesScore + punctualityScore + groomingScore;
  } else {
    reason = document.getElementById('nomReason').value.trim();
  }

  /* Capture optional Rising Star comment */
  const rsComment = isRisingSubmit ? (document.getElementById('rsComment')?.value.trim() || '') : '';

  /* v9: Rising Star does NOT use headcount — no nomination limit based on headcount.
     For other awards, check headcount-based allowed winners limit. */
  if (award.id !== 'A01') {
    const box = document.getElementById('nomHCInfo');
    const allowed = parseInt(box?.dataset?.allowed || '0');
    if (allowed > 0) {
      const existingNoms = getNominations().filter(n =>
        n.awardId === awardId && n.fy === fy && n.quarter === q &&
        n.managerEmpId === user.empId && n.cluster === cluster
      );
      if (existingNoms.length >= allowed) {
        showToast(`You have reached the allowed ${allowed} nomination(s) for this cluster/award combination.`, 'error');
        return;
      }
    }
  }
  // Determine initial status
  let status = 'Submitted';
  if (award.type==='Jury') status = 'Jury Review';
  else if (award.type==='BusinessHead') status = 'BH Review';
  else if (award.type==='Reporting') status = 'HR Review';
  const noms = getNominations();
  const nomRecord = {
    id: uid(), awardId, fy, quarter:q,
    nomineeName:name, empId, cluster, location, reason,
    managerEmpId:user.empId, managerName:user.name,
    submittedAt: new Date().toISOString().slice(0,10),
    status, juryScores:[], bhScores:[]
  };
  if (isRisingSubmit) {
    nomRecord.jobPerformanceScore = jobPerformanceScore;
    nomRecord.valuesScore         = valuesScore;
    nomRecord.punctualityScore    = punctualityScore;
    nomRecord.groomingScore       = groomingScore;
    nomRecord.totalScore          = totalScore;
    if (rsComment) nomRecord.rsComment = rsComment;
  }
  noms.push(nomRecord);
  setNominations(noms);
  closeModal();
  showToast('Nomination submitted successfully!');
  renderManagerDashboard();
}

/* =========================================================
   MY NOMINATIONS (Manager)
   ========================================================= */
function renderMyNominations() {
  const user = currentUser();
  const fy = getFY(); const q = getQ();
  const noms = getNominations().filter(n=>n.fy===fy&&n.quarter===q&&n.managerEmpId===user.empId);
  document.getElementById('pageContent').innerHTML = `
    <div class="section-card">
      <div class="section-card-header"><h3>My Nominations – ${fy} ${q}</h3></div>
      <div class="section-card-body">
        <div class="table-wrapper">
          <table>
            <thead><tr><th>Nominee</th><th>Award</th><th>Cluster</th><th>Submitted</th><th>Status</th><th>Action</th></tr></thead>
            <tbody>
              ${noms.length ? noms.map(n=>{
                const award = AWARD_LIST.find(a=>a.id===n.awardId);
                return `<tr>
                  <td><strong>${n.nomineeName}</strong><br/><span class="text-muted text-sm">${n.empId}</span></td>
                  <td>${award?award.name:'—'}</td>
                  <td>${n.cluster}</td>
                  <td>${n.submittedAt}</td>
                  <td>${statusBadge(n.status)}</td>
                  <td><button class="btn-secondary btn-sm" onclick="openNomDetail('${n.id}')">View</button></td>
                </tr>`;
              }).join('') : '<tr><td colspan="6"><div class="empty-state"><div class="empty-icon">📝</div><p>You have not submitted any nominations for this period.</p></div></td></tr>'}
            </tbody>
          </table>
        </div>
      </div>
    </div>`;
}

/* =========================================================
   JURY DASHBOARD
   ========================================================= */
function renderJuryDashboard() {
  const user = currentUser();
  const fy = getFY(); const q = getQ();
  const myAwardIds = getAssignments().filter(a=>a.role==='Jury'&&a.empId===user.empId).map(a=>a.awardId);
  const pending = getNominations().filter(n => n.fy===fy && n.quarter===q && n.status==='Jury Review' && myAwardIds.includes(n.awardId));
  const evaluated = getNominations().filter(n => n.fy===fy && n.quarter===q && myAwardIds.includes(n.awardId) && n.juryScores && n.juryScores.find(j=>j.juryId===user.empId));
  const recentWinners = getWinners().slice(-6).reverse();
  document.getElementById('pageContent').innerHTML = `
    <div class="stats-grid">
      <div class="stat-card"><div class="stat-icon">⏳</div><div><div class="stat-value">${pending.length}</div><div class="stat-label">Pending Evaluations</div></div></div>
      <div class="stat-card green"><div class="stat-icon">✅</div><div><div class="stat-value">${evaluated.length}</div><div class="stat-label">Completed Evaluations</div></div></div>
    </div>
    <div class="section-card">
      <div class="section-card-header"><h3>Nominations Awaiting Your Evaluation</h3></div>
      <div class="section-card-body">
        ${pending.length ? `<div class="table-wrapper"><table>
          <thead><tr><th>Nominee</th><th>Award</th><th>Cluster</th><th>Reason (preview)</th><th>Action</th></tr></thead>
          <tbody>${pending.map(n=>{
            const award = AWARD_LIST.find(a=>a.id===n.awardId);
            const alreadyScored = n.juryScores && n.juryScores.find(j=>j.juryId===user.empId);
            return `<tr>
              <td><strong>${n.nomineeName}</strong><br/><span class="text-muted text-sm">${n.empId}</span></td>
              <td>${award?award.name:'—'}</td>
              <td>${n.cluster}</td>
              <td class="text-muted">${n.reason.slice(0,60)}…</td>
              <td><button class="btn-primary btn-sm" onclick="openJuryEval('${n.id}')">${alreadyScored?'Update Eval':'Evaluate'}</button></td>
            </tr>`;
          }).join('')}</tbody></table></div>`
        : `<div class="empty-state"><div class="empty-icon">✅</div><p>No nominations pending your evaluation.</p></div>`}
      </div>
    </div>
    <div class="section-card" style="margin-top:24px">
      <div class="section-card-header">
        <h3>🏅 Previous Winners</h3>
        <button class="btn-secondary btn-sm" onclick="navigateTo('winnerHistory')">View Full History →</button>
      </div>
      <div class="section-card-body">
        ${recentWinners.length ? `<div class="table-wrapper"><table>
          <thead><tr><th>Financial Year</th><th>Quarter</th><th>Award</th><th>Winner</th></tr></thead>
          <tbody>${recentWinners.map(w=>`<tr>
            <td>${w.fy}</td><td><span class="badge badge-blue">${qDisplay(w.quarter)}</span></td>
            <td>${w.awardName}</td>
            <td><div class="winner-name-cell"><span class="winner-trophy">🏆</span><strong>${w.winnerName}</strong></div></td>
          </tr>`).join('')}</tbody>
        </table></div>`
        : `<div class="empty-state"><div class="empty-icon">🏅</div><p>No winners recorded yet.</p></div>`}
      </div>
    </div>`;
}

function renderJuryEvaluations() {
  const user = currentUser();
  const fy = getFY(); const q = getQ();
  const myAwardIds = getAssignments().filter(a=>a.role==='Jury'&&a.empId===user.empId).map(a=>a.awardId);
  const allRelevant = getNominations().filter(n=>n.fy===fy&&n.quarter===q&&myAwardIds.includes(n.awardId));
  document.getElementById('pageContent').innerHTML = `
    <div class="section-card">
      <div class="section-card-header"><h3>All Evaluations – ${fy} ${q}</h3></div>
      <div class="section-card-body">
        <div class="table-wrapper"><table>
          <thead><tr><th>Nominee</th><th>Award</th><th>Your Score (1-10)</th><th>Avg Score</th><th>Status</th><th>Action</th></tr></thead>
          <tbody>${allRelevant.length ? allRelevant.map(n=>{
            const award = AWARD_LIST.find(a=>a.id===n.awardId);
            const myScore = n.juryScores && n.juryScores.find(j=>j.juryId===user.empId);
            const avg = n.juryScores&&n.juryScores.length ? (n.juryScores.reduce((s,j)=>s+j.score,0)/n.juryScores.length).toFixed(1) : '—';
            return `<tr>
              <td><strong>${n.nomineeName}</strong></td>
              <td>${award?award.name:'—'}</td>
              <td>${myScore ? `<strong>${myScore.score}</strong>` : '<span class="text-muted">Pending</span>'}</td>
              <td>${avg}</td>
              <td>${statusBadge(n.status)}</td>
              <td><button class="btn-secondary btn-sm" onclick="openJuryEval('${n.id}')">Evaluate</button></td>
            </tr>`;
          }).join('') : '<tr><td colspan="6"><div class="empty-state"><div class="empty-icon">⚖️</div><p>No nominations assigned.</p></div></td></tr>'}</tbody>
        </table></div>
      </div>
    </div>`;
}

function openJuryEval(nomId) {
  const nom = getNominations().find(n=>n.id===nomId);
  const award = AWARD_LIST.find(a=>a.id===nom.awardId);
  const user = currentUser();
  const existing = nom.juryScores && nom.juryScores.find(j=>j.juryId===user.empId);
  openModal('Jury Evaluation – ' + nom.nomineeName, `
    <div class="info-alert blue">Award: <strong>${award?award.name:'—'}</strong></div>
    <div class="detail-row"><span class="label">Nominee</span><span class="value">${nom.nomineeName} (${nom.empId})</span></div>
    <div class="detail-row"><span class="label">Cluster</span><span class="value">${nom.cluster}</span></div>
    <div class="detail-row"><span class="label">Location</span><span class="value">${nom.location}</span></div>
    <div class="detail-row"><span class="label">Reason</span><span class="value">${nom.reason}</span></div>
    <hr class="divider"/>
    <div class="form-group"><label>Score (1-10)</label>
      <input id="juryScore" type="number" min="1" max="10" step="1" value="${existing?existing.score:''}" placeholder="Enter score"/>
      <div class="score-scale-hint">1 = Lowest Rating &nbsp;·&nbsp; 10 = Highest Rating</div>
      <div id="juryScoreError" class="field-error" style="display:none">Please enter a whole number between 1 and 10.</div>
    </div>
    <div class="form-group"><label>Comments <span class="text-muted" style="font-weight:400">(optional)</span></label>
      <textarea id="juryComment" placeholder="Add evaluation comments… (optional)">${existing?existing.comment:''}</textarea>
    </div>
    <div class="modal-actions">
      <button class="btn-primary" onclick="submitJuryEval('${nomId}')">Submit Evaluation</button>
      <button class="btn-secondary" onclick="closeModal()">Cancel</button>
    </div>`);
}

function submitJuryEval(nomId) {
  const scoreEl = document.getElementById('juryScore');
  const errEl   = document.getElementById('juryScoreError');
  const raw     = scoreEl.value.trim();
  const score   = Number(raw);
  const isWhole = raw !== '' && Number.isInteger(score);
  if (!isWhole || score<1 || score>10) {
    errEl.style.display = 'block';
    scoreEl.classList.add('input-error');
    return;
  }
  errEl.style.display = 'none';
  scoreEl.classList.remove('input-error');
  const comment = document.getElementById('juryComment').value.trim();
  const user = currentUser();
  const noms = getNominations();
  const nom  = noms.find(n=>n.id===nomId);
  if (!nom.juryScores) nom.juryScores = [];
  const idx = nom.juryScores.findIndex(j=>j.juryId===user.empId);
  const entry = { juryId:user.empId, juryName:user.name, score, comment };
  if (idx>-1) nom.juryScores[idx]=entry; else nom.juryScores.push(entry);
  // Move to HR Review if all jury members have scored
  const juryAssigned = getAssignments().filter(a=>a.role==='Jury'&&a.awardId===nom.awardId);
  if (nom.juryScores.length >= juryAssigned.length) nom.status='HR Review';
  setNominations(noms);
  closeModal();
  showToast('Evaluation submitted!');
  renderJuryDashboard();
}

/* =========================================================
   BUSINESS HEAD DASHBOARD
   ========================================================= */
function renderBHDashboard() {
  const user = currentUser();
  const fy = getFY(); const q = getQ();
  const myAwardIds = getAssignments().filter(a=>a.role==='BusinessHead'&&a.empId===user.empId).map(a=>a.awardId);
  const nominations = getNominations().filter(n=>n.fy===fy&&n.quarter===q&&n.status==='BH Review'&&myAwardIds.includes(n.awardId));
  const completed   = getNominations().filter(n=>n.fy===fy&&n.quarter===q&&(n.status==='HR Review'||n.status==='Approved')&&myAwardIds.includes(n.awardId));
  const recentWinners = getWinners().slice(-6).reverse();
  document.getElementById('pageContent').innerHTML = `
    <div class="stats-grid">
      <div class="stat-card"><div class="stat-icon">⏳</div><div><div class="stat-value">${nominations.length}</div><div class="stat-label">Pending Reviews</div></div></div>
      <div class="stat-card green"><div class="stat-icon">✅</div><div><div class="stat-value">${completed.length}</div><div class="stat-label">Decisions Made</div></div></div>
    </div>
    <div class="section-card">
      <div class="section-card-header"><h3>Nominations for Your Review – ${fy} ${q}</h3></div>
      <div class="section-card-body">
        ${nominations.length ? `<div class="table-wrapper"><table>
          <thead><tr><th>Nominee</th><th>Award</th><th>Cluster</th><th>Reason</th><th>Action</th></tr></thead>
          <tbody>${nominations.map(n=>{
            const award = AWARD_LIST.find(a=>a.id===n.awardId);
            return `<tr>
              <td><strong>${n.nomineeName}</strong><br/><span class="text-muted text-sm">${n.empId}</span></td>
              <td>${award?award.name:'—'}</td>
              <td>${n.cluster}</td>
              <td class="text-muted">${n.reason.slice(0,60)}…</td>
              <td><button class="btn-primary btn-sm" onclick="openBHReview('${n.id}')">Review</button></td>
            </tr>`;
          }).join('')}</tbody></table></div>`
        : `<div class="empty-state"><div class="empty-icon">💼</div><p>No nominations pending your review for this period.</p></div>`}
      </div>
    </div>
    <div class="section-card" style="margin-top:24px">
      <div class="section-card-header">
        <h3>🏅 Previous Winners</h3>
        <button class="btn-secondary btn-sm" onclick="navigateTo('winnerHistory')">View Full History →</button>
      </div>
      <div class="section-card-body">
        ${recentWinners.length ? `<div class="table-wrapper"><table>
          <thead><tr><th>Financial Year</th><th>Quarter</th><th>Award</th><th>Winner</th></tr></thead>
          <tbody>${recentWinners.map(w=>`<tr>
            <td>${w.fy}</td><td><span class="badge badge-blue">${qDisplay(w.quarter)}</span></td>
            <td>${w.awardName}</td>
            <td><div class="winner-name-cell"><span class="winner-trophy">🏆</span><strong>${w.winnerName}</strong></div></td>
          </tr>`).join('')}</tbody>
        </table></div>`
        : `<div class="empty-state"><div class="empty-icon">🏅</div><p>No winners recorded yet.</p></div>`}
      </div>
    </div>`;
}

function openBHReview(nomId) {
  const nom = getNominations().find(n=>n.id===nomId);
  const award = AWARD_LIST.find(a=>a.id===nom.awardId);
  const isScored = award && award.bhScored;
  const user = currentUser();
  const existing = nom.bhScores && nom.bhScores.find(b=>b.bhId===user.empId);
  const scoringFields = isScored ? `
    <hr class="divider"/>
    <div class="form-group"><label>Score (1-10)</label>
      <input id="bhScore" type="number" min="1" max="10" step="1" value="${existing?existing.score:''}" placeholder="Enter score"/>
      <div class="score-scale-hint">1 = Lowest Rating &nbsp;·&nbsp; 10 = Highest Rating</div>
      <div id="bhScoreError" class="field-error" style="display:none">Please enter a whole number between 1 and 10.</div>
    </div>
    <div class="form-group"><label>Comments <span class="text-muted" style="font-weight:400">(optional)</span></label>
      <textarea id="bhComment" placeholder="Add scoring comments… (optional)">${existing?existing.comment:''}</textarea>
    </div>` : `
    <hr class="divider"/>
    <div class="info-alert blue">Select this nominee as the winner for the award.</div>`;
  openModal('BH Review – ' + nom.nomineeName, `
    <div class="info-alert blue">Award: <strong>${award?award.name:'—'}</strong>${isScored?' (Scoring Required)':''}</div>
    <div class="detail-row"><span class="label">Nominee</span><span class="value">${nom.nomineeName} (${nom.empId})</span></div>
    <div class="detail-row"><span class="label">Cluster</span><span class="value">${nom.cluster}</span></div>
    <div class="detail-row"><span class="label">Location</span><span class="value">${nom.location}</span></div>
    <div class="detail-row"><span class="label">Reason</span><span class="value">${nom.reason}</span></div>
    ${scoringFields}
    <div class="modal-actions">
      <button class="btn-success" onclick="submitBHDecision('${nomId}', ${isScored})">
        ${isScored ? 'Submit Score' : '✓ Select as Winner'}
      </button>
      <button class="btn-secondary" onclick="closeModal()">Cancel</button>
    </div>`);
}

function submitBHDecision(nomId, isScored) {
  const user = currentUser();
  const noms = getNominations();
  const nom  = noms.find(n=>n.id===nomId);
  if (!nom.bhScores) nom.bhScores = [];
  if (isScored) {
    const scoreEl = document.getElementById('bhScore');
    const errEl   = document.getElementById('bhScoreError');
    const raw     = scoreEl.value.trim();
    const score   = Number(raw);
    const isWhole = raw !== '' && Number.isInteger(score);
    if (!isWhole || score<1 || score>10) {
      errEl.style.display = 'block';
      scoreEl.classList.add('input-error');
      return;
    }
    errEl.style.display = 'none';
    scoreEl.classList.remove('input-error');
    const comment = document.getElementById('bhComment').value.trim();
    const idx = nom.bhScores.findIndex(b=>b.bhId===user.empId);
    const entry = { bhId:user.empId, bhName:user.name, score, comment };
    if (idx>-1) nom.bhScores[idx]=entry; else nom.bhScores.push(entry);
  }
  nom.status = 'HR Review';
  setNominations(noms);
  closeModal();
  showToast('Decision submitted. Sent to HR for final approval.');
  renderBHDashboard();
}

/* =========================================================
   RISING STAR HR REVIEW  (Change 2)
   Shows Nominee Name, Employee ID, Cluster, Location, the 4
   evaluation scores, and Total Score (prominent) for every
   Rising Star (A01) nomination in the selected period.
   ========================================================= */
function renderRisingStarReview() {
  const fy = getFY(); const q = getQ();
  document.getElementById('pageContent').innerHTML = `
    <div class="section-card">
      <div class="section-card-header">
        <h3>Rising Star Award – Evaluation Review – ${fy} ${q}</h3>
        <span class="score-scale-badge">Score (1-5) per parameter · Total (1-20)</span>
      </div>
      <div class="section-card-body">
        <div style="display:flex;gap:12px;flex-wrap:wrap;align-items:center;margin-bottom:16px;">
          <div class="form-group" style="margin:0;flex:1;min-width:200px">
            <label style="margin-bottom:4px;display:block">Search</label>
            <input type="text" id="rsrSearch" placeholder="Search nominee or ID…" oninput="rsrFilter()" style="width:100%"/>
          </div>
          <div style="align-self:flex-end;padding-bottom:2px">
            <button class="btn-secondary btn-sm" onclick="rsrExportCSV()">⬇ Export CSV</button>
          </div>
        </div>
        <div id="rsrTableWrap"></div>
      </div>
    </div>`;
  rsrRenderTable(fy, q);
}

function rsrFilter() {
  rsrRenderTable(getFY(), getQ());
}

function rsrRenderTable(fy, q) {
  let noms = getNominations().filter(n => n.awardId === 'A01' && n.fy === fy && n.quarter === q);
  const search = (document.getElementById('rsrSearch')?.value || '').toLowerCase();
  if (search) noms = noms.filter(n => n.nomineeName.toLowerCase().includes(search) || n.empId.toLowerCase().includes(search));

  if (!window._rsrSort) window._rsrSort = { col: 'total', dir: 'desc' };
  const sort = window._rsrSort;
  function sortTh(col, label) {
    const icon = sort.col === col ? (sort.dir === 'asc' ? ' ▲' : ' ▼') : ' ⇅';
    return `<th style="cursor:pointer;white-space:nowrap" onclick="rsrSetSort('${col}')">${label}${icon}</th>`;
  }
  noms = [...noms].sort((a, b) => {
    let va, vb;
    if (sort.col === 'nominee') { va = a.nomineeName; vb = b.nomineeName; }
    else if (sort.col === 'empId') { va = a.empId; vb = b.empId; }
    else { va = a.totalScore ?? 0; vb = b.totalScore ?? 0; }
    if (va < vb) return sort.dir === 'asc' ? -1 : 1;
    if (va > vb) return sort.dir === 'asc' ? 1 : -1;
    return 0;
  });

  const wrap = document.getElementById('rsrTableWrap');
  if (!wrap) return;
  if (!noms.length) {
    wrap.innerHTML = `<div class="empty-state"><div class="empty-icon">🌟</div><p>No Rising Star nominations found for this period.</p></div>`; return;
  }

  const rows = noms.map(n => `<tr>
      <td><strong>${n.nomineeName}</strong></td>
      <td><code>${n.empId}</code></td>
      <td>${n.cluster}</td>
      <td>${n.location}</td>
      <td style="text-align:center">${n.jobPerformanceScore ?? '—'}</td>
      <td style="text-align:center">${n.valuesScore ?? '—'}</td>
      <td style="text-align:center">${n.punctualityScore ?? '—'}</td>
      <td style="text-align:center">${n.groomingScore ?? '—'}</td>
      <td style="text-align:center"><span class="avg-score">${n.totalScore ?? '—'} / 20</span></td>
      <td style="font-size:12px;color:var(--text-muted)">${n.rsComment || '—'}</td>
    </tr>`).join('');

  wrap.innerHTML = `<div class="table-wrapper">
    <table>
      <thead>
        <tr>
          ${sortTh('nominee','Nominee Name')}
          ${sortTh('empId','Employee ID')}
          <th>Cluster</th>
          <th>Location</th>
          <th>Job Performance</th>
          <th>Values</th>
          <th>Punctuality</th>
          <th>Grooming</th>
          ${sortTh('total','Total Score')}
          <th>Comments</th>
        </tr>
      </thead>
      <tbody>${rows}</tbody>
    </table>
  </div>
  <div class="text-muted text-sm" style="margin-top:8px">Showing ${noms.length} Rising Star nomination(s)</div>`;
}

function rsrSetSort(col) {
  if (!window._rsrSort) window._rsrSort = { col, dir: 'desc' };
  else if (window._rsrSort.col === col) window._rsrSort.dir = window._rsrSort.dir === 'asc' ? 'desc' : 'asc';
  else window._rsrSort = { col, dir: col === 'total' ? 'desc' : 'asc' };
  rsrFilter();
}

function rsrExportCSV() {
  const fy = getFY(); const q = getQ();
  const noms = getNominations().filter(n => n.awardId === 'A01' && n.fy === fy && n.quarter === q);
  const headers = ['Nominee Name','Employee ID','Cluster','Location','Job Performance Score','Values Score','Punctuality Score','Grooming Score','Total Score','Comments'];
  const rows = noms.map(n => [
    n.nomineeName, n.empId, n.cluster, n.location,
    n.jobPerformanceScore ?? '', n.valuesScore ?? '', n.punctualityScore ?? '', n.groomingScore ?? '', n.totalScore ?? '',
    n.rsComment || ''
  ]);
  downloadCSV(`Rising_Star_Review_${fy}_${q}.csv`, headers, rows);
}

/* =========================================================
   HR SCORE REVIEW DASHBOARD
   ========================================================= */
function renderHRScoreReview() {
  const fy = getFY(); const q = getQ();
  // Build award selector — only awards that have jury scoring
  const juryAwards = AWARD_LIST.filter(a => a.type === 'Jury');
  const savedAward = window._hrSRaward || (juryAwards[0] ? juryAwards[0].id : '');

  document.getElementById('pageContent').innerHTML = `
    <div class="section-card">
      <div class="section-card-header">
        <h3>Jury Score Review – ${fy} ${q}</h3>
        <span class="score-scale-badge">Score (1-10)</span>
      </div>
      <div class="section-card-body">
        <div style="display:flex;gap:12px;flex-wrap:wrap;align-items:center;margin-bottom:16px;">
          <div class="form-group" style="margin:0;flex:0 0 auto">
            <label style="margin-bottom:4px;display:block">Select Award</label>
            <select id="hrSRAward" onchange="hrSRChangeAward()" style="min-width:260px">
              ${juryAwards.map(a=>`<option value="${a.id}" ${a.id===savedAward?'selected':''}>${a.name}</option>`).join('')}
            </select>
          </div>
          <div class="form-group" style="margin:0;flex:1;min-width:200px">
            <label style="margin-bottom:4px;display:block">Search</label>
            <input type="text" id="hrSRSearch" placeholder="Search nominee or ID…" oninput="hrSRFilter()" style="width:100%"/>
          </div>
          <div class="form-group" style="margin:0">
            <label style="margin-bottom:4px;display:block">Min Avg Score (1-10)</label>
            <input type="number" id="hrSRMinScore" min="1" max="10" placeholder="e.g. 7" oninput="hrSRFilter()" style="width:110px"/>
          </div>
          <div style="align-self:flex-end;padding-bottom:2px">
            <button class="btn-secondary btn-sm" onclick="hrSRExportCSV()">⬇ Export CSV</button>
          </div>
        </div>
        <div id="hrSRTableWrap"></div>
      </div>
    </div>`;

  hrSRRenderTable(savedAward, fy, q);
}

function hrSRChangeAward() {
  const awardId = document.getElementById('hrSRAward').value;
  window._hrSRward = awardId;
  hrSRRenderTable(awardId, getFY(), getQ());
}

function hrSRFilter() {
  const awardId = document.getElementById('hrSRAward').value;
  hrSRRenderTable(awardId, getFY(), getQ());
}

function hrSRRenderTable(awardId, fy, q) {
  const noms = getNominations().filter(n => n.awardId === awardId && n.fy === fy && n.quarter === q && n.juryScores && n.juryScores.length > 0);
  const allJury = getUsers().filter(u => u.role === 'Jury Member');
  const assignedJuryIds = getAssignments().filter(a => a.role === 'Jury' && a.awardId === awardId).map(a => a.empId);
  const assignedJury = allJury.filter(u => assignedJuryIds.includes(u.empId));

  // Apply search filter
  const search = (document.getElementById('hrSRSearch')?.value || '').toLowerCase();
  const minScore = parseFloat(document.getElementById('hrSRMinScore')?.value || '');

  let filtered = noms;
  if (search) filtered = filtered.filter(n => n.nomineeName.toLowerCase().includes(search) || n.empId.toLowerCase().includes(search));
  if (!isNaN(minScore)) {
    filtered = filtered.filter(n => {
      const avg = n.juryScores.reduce((s,j)=>s+j.score,0) / n.juryScores.length;
      return avg >= minScore;
    });
  }

  // Sort state
  if (!window._hrSRSort) window._hrSRSort = { col: 'avg', dir: 'desc' };
  const sort = window._hrSRSort;

  function sortTh(col, label) {
    const icon = sort.col === col ? (sort.dir === 'asc' ? ' ▲' : ' ▼') : ' ⇅';
    return `<th style="cursor:pointer;white-space:nowrap" onclick="hrSRSetSort('${col}')">${label}${icon}</th>`;
  }

  filtered.sort((a, b) => {
    let va, vb;
    if (sort.col === 'nominee') { va = a.nomineeName; vb = b.nomineeName; }
    else if (sort.col === 'empId') { va = a.empId; vb = b.empId; }
    else { // avg
      va = a.juryScores.length ? a.juryScores.reduce((s,j)=>s+j.score,0)/a.juryScores.length : 0;
      vb = b.juryScores.length ? b.juryScores.reduce((s,j)=>s+j.score,0)/b.juryScores.length : 0;
    }
    if (va < vb) return sort.dir === 'asc' ? -1 : 1;
    if (va > vb) return sort.dir === 'asc' ? 1 : -1;
    return 0;
  });

  const wrap = document.getElementById('hrSRTableWrap');
  if (!wrap) return;

  if (!assignedJury.length) {
    wrap.innerHTML = `<div class="info-alert blue">No jury members assigned to this award yet.</div>`; return;
  }
  if (!filtered.length) {
    wrap.innerHTML = `<div class="empty-state"><div class="empty-icon">⭐</div><p>No scored nominations found for this award/period.</p></div>`; return;
  }

  const juryHeaders = assignedJury.map(j =>
    `<th colspan="2" style="text-align:center;background:rgba(99,102,241,0.08)">${j.name}</th>`
  ).join('');
  const jurySubHeaders = assignedJury.map(() =>
    `<th style="background:rgba(99,102,241,0.05)">Score (1-10)</th><th style="background:rgba(99,102,241,0.05)">Comment</th>`
  ).join('');

  const rows = filtered.map(n => {
    const avg = (n.juryScores.reduce((s,j)=>s+j.score,0)/n.juryScores.length).toFixed(1);
    const juryCells = assignedJury.map(j => {
      const entry = n.juryScores.find(js => js.juryId === j.empId);
      return entry
        ? `<td style="text-align:center"><strong>${entry.score}</strong></td><td style="font-size:12px;color:var(--text-muted)">${entry.comment || '—'}</td>`
        : `<td style="text-align:center;color:var(--text-muted)">—</td><td style="color:var(--text-muted)">—</td>`;
    }).join('');
    return `<tr>
      <td><strong>${n.nomineeName}</strong></td>
      <td><code>${n.empId}</code></td>
      ${juryCells}
      <td style="text-align:center"><span class="avg-score">${avg}</span></td>
    </tr>`;
  }).join('');

  wrap.innerHTML = `<div class="table-wrapper">
    <table>
      <thead>
        <tr>
          ${sortTh('nominee','Nominee Name')}
          ${sortTh('empId','Employee ID')}
          ${juryHeaders}
          ${sortTh('avg','Avg Score')}
        </tr>
        <tr>
          <th></th><th></th>
          ${jurySubHeaders}
          <th></th>
        </tr>
      </thead>
      <tbody>${rows}</tbody>
    </table>
  </div>
  <div class="text-muted text-sm" style="margin-top:8px">Showing ${filtered.length} nomination(s) with jury scores</div>`;
}

function hrSRSetSort(col) {
  if (!window._hrSRSort) window._hrSRSort = { col, dir: 'desc' };
  else if (window._hrSRSort.col === col) window._hrSRSort.dir = window._hrSRSort.dir === 'asc' ? 'desc' : 'asc';
  else window._hrSRSort = { col, dir: col === 'avg' ? 'desc' : 'asc' };
  hrSRFilter();
}

function hrSRExportCSV() {
  const awardId = document.getElementById('hrSRAward')?.value;
  if (!awardId) return;
  const fy = getFY(); const q = getQ();
  const award = AWARD_LIST.find(a => a.id === awardId);
  const noms = getNominations().filter(n => n.awardId === awardId && n.fy === fy && n.quarter === q && n.juryScores && n.juryScores.length > 0);
  const assignedJuryIds = getAssignments().filter(a => a.role === 'Jury' && a.awardId === awardId).map(a => a.empId);
  const assignedJury = getUsers().filter(u => u.role === 'Jury Member' && assignedJuryIds.includes(u.empId));

  const juryHeaders = assignedJury.flatMap(j => [`${j.name} Score (1-10)`, `${j.name} Comment`]);
  const headers = ['Nominee Name','Employee ID', ...juryHeaders, 'Average Score'];
  const rows = noms.map(n => {
    const avg = n.juryScores.length ? (n.juryScores.reduce((s,j)=>s+j.score,0)/n.juryScores.length).toFixed(1) : '';
    const juryCols = assignedJury.flatMap(j => {
      const e = n.juryScores.find(js => js.juryId === j.empId);
      return e ? [e.score, e.comment || ''] : ['',''];
    });
    return [n.nomineeName, n.empId, ...juryCols, avg];
  });
  downloadCSV(`Jury_Score_Review_${award?award.name:awardId}_${fy}_${q}.csv`, headers, rows);
}

/* =========================================================
   BH SCORE REVIEW DASHBOARD
   ========================================================= */
function renderBHScoreReview() {
  const fy = getFY(); const q = getQ();
  const noms = getNominations().filter(n => n.fy === fy && n.quarter === q && n.bhScores && n.bhScores.length > 0);

  if (!window._bhSRSort) window._bhSRSort = { col: 'avg', dir: 'desc' };
  const sort = window._bhSRSort;

  document.getElementById('pageContent').innerHTML = `
    <div class="section-card">
      <div class="section-card-header">
        <h3>Business Head Score Review – ${fy} ${q}</h3>
        <span class="score-scale-badge">Score (1-10)</span>
      </div>
      <div class="section-card-body">
        <div style="display:flex;gap:12px;flex-wrap:wrap;align-items:center;margin-bottom:16px;">
          <div class="form-group" style="margin:0;flex:1;min-width:200px">
            <label style="margin-bottom:4px;display:block">Search</label>
            <input type="text" id="bhSRSearch" placeholder="Search nominee or ID…" oninput="bhSRFilter()" style="width:100%"/>
          </div>
          <div style="align-self:flex-end;padding-bottom:2px">
            <button class="btn-secondary btn-sm" onclick="bhSRExportCSV()">⬇ Export CSV</button>
          </div>
        </div>
        <div id="bhSRTableWrap"></div>
      </div>
    </div>`;

  bhSRRenderTable(noms, fy, q);
}

function bhSRFilter() {
  const fy = getFY(); const q = getQ();
  const search = (document.getElementById('bhSRSearch')?.value || '').toLowerCase();
  let noms = getNominations().filter(n => n.fy === fy && n.quarter === q && n.bhScores && n.bhScores.length > 0);
  if (search) noms = noms.filter(n => n.nomineeName.toLowerCase().includes(search) || n.empId.toLowerCase().includes(search));
  bhSRRenderTable(noms, fy, q);
}

function bhSRSetSort(col) {
  if (!window._bhSRSort) window._bhSRSort = { col, dir: 'desc' };
  else if (window._bhSRSort.col === col) window._bhSRSort.dir = window._bhSRSort.dir === 'asc' ? 'desc' : 'asc';
  else window._bhSRSort = { col, dir: col === 'avg' ? 'desc' : 'asc' };
  bhSRFilter();
}

function bhSRRenderTable(noms, fy, q) {
  const sort = window._bhSRSort || { col:'avg', dir:'desc' };
  function sortTh(col, label) {
    const icon = sort.col === col ? (sort.dir === 'asc' ? ' ▲' : ' ▼') : ' ⇅';
    return `<th style="cursor:pointer;white-space:nowrap" onclick="bhSRSetSort('${col}')">${label}${icon}</th>`;
  }

  noms = [...noms].sort((a, b) => {
    let va, vb;
    if (sort.col === 'nominee') { va = a.nomineeName; vb = b.nomineeName; }
    else if (sort.col === 'empId') { va = a.empId; vb = b.empId; }
    else {
      va = a.bhScores.length ? a.bhScores.reduce((s,b)=>s+b.score,0)/a.bhScores.length : 0;
      vb = b.bhScores.length ? b.bhScores.reduce((s,b)=>s+b.score,0)/b.bhScores.length : 0;
    }
    if (va < vb) return sort.dir === 'asc' ? -1 : 1;
    if (va > vb) return sort.dir === 'asc' ? 1 : -1;
    return 0;
  });

  const wrap = document.getElementById('bhSRTableWrap');
  if (!wrap) return;
  if (!noms.length) {
    wrap.innerHTML = `<div class="empty-state"><div class="empty-icon">💼</div><p>No BH-scored nominations found for this period.</p></div>`; return;
  }

  const rows = noms.map(n => {
    const award = AWARD_LIST.find(a => a.id === n.awardId);
    const avg = (n.bhScores.reduce((s,b)=>s+b.score,0)/n.bhScores.length).toFixed(1);
    const bhCells = n.bhScores.map(b =>
      `<td><strong>${b.bhName}</strong><br/><span style="font-size:12px;color:var(--text-muted)">${b.comment||'—'}</span></td>
       <td style="text-align:center"><strong>${b.score}</strong></td>`
    ).join('');
    return `<tr>
      <td><strong>${n.nomineeName}</strong></td>
      <td><code>${n.empId}</code></td>
      <td>${award?award.name:'—'}</td>
      ${bhCells}
      <td style="text-align:center"><span class="avg-score">${avg}</span></td>
    </tr>`;
  }).join('');

  wrap.innerHTML = `<div class="table-wrapper">
    <table>
      <thead>
        <tr>
          ${sortTh('nominee','Nominee Name')}
          ${sortTh('empId','Employee ID')}
          <th>Award</th>
          <th>Business Head / Comment</th>
          <th>BH Score (1-10)</th>
          ${sortTh('avg','Avg Score')}
        </tr>
      </thead>
      <tbody>${rows}</tbody>
    </table>
  </div>
  <div class="text-muted text-sm" style="margin-top:8px">Showing ${noms.length} nomination(s) with BH scores</div>`;
}

function bhSRExportCSV() {
  const fy = getFY(); const q = getQ();
  const noms = getNominations().filter(n => n.fy === fy && n.quarter === q && n.bhScores && n.bhScores.length > 0);
  const headers = ['Nominee Name','Employee ID','Award','Business Head','BH Score (1-10)','BH Comment','Average Score'];
  const rows = noms.flatMap(n => {
    const award = AWARD_LIST.find(a => a.id === n.awardId);
    const avg = n.bhScores.length ? (n.bhScores.reduce((s,b)=>s+b.score,0)/n.bhScores.length).toFixed(1) : '';
    return n.bhScores.map((b, i) => [
      i===0 ? n.nomineeName : '',
      i===0 ? n.empId : '',
      i===0 ? (award?award.name:'') : '',
      b.bhName, b.score, b.comment||'',
      i===0 ? avg : ''
    ]);
  });
  downloadCSV(`BH_Score_Review_${fy}_${q}.csv`, headers, rows);
}

/* =========================================================
   HR NOMINATION TRACKER
   ========================================================= */
function renderNominationTracker() {
  const fy = getFY(); const q = getQ();
  const allNoms = getNominations();
  const users = getUsers();
  const managers = users.filter(u => u.role === 'Manager' && u.active);

  // Unique FY/Q values from existing nominations + current
  const fySet = [...new Set(['FY2024-25','FY2025-26','FY2026-27', ...allNoms.map(n=>n.fy)])].sort();
  const qSet  = ['Q1','Q2','Q3','Q4'];

  // Read filter state
  const fFY      = document.getElementById('ntFY')?.value      || fy;
  const fQ       = document.getElementById('ntQ')?.value       || q;
  const fAward   = document.getElementById('ntAward')?.value   || '';
  const fManager = document.getElementById('ntManager')?.value || '';
  const fNominee = document.getElementById('ntNominee')?.value || '';
  const fCluster = document.getElementById('ntCluster')?.value || '';

  let noms = allNoms.filter(n => n.fy === fFY && n.quarter === fQ);

  // Summary stats (before additional filters)
  /* Change 1: Eligible managers are now those whose team has at least one award assigned */
  const teamAwards = getTeamAwards();
  const teamsWithAwards = new Set(teamAwards.filter(t => t.awardIds.length > 0).map(t => t.team));
  const eligibleMgrs = managers.filter(m => {
    /* Manager is eligible if any of their teams has awards, OR they have legacy manager-award assignments */
    const hasTeamAward = Array.isArray(m.eligibleTeams) && m.eligibleTeams.some(t => teamsWithAwards.has(t));
    const hasLegacyAssignment = getAssignments().some(a => a.role === 'Manager' && a.empId === m.empId);
    return hasTeamAward || hasLegacyAssignment;
  });
  const submittedMgrIds = [...new Set(noms.map(n=>n.managerEmpId))];
  const submittedMgrs = eligibleMgrs.filter(m => submittedMgrIds.includes(m.empId));
  const pendingMgrs   = eligibleMgrs.filter(m => !submittedMgrIds.includes(m.empId));

  // Apply additional filters
  if (fAward)   noms = noms.filter(n => n.awardId === fAward);
  if (fManager) noms = noms.filter(n => n.managerEmpId === fManager);
  if (fNominee) noms = noms.filter(n => n.nomineeName.toLowerCase().includes(fNominee.toLowerCase()) || n.empId.toLowerCase().includes(fNominee.toLowerCase()));
  if (fCluster) noms = noms.filter(n => n.cluster === fCluster);

  document.getElementById('pageContent').innerHTML = `
    <div class="stats-grid">
      <div class="stat-card blue"><div class="stat-icon">👥</div><div><div class="stat-value">${eligibleMgrs.length}</div><div class="stat-label">Total Eligible Managers</div></div></div>
      <div class="stat-card green"><div class="stat-icon">✅</div><div><div class="stat-value">${submittedMgrs.length}</div><div class="stat-label">Managers Submitted</div></div></div>
      <div class="stat-card yellow"><div class="stat-icon">⏳</div><div><div class="stat-value">${pendingMgrs.length}</div><div class="stat-label">Managers Pending</div></div></div>
      <div class="stat-card"><div class="stat-icon">📝</div><div><div class="stat-value">${noms.length}</div><div class="stat-label">Total Nominations</div></div></div>
    </div>

    <div class="section-card">
      <div class="section-card-header">
        <h3>Nomination Tracker</h3>
        <button class="btn-secondary btn-sm" onclick="ntExportCSV()">⬇ Export CSV</button>
      </div>
      <div class="section-card-body">
        <!-- Filters Row -->
        <div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(160px,1fr));gap:12px;margin-bottom:16px">
          <div class="form-group" style="margin:0">
            <label style="margin-bottom:4px;display:block">Financial Year</label>
            <select id="ntFY" onchange="renderNominationTracker()">
              ${fySet.map(f=>`<option ${f===fFY?'selected':''}>${f}</option>`).join('')}
            </select>
          </div>
          <div class="form-group" style="margin:0">
            <label style="margin-bottom:4px;display:block">Quarter</label>
            <select id="ntQ" onchange="renderNominationTracker()">
              ${qSet.map(qq=>`<option value="${qq}" ${qq===fQ?'selected':''}>${qDisplay(qq)}</option>`).join('')}
            </select>
          </div>
          <div class="form-group" style="margin:0">
            <label style="margin-bottom:4px;display:block">Award Category</label>
            <select id="ntAward" onchange="renderNominationTracker()">
              <option value="">All Awards</option>
              ${AWARD_LIST.map(a=>`<option value="${a.id}" ${a.id===fAward?'selected':''}>${a.name}</option>`).join('')}
            </select>
          </div>
          <div class="form-group" style="margin:0">
            <label style="margin-bottom:4px;display:block">Manager</label>
            <select id="ntManager" onchange="renderNominationTracker()">
              <option value="">All Managers</option>
              ${managers.map(m=>`<option value="${m.empId}" ${m.empId===fManager?'selected':''}>${m.name}</option>`).join('')}
            </select>
          </div>
          <div class="form-group" style="margin:0">
            <label style="margin-bottom:4px;display:block">Nominee</label>
            <input type="text" id="ntNominee" placeholder="Name or ID…" value="${fNominee}" oninput="renderNominationTracker()" style="width:100%"/>
          </div>
          <div class="form-group" style="margin:0">
            <label style="margin-bottom:4px;display:block">Cluster</label>
            <select id="ntCluster" onchange="renderNominationTracker()">
              <option value="">All Clusters</option>
              ${CLUSTERS.filter(c=>c!=='Other').map(c=>`<option ${c===fCluster?'selected':''}>${c}</option>`).join('')}
            </select>
          </div>
        </div>

        <!-- Pending Managers callout -->
        ${pendingMgrs.length ? `
        <details style="margin-bottom:16px">
          <summary style="cursor:pointer;font-weight:600;color:var(--yellow);padding:8px 0">
            ⚠️ ${pendingMgrs.length} Manager(s) Yet to Submit
          </summary>
          <div style="margin-top:8px;display:flex;flex-wrap:wrap;gap:8px">
            ${pendingMgrs.map(m=>`<span class="badge badge-yellow">${m.name}${m.email?` <span style="font-weight:400;opacity:0.8">(${m.email})</span>`:''}</span>`).join('')}
          </div>
        </details>` : `<div class="info-alert" style="margin-bottom:16px;background:rgba(16,185,129,0.1);border-color:var(--green);color:var(--green)">✅ All eligible managers have submitted nominations for this period.</div>`}

        <!-- Table -->
        ${noms.length ? `
        <div class="table-wrapper">
          <table>
            <thead><tr>
              <th>Award Category</th>
              <th>Nominee Name</th>
              <th>Nominee Emp ID</th>
              <th>Nominated By (Manager)</th>
              <th>Submission Date</th>
              <th>Status</th>
            </tr></thead>
            <tbody>
              ${noms.map(n => {
                const award = AWARD_LIST.find(a=>a.id===n.awardId);
                const mgr = getUsers().find(u=>u.empId===n.managerEmpId);
                return `<tr>
                  <td>${award?award.name:'—'}</td>
                  <td><strong>${n.nomineeName}</strong></td>
                  <td><code>${n.empId}</code></td>
                  <td>${n.managerName}${mgr&&mgr.email?`<br/><span class="text-muted text-sm">${mgr.email}</span>`:''}</td>
                  <td>${n.submittedAt}</td>
                  <td>${statusBadge(n.status)}</td>
                </tr>`;
              }).join('')}
            </tbody>
          </table>
        </div>
        <div class="text-muted text-sm" style="margin-top:8px">Showing ${noms.length} nomination(s)</div>`
        : `<div class="empty-state"><div class="empty-icon">📈</div><p>No nominations match the selected filters.</p></div>`}
      </div>
    </div>`;
}

function ntExportCSV() {
  const fFY      = document.getElementById('ntFY')?.value      || getFY();
  const fQ       = document.getElementById('ntQ')?.value       || getQ();
  const fAward   = document.getElementById('ntAward')?.value   || '';
  const fManager = document.getElementById('ntManager')?.value || '';
  const fNominee = document.getElementById('ntNominee')?.value || '';
  const fCluster = document.getElementById('ntCluster')?.value || '';

  let noms = getNominations().filter(n => n.fy === fFY && n.quarter === fQ);
  if (fAward)   noms = noms.filter(n => n.awardId === fAward);
  if (fManager) noms = noms.filter(n => n.managerEmpId === fManager);
  if (fNominee) noms = noms.filter(n => n.nomineeName.toLowerCase().includes(fNominee.toLowerCase()) || n.empId.toLowerCase().includes(fNominee.toLowerCase()));
  if (fCluster) noms = noms.filter(n => n.cluster === fCluster);

  const headers = ['Award Category','Nominee Name','Nominee Employee ID','Nominated By Manager','Manager Email','Submission Date','Cluster','Status'];
  const rows = noms.map(n => {
    const award = AWARD_LIST.find(a=>a.id===n.awardId);
    const mgr = getUsers().find(u=>u.empId===n.managerEmpId);
    return [award?award.name:'', n.nomineeName, n.empId, n.managerName, mgr?(mgr.email||''):'', n.submittedAt, n.cluster, n.status];
  });
  downloadCSV(`Nomination_Tracker_${fFY}_${fQ}.csv`, headers, rows);
}

/* =========================================================
   CSV DOWNLOAD HELPER
   ========================================================= */
function downloadCSV(filename, headers, rows) {
  const escape = v => {
    const s = String(v==null?'':v);
    return s.includes(',') || s.includes('"') || s.includes('\n') ? `"${s.replace(/"/g,'""')}"` : s;
  };
  const lines = [headers.map(escape).join(','), ...rows.map(r => r.map(escape).join(','))];
  const blob = new Blob([lines.join('\r\n')], { type:'text/csv;charset=utf-8;' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url; a.download = filename; a.click();
  URL.revokeObjectURL(url);
}

/* =========================================================
   ASYNC STARTUP — loads JSONBin then boots the portal
   ========================================================= */
function bootPortal() {
  initStorage();
  const user = currentUser();
  if (user) {
    const sessionRoles = getSessionRoles();
    if (!sessionRoles.length && user.email) {
      const allRoles = getUsers().filter(u => u.active && (u.email||'').toLowerCase() === (user.email||'').toLowerCase());
      if (allRoles.length > 0) setSessionRoles(allRoles);
    }
    document.getElementById('loginPage').style.display = 'none';
    document.getElementById('appShell').style.display = 'flex';
    buildNav();
    navigateTo(defaultPage(user.role));
  }
}

bootPortal();

